
'use client';

import { collection, addDoc, serverTimestamp, Firestore, doc, setDoc } from "firebase/firestore";
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

// --- Loan Request ---
type LoanRequestData = {
    purpose: string;
    amount: number;
    duration: number;
    organizationId: string;
};

export function submitLoanRequest(firestore: Firestore, userId: string, data: LoanRequestData) {
    const loanRequestsCollection = collection(firestore, 'users', userId, 'loanRequests');
    const loanData = {
        ...data,
        userId: userId,
        status: "Pending",
        dateRequested: serverTimestamp(),
    };
    
    addDoc(loanRequestsCollection, loanData).catch(error => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
            path: loanRequestsCollection.path,
            operation: 'create',
            requestResourceData: loanData
        }));
        throw error; // Re-throw to be caught by the calling transition
    });
}

// --- Equipment Rental ---
type EquipmentRentalData = {
    equipmentType: string;
    duration: number;
    durationUnit: string;
    organizationId: string;
};

export function rentEquipment(firestore: Firestore, userId: string, data: EquipmentRentalData) {
    const equipmentRentalsCollection = collection(firestore, 'users', userId, 'equipmentRentals');
    const rentalData = {
        ...data,
        userId: userId,
        status: "Pending",
        requestDate: serverTimestamp(),
    };

    addDoc(equipmentRentalsCollection, rentalData).catch(error => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
            path: equipmentRentalsCollection.path,
            operation: 'create',
            requestResourceData: rentalData
        }));
        throw error;
    });
}

// --- Service Booking ---
type ServiceBookingData = {
    crop: string;
    area: number;
    bookingDate: string;
    organizationId: string;
    plan: string;
};

export function bookService(firestore: Firestore, userId: string, data: ServiceBookingData) {
    const bookingsCollection = collection(firestore, 'users', userId, 'farmingGroupBookings');
    const bookingData = {
        ...data,
        userId: userId,
        service: "Full Crop Plan",
        status: "Pending",
        requestDate: serverTimestamp(),
    };

    addDoc(bookingsCollection, bookingData).catch(error => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
            path: bookingsCollection.path,
            operation: 'create',
            requestResourceData: bookingData
        }));
        throw error;
    });
}


// --- Innovation Submission ---
type InnovationData = {
    title: string;
    description: string;
    imageUri?: string;
};

export function submitInnovation(firestore: Firestore, userId: string, data: InnovationData) {
    const innovationsCollection = collection(firestore, 'innovations');
    const innovationData = {
        ...data,
        userId: userId,
        status: "PendingReview",
        submittedAt: serverTimestamp(),
    };

    addDoc(innovationsCollection, innovationData).catch(error => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
            path: innovationsCollection.path,
            operation: 'create',
            requestResourceData: innovationData
        }));
        throw error;
    });
}

// --- Sell Produce ---
type ProduceOfferData = {
    cropType: string;
    quality: string;
    quantity: number;
    price: number;
    description?: string;
    imageUri?: string;
};

export function listProduceForSale(firestore: Firestore, sellerId: string, data: ProduceOfferData) {
    const cropOffersCollection = collection(firestore, 'cropOffers');
    const offerData = {
        ...data,
        sellerId: sellerId,
        offererType: 'Individual', // Assuming seller is always an individual for now
        listedAt: serverTimestamp(),
    };

    addDoc(cropOffersCollection, offerData).catch(error => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
            path: cropOffersCollection.path,
            operation: 'create',
            requestResourceData: offerData
        }));
        throw error;
    });
}
