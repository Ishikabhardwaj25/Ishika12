export const firebaseConfig = {
  "projectId": "studio-307610280-410bb",
  "appId": "1:1043337783163:web:a749452bcb13ac2019bfde",
  "apiKey": "AIzaSyCqwOcoQ1joqjWGKdzS1lttlo0FRnTGKb4",
  "authDomain": "studio-307610280-410bb.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "1043337783163"
};
