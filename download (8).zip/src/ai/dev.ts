import { config } from 'dotenv';
config();

import '@/ai/flows/crop-doctor-disease-diagnosis.ts';
import '@/ai/flows/fertilizer-calculator.ts';
import '@/ai/flows/weather-forecast.ts';
import '@/ai/flows/mandi-prices.ts';
import '@/ai/flows/soil-health-guide.ts';
import '@/ai/flows/water-use-advisor.ts';
import '@/ai/flows/chat-assistant.ts';
import '@/ai/flows/generate-email.ts';
