'use server';
/**
 * @fileOverview Generates a simulated market price for a given crop.
 *
 * - getMandiPrice - A function that handles the price generation.
 * - MandiPriceInput - The input type for the getMandiPrice function.
 * - MandiPriceOutput - The return type for the getMandiPrice function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MandiPriceInputSchema = z.object({
  cropName: z.string().describe('The name of the crop to get the price for.'),
});
export type MandiPriceInput = z.infer<typeof MandiPriceInputSchema>;

const MandiPriceOutputSchema = z.object({
  price: z.string().describe("The simulated market price of the crop, including units (e.g., '₹2,500 / quintal')."),
  trend: z.enum(['up', 'down', 'stable']).describe("The recent price trend."),
});
export type MandiPriceOutput = z.infer<typeof MandiPriceOutputSchema>;

export async function getMandiPrice(input: MandiPriceInput): Promise<MandiPriceOutput> {
  return mandiPriceFlow(input);
}

const prompt = ai.definePrompt({
  name: 'mandiPricePrompt',
  input: {schema: MandiPriceInputSchema},
  output: {schema: MandiPriceOutputSchema},
  prompt: `You are an agricultural market data simulator.

  Generate a realistic but *simulated* real-time market price (Mandi price) for the following crop: {{{cropName}}}.

  - The price should be in Indian Rupees (₹) per quintal.
  - The price should fluctuate slightly each time to simulate real-time changes.
  - Also provide a price trend: 'up', 'down', or 'stable'.

  Example for "Wheat": "₹2,350 / quintal", trend: "up"
  Example for "Tomato": "₹1,800 / quintal", trend: "down"
  `,
});

const mandiPriceFlow = ai.defineFlow(
  {
    name: 'mandiPriceFlow',
    inputSchema: MandiPriceInputSchema,
    outputSchema: MandiPriceOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
