'use server';
/**
 * @fileOverview Calculates fertilizer recommendations based on land area and crop type.
 *
 * - calculateFertilizer - A function that handles the fertilizer calculation process.
 * - FertilizerCalculatorInput - The input type for the calculateFertilizer function.
 * - FertilizerCalculatorOutput - The return type for the calculateFertilizer function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const FertilizerCalculatorInputSchema = z.object({
  landArea: z.number().describe('The area of the land in acres or hectares.'),
  areaUnit: z.enum(['acres', 'hectares']).describe('The unit for the land area.'),
  cropType: z.string().describe('The type of crop being grown.'),
});
export type FertilizerCalculatorInput = z.infer<typeof FertilizerCalculatorInputSchema>;

const FertilizerCalculatorOutputSchema = z.object({
  fertilizerType: z.string().describe('The recommended type of fertilizer.'),
  quantity: z.string().describe('The recommended quantity of fertilizer.'),
  estimatedCost: z.string().describe('An estimated cost for the recommended fertilizer in Indian Rupees (₹).'),
  applicationSchedule: z.string().describe('A safe and effective application schedule.'),
});
export type FertilizerCalculatorOutput = z.infer<typeof FertilizerCalculatorOutputSchema>;

export async function calculateFertilizer(input: FertilizerCalculatorInput): Promise<FertilizerCalculatorOutput> {
  return fertilizerCalculatorFlow(input);
}

const prompt = ai.definePrompt({
  name: 'fertilizerCalculatorPrompt',
  input: {schema: FertilizerCalculatorInputSchema},
  output: {schema: FertilizerCalculatorOutputSchema},
  prompt: `You are an agricultural expert. A farmer needs a fertilizer recommendation.

  Farmer's Input:
  - Land Area: {{{landArea}}} {{{areaUnit}}}
  - Crop Type: {{{cropType}}}

  Based on this, provide the following:
  1.  **Fertilizer Type**: Recommend a suitable fertilizer (e.g., NPK 10-20-20, Urea).
  2.  **Quantity**: Calculate the total quantity needed for the specified area.
  3.  **Estimated Cost**: Provide a rough cost estimate in Indian Rupees (₹).
  4.  **Application Schedule**: Suggest a safe and effective schedule for applying the fertilizer (e.g., "Apply 50% at sowing, 25% after 30 days, 25% after 60 days").

  Generate a concise and practical recommendation.`,
});

const fertilizerCalculatorFlow = ai.defineFlow(
  {
    name: 'fertilizerCalculatorFlow',
    inputSchema: FertilizerCalculatorInputSchema,
    outputSchema: FertilizerCalculatorOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
