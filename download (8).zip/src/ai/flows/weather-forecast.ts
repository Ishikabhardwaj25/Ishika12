'use server';
/**
 * @fileOverview Generates a 7-day weather forecast for a given location.
 *
 * - getWeatherForecast - A function that handles the weather forecast generation.
 * - WeatherForecastInput - The input type for the getWeatherForecast function.
 * - WeatherForecastOutput - The return type for the getWeatherForecast function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const WeatherForecastInputSchema = z.object({
  location: z.string().describe('The city or area for the weather forecast.'),
});
export type WeatherForecastInput = z.infer<typeof WeatherForecastInputSchema>;

const DailyForecastSchema = z.object({
    day: z.string().describe("The day of the week (e.g., Monday)."),
    temperature: z.string().describe("The predicted temperature (e.g., '25°C')."),
    condition: z.string().describe("The weather condition (e.g., 'Sunny', 'Partly Cloudy')."),
    icon: z.enum(['Sunny', 'PartlyCloudy', 'Cloudy', 'Rainy', 'Stormy']).describe("A single keyword representing the weather condition for icon mapping."),
});

const WeatherForecastOutputSchema = z.object({
  forecast: z.array(DailyForecastSchema).length(7).describe('A 7-day weather forecast.'),
  summary: z.string().describe("A brief summary of the week's weather outlook for a farmer."),
});
export type WeatherForecastOutput = z.infer<typeof WeatherForecastOutputSchema>;

export async function getWeatherForecast(input: WeatherForecastInput): Promise<WeatherForecastOutput> {
  return weatherForecastFlow(input);
}

const prompt = ai.definePrompt({
  name: 'weatherForecastPrompt',
  input: {schema: WeatherForecastInputSchema},
  output: {schema: WeatherForecastOutputSchema},
  prompt: `You are a meteorological AI for farmers. Generate a 7-day weather forecast for {{{location}}}.

  Your output must be practical for farming. For each day, provide the day of the week, a realistic temperature, a simple weather condition, and an icon keyword.
  The icon keyword must be one of: 'Sunny', 'PartlyCloudy', 'Cloudy', 'Rainy', 'Stormy'.

  Also, provide a short, actionable summary for a farmer based on the weekly forecast (e.g., "Good week for planting, but prepare for rain on Friday.").
  `,
});

const weatherForecastFlow = ai.defineFlow(
  {
    name: 'weatherForecastFlow',
    inputSchema: WeatherForecastInputSchema,
    outputSchema: WeatherForecastOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
