'use server';
/**
 * @fileOverview Generates a professional email response to a user's query.
 *
 * - generateEmail - A function that handles the email generation process.
 * - GenerateEmailInput - The input type for the generateEmail function.
 * - GenerateEmailOutput - The return type for the generateEmail function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateEmailInputSchema = z.object({
  userName: z.string().describe('The name of the user to address in the email.'),
  userQuery: z.string().describe("The user's original question or message."),
});
export type GenerateEmailInput = z.infer<typeof GenerateEmailInputSchema>;

const GenerateEmailOutputSchema = z.object({
  subject: z.string().describe("A concise and relevant subject line for the email."),
  body: z.string().describe("The full, professionally formatted body of the email response."),
});
export type GenerateEmailOutput = z.infer<typeof GenerateEmailOutputSchema>;

export async function generateEmail(input: GenerateEmailInput): Promise<GenerateEmailOutput> {
  return generateEmailFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateEmailPrompt',
  input: {schema: GenerateEmailInputSchema},
  output: {schema: GenerateEmailOutputSchema},
  prompt: `You are a helpful customer support assistant for a platform called AgroLink. Your task is to draft a professional and helpful email response to a user.

  User's Name: {{{userName}}}
  User's Query: "{{{userQuery}}}"

  Based on the user's query, please generate an appropriate email response.

  - The subject line should be clear and directly related to the user's query.
  - The body should be friendly, start with a greeting to the user by name, address their query directly, and end with a professional closing (e.g., "Best regards, The AgroLink Team").
  - Do not make up information you don't have. If the query is complex, suggest that a specialist will look into it.`,
});

const generateEmailFlow = ai.defineFlow(
  {
    name: 'generateEmailFlow',
    inputSchema: GenerateEmailInputSchema,
    outputSchema: GenerateEmailOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
