'use server';
/**
 * @fileOverview Provides soil health recommendations.
 *
 * - getSoilHealthGuide - A function that handles the soil health guide generation.
 * - SoilHealthGuideInput - The input type for the getSoilHealthGuide function.
 * - SoilHealthGuideOutput - The return type for the getSoilHealthGuide function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SoilHealthGuideInputSchema = z.object({
  location: z.string().describe('The geographical location (e.g., city, district) of the farm.'),
  cropType: z.string().describe('The type of crop being grown.'),
});
export type SoilHealthGuideInput = z.infer<typeof SoilHealthGuideInputSchema>;

const SoilHealthGuideOutputSchema = z.object({
  recommendations: z.string().describe('Detailed soil improvement methods tailored to the location and crop, formatted for readability.'),
  testReminder: z.string().describe('A friendly and specific reminder about when the next soil test should be conducted.'),
});
export type SoilHealthGuideOutput = z.infer<typeof SoilHealthGuideOutputSchema>;

export async function getSoilHealthGuide(input: SoilHealthGuideInput): Promise<SoilHealthGuideOutput> {
  return soilHealthGuideFlow(input);
}

const prompt = ai.definePrompt({
  name: 'soilHealthGuidePrompt',
  input: {schema: SoilHealthGuideInputSchema},
  output: {schema: SoilHealthGuideOutputSchema},
  prompt: `You are an agricultural soil expert. A farmer needs advice on soil health.

  Farmer's Details:
  - Location: {{{location}}}
  - Crop Type: {{{cropType}}}

  Based on this, provide the following:
  1.  **Soil Improvement Recommendations**: Suggest 2-3 specific, practical methods to improve soil health for this crop and location. Examples: adding compost, cover cropping, crop rotation, adjusting pH. Explain why each is beneficial.
  2.  **Soil Test Reminder**: Give a clear, friendly reminder for when to perform the next soil test. Example: "It's a good idea to test your soil before the next planting season, around October-November."

  Generate a concise and actionable response.`,
});

const soilHealthGuideFlow = ai.defineFlow(
  {
    name: 'soilHealthGuideFlow',
    inputSchema: SoilHealthGuideInputSchema,
    outputSchema: SoilHealthGuideOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
