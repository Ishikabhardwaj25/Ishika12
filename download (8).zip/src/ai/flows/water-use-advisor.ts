'use server';
/**
 * @fileOverview Calculates water requirements for crops based on type and weather.
 *
 * - getWaterUseAdvice - A function that handles the water use calculation.
 * - WaterUseAdvisorInput - The input type for the getWaterUseAdvice function.
 * - WaterUseAdvisorOutput - The return type for the getWaterUseAdvice function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const WaterUseAdvisorInputSchema = z.object({
  cropType: z.string().describe('The type of crop being grown.'),
  location: z.string().describe('The geographical location (e.g., city, district) of the farm to simulate weather conditions.'),
});
export type WaterUseAdvisorInput = z.infer<typeof WaterUseAdvisorInputSchema>;

const WaterUseAdvisorOutputSchema = z.object({
    waterRequirement: z.string().describe('The estimated water requirement for the crop (e.g., "2-3 inches per week").'),
    advice: z.string().describe('Actionable advice for efficient watering (e.g., "Consider drip irrigation to minimize evaporation.").'),
    nextWateringSchedule: z.string().describe('A recommendation for the next watering session (e.g., "Next recommended watering in 3 days.").'),
});
export type WaterUseAdvisorOutput = z.infer<typeof WaterUseAdvisorOutputSchema>;

export async function getWaterUseAdvice(input: WaterUseAdvisorInput): Promise<WaterUseAdvisorOutput> {
  return waterUseAdvisorFlow(input);
}

const prompt = ai.definePrompt({
  name: 'waterUseAdvisorPrompt',
  input: {schema: WaterUseAdvisorInputSchema},
  output: {schema: WaterUseAdvisorOutputSchema},
  prompt: `You are an agricultural irrigation expert. A farmer needs advice on water usage.

  Farmer's Details:
  - Crop Type: {{{cropType}}}
  - Location: {{{location}}}

  Based on this information and typical weather conditions for the location, provide the following:
  1.  **Water Requirement**: Estimate the weekly water requirement for the crop.
  2.  **Watering Advice**: Give a practical tip for efficient water use.
  3.  **Next Watering Schedule**: Suggest a specific timeframe for the next watering session.

  Generate a concise and actionable response.`,
});

const waterUseAdvisorFlow = ai.defineFlow(
  {
    name: 'waterUseAdvisorFlow',
    inputSchema: WaterUseAdvisorInputSchema,
    outputSchema: WaterUseAdvisorOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
