'use server';
/**
 * @fileOverview A conversational AI assistant for farming questions.
 *
 * - askChatAssistant - A function that handles the chat interaction.
 * - ChatAssistantInput - The input type for the askChatAssistant function.
 * - ChatAssistantOutput - The return type for the askChatAssistant function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ChatAssistantInputSchema = z.object({
  query: z.string().describe('The user\'s question about farming.'),
});
export type ChatAssistantInput = z.infer<typeof ChatAssistantInputSchema>;

const ChatAssistantOutputSchema = z.object({
  response: z.string().describe('The AI\'s answer to the user\'s question.'),
});
export type ChatAssistantOutput = z.infer<typeof ChatAssistantOutputSchema>;

export async function askChatAssistant(input: ChatAssistantInput): Promise<ChatAssistantOutput> {
  return chatAssistantFlow(input);
}

const prompt = ai.definePrompt({
  name: 'chatAssistantPrompt',
  input: {schema: ChatAssistantInputSchema},
  output: {schema: ChatAssistantOutputSchema},
  prompt: `You are KrishiBot, an expert agricultural assistant. Your role is to provide clear, concise, and actionable advice to farmers.

  A farmer has a question:
  "{{{query}}}"

  Provide a helpful and direct answer to the farmer's query. Format the response for easy readability. If you provide a list, use bullet points.`,
});

const chatAssistantFlow = ai.defineFlow(
  {
    name: 'chatAssistantFlow',
    inputSchema: ChatAssistantInputSchema,
    outputSchema: ChatAssistantOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
