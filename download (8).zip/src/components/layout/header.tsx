"use client";

import { Sprout, LogIn, LogOut, User as UserIcon, Sun, Moon, Laptop, Languages } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useUser } from '@/firebase';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuPortal,
  DropdownMenuSubContent
} from "@/components/ui/dropdown-menu";
import { signOut, getAuth } from 'firebase/auth';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogTrigger } from '../ui/dialog';
import AuthDialog from '../auth/auth-dialog';
import ProfileDashboard from '../features/profile-dashboard';
import { useTheme } from 'next-themes';
import { useLanguage } from '@/context/language-context';
import type { Language } from '@/lib/translations';

const languageOptions: { code: Language; name: string }[] = [
    { code: 'en', name: 'English' },
    { code: 'hi', name: 'हिंदी' },
    { code: 'as', name: 'অসমীয়া' },
    { code: 'bn', name: 'বাংলা' },
    { code: 'brx', name: 'बोड़ो' },
    { code: 'doi', name: 'डोगरी' },
    { code: 'gu', name: 'ગુજરાતી' },
    { code: 'kn', name: 'ಕನ್ನಡ' },
    { code: 'ks', name: 'کٲشُر' },
    { code: 'kok', name: 'कोंकणी' },
    { code: 'mai', name: 'मैथिली' },
    { code: 'ml', name: 'മലയാളം' },
    { code: 'mni', name: 'মৈতৈ' },
    { code: 'mr', name: 'मराठी' },
    { code: 'ne', name: 'नेपाली' },
    { code: 'or', name: 'ଓଡ଼ିଆ' },
    { code: 'pa', name: 'ਪੰਜਾਬੀ' },
    { code: 'sa', name: 'संस्कृतम्' },
    { code: 'sat', name: 'संताली' },
    { code: 'sd', name: 'सिंधी' },
    { code: 'ta', name: 'தமிழ்' },
    { code: 'te', name: 'తెలుగు' },
    { code: 'ur', name: 'اردو' },
];

export default function Header() {
  const { user, isUserLoading } = useUser();
  const { toast } = useToast();
  const { setTheme } = useTheme();
  const { setLanguage } = useLanguage();

  const handleLogout = async () => {
    try {
      await signOut(getAuth());
      toast({
        title: "Logged Out",
        description: "You have been successfully logged out.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Logout Failed",
        description: "An error occurred while logging out.",
      });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 p-4 md:p-6 flex justify-between items-center w-full z-30 bg-background/30 backdrop-blur-lg border-b border-white/5">
      <div className="flex items-center gap-3">
         <div className="w-10 h-10 flex items-center justify-center rounded-full bg-card border shadow-sm">
            <Sprout className="w-5 h-5 text-primary" />
        </div>
        <div>
            <h1 className="text-xl md:text-2xl font-headline font-bold text-foreground">
            AgroLink
            </h1>
        </div>
      </div>
      <Dialog>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Avatar className="cursor-pointer border-2 border-border hover:border-primary transition-colors">
               <AvatarImage src={user && !user.isAnonymous ? `https://picsum.photos/seed/${user.uid}/100/100` : ''} alt={user?.displayName || ''} />
              <AvatarFallback className="bg-secondary text-primary font-bold">
                {isUserLoading ? <Sprout className="animate-spin" /> : <UserIcon />}
              </AvatarFallback>
            </Avatar>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56 bg-background/80 backdrop-blur-md border-border" align="end">
            {user && !user.isAnonymous && (
              <>
                <DropdownMenuLabel className='truncate'>
                  {user.email}
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
              </>
            )}
            <DialogTrigger asChild>
              <DropdownMenuItem>
                <UserIcon className="mr-2 h-4 w-4" />
                <span>My Profile</span>
              </DropdownMenuItem>
            </DialogTrigger>

             <DropdownMenuSub>
                <DropdownMenuSubTrigger>
                    <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0 mr-2" />
                    <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100 mr-2" />
                    <span>Toggle theme</span>
                </DropdownMenuSubTrigger>
                <DropdownMenuPortal>
                    <DropdownMenuSubContent className="bg-background/80 backdrop-blur-md border-border">
                        <DropdownMenuItem onClick={() => setTheme("light")}>
                            <Sun className="mr-2 h-4 w-4" />
                            <span>Light</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setTheme("dark")}>
                            <Moon className="mr-2 h-4 w-4" />
                            <span>Dark</span>
                        </DropdownMenuItem>
                         <DropdownMenuItem onClick={() => setTheme("system")}>
                            <Laptop className="mr-2 h-4 w-4" />
                            <span>System</span>
                        </DropdownMenuItem>
                    </DropdownMenuSubContent>
                </DropdownMenuPortal>
            </DropdownMenuSub>
            
            <DropdownMenuSub>
                <DropdownMenuSubTrigger>
                    <Languages className="mr-2 h-4 w-4" />
                    <span>Language</span>
                </DropdownMenuSubTrigger>
                <DropdownMenuPortal>
                    <DropdownMenuSubContent className="bg-background/80 backdrop-blur-md border-border max-h-96 overflow-y-auto">
                        {languageOptions.map(lang => (
                            <DropdownMenuItem key={lang.code} onClick={() => setLanguage(lang.code)}>
                                <span>{lang.name}</span>
                            </DropdownMenuItem>
                        ))}
                    </DropdownMenuSubContent>
                </DropdownMenuPortal>
            </DropdownMenuSub>

            <DropdownMenuSeparator />
            
            {user?.isAnonymous ? (
              <DialogTrigger asChild>
                 <DropdownMenuItem>
                    <LogIn className="mr-2 h-4 w-4" />
                    <span>Login/Register</span>
                </DropdownMenuItem>
              </DialogTrigger>
            ) : (
              <DropdownMenuItem onClick={handleLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Logout</span>
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* The Dialog Content depends on the user's auth state */}
        {user?.isAnonymous ? <AuthDialog /> : <ProfileDashboard />}
      </Dialog>
    </header>
  );
}
