"use client";

import { Mail } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function AnimatedEmail({ className }: { className?: string }) {
  return (
    <div className={cn("relative w-24 h-24 flex items-center justify-center", className)}>
      <div className="absolute inset-0 bg-primary/20 rounded-full animate-ping opacity-75"></div>
      <div className="relative w-16 h-16 bg-background rounded-full flex items-center justify-center shadow-lg">
        <Mail className="w-8 h-8 text-primary" />
      </div>
    </div>
  );
}
