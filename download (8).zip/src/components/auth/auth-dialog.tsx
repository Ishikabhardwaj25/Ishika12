"use client";

import { useState, useTransition } from "react";
import { DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { LogIn } from "lucide-react";
import { signInAction, signUpAction } from "@/app/auth/actions";
import { useToast } from "@/hooks/use-toast";

export default function AuthDialog() {
    return (
        <DialogContent className="bg-background/80 border-accent/50 text-foreground p-0 max-w-md w-[95vw] data-[state=open]:animate-sprout-up backdrop-blur-xl rounded-lg shadow-2xl shadow-accent/10">
            <DialogHeader className="p-6 pb-0">
                 <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
                        <LogIn className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                        <DialogTitle className="text-2xl font-headline text-accent tracking-wider">Join or Sign In</DialogTitle>
                        <DialogDescription>Unlock the full potential of your Farmverse.</DialogDescription>
                    </div>
                </div>
            </DialogHeader>
            <div className="p-6">
                 <Tabs defaultValue="login" className="w-full">
                    <TabsList className="grid w-full grid-cols-2 bg-primary/10 border border-primary/20">
                        <TabsTrigger value="login">Login</TabsTrigger>
                        <TabsTrigger value="register">Register</TabsTrigger>
                    </TabsList>
                    <TabsContent value="login">
                        <AuthForm type="login" />
                    </TabsContent>
                    <TabsContent value="register">
                        <AuthForm type="register" />
                    </TabsContent>
                </Tabs>
            </div>
        </DialogContent>
    );
}


function AuthForm({ type }: { type: 'login' | 'register' }) {
    const [isPending, startTransition] = useTransition();
    const [error, setError] = useState<string | null>(null);
    const { toast } = useToast();

    const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        setError(null);
        const formData = new FormData(event.currentTarget);
        
        startTransition(async () => {
            const action = type === 'login' ? signInAction : signUpAction;
            const response = await action(formData);
            if (response.error) {
                setError(response.error);
            } else {
                 toast({
                    title: type === 'login' ? "Login Successful" : "Registration Successful",
                    description: type === 'login' ? "Welcome back!" : "Your account has been created.",
                });
                // We don't need to manually close the dialog.
                // The onAuthStateChanged listener will trigger a re-render of the header,
                // which will remove this component from the DOM.
            }
        });
    }

    return (
        <Card className="bg-transparent border-0 shadow-none">
            <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4 pt-6">
                     {error && (
                        <Alert variant="destructive">
                            <AlertDescription>{error}</AlertDescription>
                        </Alert>
                    )}
                    <div className="space-y-2">
                        <Label htmlFor={`${type}-email`}>Email</Label>
                        <Input id={`${type}-email`} name="email" type="email" placeholder="farmer@example.com" required className="bg-background/50 border-primary/30" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor={`${type}-password`}>Password</Label>
                        <Input id={`${type}-password`} name="password" type="password" required className="bg-background/50 border-primary/30" />
                    </div>
                </CardContent>
                <CardFooter>
                    <Button type="submit" className="w-full font-bold text-lg py-6 bg-gradient-to-r from-primary to-green-400 hover:from-primary/90 hover:to-green-400/90 text-primary-foreground shadow-lg shadow-primary/20 transform hover:scale-105 transition-transform duration-300" disabled={isPending}>
                        {isPending ? 'Processing...' : (type === 'login' ? 'Sign In' : 'Create Account')}
                    </Button>
                </CardFooter>
            </form>
        </Card>
    );
}
