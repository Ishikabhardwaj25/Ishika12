"use client";

import { useEffect } from 'react';
import { useAuth, useUser } from '@/firebase';
import { initiateAnonymousSignIn } from '@/firebase/non-blocking-login';
import { Sprout } from 'lucide-react';

export default function AuthProvider({ children }: { children: React.ReactNode }) {
  const auth = useAuth();
  const { user, isUserLoading } = useUser();

  useEffect(() => {
    // If there is no user and we are not in a loading state,
    // it means the initial auth check is complete and no user was found.
    // In this case, we initiate an anonymous sign-in.
    if (!isUserLoading && !user) {
      initiateAnonymousSignIn(auth);
    }
  }, [user, isUserLoading, auth]);

  if (isUserLoading || !user) {
    // Show a loading screen while Firebase is determining the auth state,
    // or while the anonymous user is being created.
    return (
      <div className="fixed inset-0 bg-background z-50 flex flex-col items-center justify-center gap-4">
        <Sprout className="w-16 h-16 text-primary animate-bounce" />
        <p className="text-primary/80">Connecting to Farmverse...</p>
      </div>
    );
  }

  // Once we have a user (anonymous or registered), render the app.
  return <>{children}</>;
}
