"use client";

import { Card } from "@/components/ui/card";
import { Bot, Sparkles, BrainCircuit } from "lucide-react";
import { useLanguage } from "@/context/language-context";

export default function CharacterAnimation() {
  const { t } = useLanguage();
  return (
    <div className="w-full h-full flex flex-col items-center justify-center text-center p-4">
        <div className="relative w-40 h-40 md:w-48 md:h-48">
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/30 to-accent/30 animate-float opacity-50 blur-2xl"></div>
            <div className="absolute inset-2 rounded-full bg-background/50 flex items-center justify-center">
                <Bot className="w-20 h-20 md:w-24 md:h-24 text-primary animate-glow" />
            </div>
            <Sparkle index={0} />
            <Sparkle index={1} />
            <Sparkle index={2} />
        </div>
        <h3 className="text-xl font-headline font-semibold text-primary mt-4 animate-glow">
          {t.aiAssistant.title}
        </h3>
        <p className="text-muted-foreground mt-1 max-w-xs text-sm">
            {t.aiAssistant.description}
        </p>
    </div>
  );
}


const Sparkle = ({ index }: { index: number }) => {
    const positions = [
        { top: '5%', left: '15%' },
        { top: '25%', left: '85%' },
        { top: '80%', left: '10%' },
    ];
    const delays = ['0s', '0.5s', '1s'];
    const durations = ['1.5s', '2s', '2.5s'];

    return (
        <Sparkles 
            className="absolute w-5 h-5 text-accent/80 animate-pulse"
            style={{
                top: positions[index].top,
                left: positions[index].left,
                animationDelay: delays[index],
                animationDuration: durations[index],
            }}
        />
    )
}
