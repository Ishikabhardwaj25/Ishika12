
"use client";

import DashboardCard from './dashboard-card';
import { Tractor, Rocket, Users, Store, Network, Bot } from 'lucide-react';
import InnovationGarden from '../features/innovation-garden';
import TrainingAndJobs from '../features/training-and-jobs';
import MagicalMarketplace from '../features/magical-marketplace';
import { useLanguage } from '@/context/language-context';
import GovernmentNetwork from '../features/government-network';
import AgroService from '../features/agro-service';
import CharacterAnimation from './character-animation';
import AiAgroAssistant from '../features/ai-agro-assistant';
import { cn } from '@/lib/utils';

export default function Dashboard() {
  const { t } = useLanguage();

  const features = [
     {
      title: t.aiAssistant.title,
      description: t.aiAssistant.description,
      icon: <Bot className="w-8 h-8" />,
      content: <AiAgroAssistant />,
      triggerContent: <CharacterAnimation />,
      className: "lg:row-span-2",
    },
    {
      title: t.governmentHelp.title,
      description: t.governmentHelp.description,
      icon: <Network className="w-8 h-8" />,
      content: <GovernmentNetwork />,
      className: "lg:col-span-1",
    },
    {
      title: t.rentServices.title,
      description: t.rentServices.description,
      icon: <Tractor className="w-8 h-8" />,
      content: <AgroService />,
      className: "lg:col-span-1",
    },
    {
      title: t.newIdeas.title,
      description: t.newIdeas.description,
      icon: <Rocket className="w-8 h-8" />,
      content: <InnovationGarden />,
       className: "lg:col-span-1",
    },
    {
      title: t.trainingJobs.title,
      description: t.trainingJobs.description,
      icon: <Users className="w-8 h-8" />,
      content: <TrainingAndJobs />,
       className: "lg:col-span-1",
    },
    {
      title: t.marketplace.title,
      description: t.marketplace.description,
      icon: <Store className="w-8 h-8" />,
      content: <MagicalMarketplace />,
      className: "lg:col-span-2",
    },
  ];

  const aiAssistantFeature = features[0];
  const otherFeatures = features.slice(1);

  return (
    <div className="w-full max-w-7xl mx-auto">
       <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className={cn("animate-fade-in", aiAssistantFeature.className)} style={{ animationDelay: '100ms' }}>
            <DashboardCard 
              title={aiAssistantFeature.title} 
              description={aiAssistantFeature.description} 
              icon={aiAssistantFeature.icon}
              triggerContent={aiAssistantFeature.triggerContent}
              dialogContentClassName="p-0 max-w-6xl"
            >
              {aiAssistantFeature.content}
            </DashboardCard>
        </div>
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
            {otherFeatures.map((feature, index) => (
            <div key={feature.title} className={cn("animate-fade-in", feature.className)} style={{ animationDelay: `${(index + 2) * 100}ms` }}>
                <DashboardCard {...feature}>
                {feature.content}
                </DashboardCard>
            </div>
            ))}
        </div>
      </div>
    </div>
  );
}
