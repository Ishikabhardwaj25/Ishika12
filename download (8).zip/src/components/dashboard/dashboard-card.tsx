"use client";

import { Dialog, DialogContent, DialogTrigger, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle as CardTitleComponent, CardDescription } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import type { ReactNode } from 'react';

type DashboardCardProps = {
  title: string;
  description: string;
  icon: ReactNode;
  children: ReactNode;
  triggerContent?: ReactNode;
  className?: string;
  dialogContentClassName?: string;
};

export default function DashboardCard({ title, description, icon, children, triggerContent, className, dialogContentClassName }: DashboardCardProps) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Card
          className={cn(
            "group relative bg-card/60 border border-border/50 backdrop-blur-sm transition-all duration-300 cursor-pointer overflow-hidden transform hover:-translate-y-2 h-full shadow-lg hover:shadow-2xl hover:shadow-primary/10",
            "hover:border-primary/50",
            "data-[state=open]:border-primary",
            "flex flex-col",
            className
          )}
        >
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-primary/5 to-transparent transition-opacity duration-500 opacity-0 group-hover:opacity-100"></div>
          <div className="absolute inset-0 bg-grid-pattern opacity-5 group-hover:opacity-10 transition-opacity duration-300"></div>
          
          <CardHeader className="flex flex-row items-start gap-4 p-5 z-10 relative">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary transition-colors duration-300 group-hover:bg-primary group-hover:text-primary-foreground group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-primary/30 shrink-0">
              {icon}
            </div>
            <div className='flex-1'>
              <CardTitleComponent className="font-headline text-lg text-foreground/90 group-hover:text-primary transition-colors duration-300 tracking-wide">{title}</CardTitleComponent>
              <CardDescription className="text-muted-foreground mt-1 text-sm">{description}</CardDescription>
            </div>
          </CardHeader>

          {triggerContent && (
            <CardContent className="p-5 pt-0 z-10 relative flex-1 flex flex-col">
              {triggerContent}
            </CardContent>
          )}
        </Card>
      </DialogTrigger>
      <DialogContent className={cn("bg-background/90 border-border text-foreground p-0 max-w-4xl w-[95vw] data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95 backdrop-blur-sm rounded-lg shadow-2xl", dialogContentClassName)}>
        <DialogTitle className="sr-only">{title}</DialogTitle>
        {children}
      </DialogContent>
    </Dialog>
  );
}
