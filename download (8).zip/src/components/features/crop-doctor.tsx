
"use client";

import { useState, useTransition, ChangeEvent, useRef } from 'react';
import Image from 'next/image';
import { Microscope, UploadCloud, X, Syringe, TestTube, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { diagnoseCropDiseaseAction } from '@/app/actions';
import type { DiagnoseCropDiseaseOutput } from '@/ai/flows/crop-doctor-disease-diagnosis';

const ResultCard = ({ icon, title, content }: { icon: React.ReactNode, title: string, content: string }) => (
    <Card className="bg-card/50 border-primary/10 animate-sprout-up">
      <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
        <div className="text-accent">{icon}</div>
        <CardTitle className="text-base font-headline text-accent/80">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-foreground whitespace-pre-line">{content}</p>
      </CardContent>
    </Card>
);


export default function CropDoctor() {
  const [isPending, startTransition] = useTransition();
  const [result, setResult] = useState<DiagnoseCropDiseaseOutput | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [description, setDescription] = useState('');
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 4 * 1024 * 1024) { // 4MB limit
        setError("Image size cannot exceed 4MB.");
        return;
      }
      setError(null);
      const reader = new FileReader();
      reader.onprogress = (event) => {
        if (event.lengthComputable) {
          const progress = (event.loaded / event.total) * 100;
          setUploadProgress(progress);
        }
      };
      reader.onloadend = () => {
        setImageUri(reader.result as string);
        setUploadProgress(100);
      };
      reader.readAsDataURL(file);
    }
  };

  const clearImage = () => {
    setImageUri(null);
    setUploadProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!imageUri) {
        setError("Please upload an image of the crop.");
        return;
    }
    setError(null);
    setResult(null);

    const formData = new FormData();
    formData.append('photoDataUri', imageUri);
    formData.append('description', description);

    startTransition(async () => {
      const response = await diagnoseCropDiseaseAction(formData);
      if (response.error) {
        setError(response.error);
      } else if (response.data) {
        setResult(response.data);
      }
    });
  };

  return (
    <div className="space-y-6 h-full">
      <Card className="bg-transparent border-0 shadow-none h-full flex flex-col">
        <CardHeader className="p-0 pb-4">
          <CardTitle className="font-headline text-lg flex items-center gap-2">
            <Microscope className="w-6 h-6 text-primary" />
            AI Crop Doctor
          </CardTitle>
          <CardDescription>Upload a photo to get an AI-powered diagnosis for your crop.</CardDescription>
        </CardHeader>
        <CardContent className="p-0 flex-grow">
          <form onSubmit={handleFormSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full">
            <div className="space-y-4">
               <div className="space-y-2">
                <Label>Crop Image</Label>
                <div className="relative p-2 aspect-video w-full border-2 border-dashed border-primary/30 rounded-lg flex items-center justify-center bg-background/50 overflow-hidden">
                    {imageUri ? (
                    <>
                        <Image src={imageUri} alt="Crop preview" fill className="object-contain" />
                        <Button type="button" size="icon" variant="destructive" className="absolute top-2 right-2 z-10 h-8 w-8" onClick={clearImage}>
                        <X className="h-4 w-4" />
                        </Button>
                    </>
                    ) : (
                    <label htmlFor="crop-image" className="text-center cursor-pointer p-4">
                        <UploadCloud className="mx-auto h-10 w-10 text-primary/50" />
                        <p className="mt-2 text-sm text-primary/70">Click to upload an image</p>
                        <p className="text-xs text-primary/50">PNG or JPG, up to 4MB</p>
                    </label>
                    )}
                    <input id="crop-image" type="file" className="sr-only" accept="image/png, image/jpeg" onChange={handleImageChange} ref={fileInputRef}/>
                </div>
                {uploadProgress > 0 && uploadProgress < 100 && (
                    <Progress value={uploadProgress} className="h-2 bg-primary/20" />
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <Textarea
                  id="description"
                  name="description"
                  placeholder="e.g., 'These spots appeared on the lower leaves of my tomato plants yesterday.'"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="bg-background/50 border-primary/30 focus:border-accent"
                />
              </div>
              <Button type="submit" disabled={isPending || !imageUri} className="w-full mt-4 bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-lg py-6">
                {isPending ? 'Diagnosing...' : 'Diagnose Crop'}
              </Button>
            </div>
            
            <div className="flex flex-col">
              <div className="flex-grow space-y-4 min-h-[350px] flex flex-col justify-center">
                {error && (
                  <Alert variant="destructive">
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {isPending && (
                    <div className="flex flex-col items-center justify-center h-full gap-4 text-primary">
                        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-accent"></div>
                        <p className="font-headline text-lg">KrishiBot is analyzing the sample...</p>
                        <p className="text-sm text-primary/70">This might take a moment.</p>
                    </div>
                )}
                
                {result && !isPending && (
                  <div className="space-y-4 animate-fade-in">
                    <h3 className="text-xl font-headline text-accent">AI Diagnosis Result</h3>
                    <ResultCard icon={<Sparkles />} title="Diagnosed Disease" content={result.disease} />
                    <ResultCard icon={<Syringe />} title="Recommended Cure" content={result.cure} />
                    <ResultCard icon={<TestTube />} title="Suggested Fertilizer" content={result.suggestedFertilizer} />
                  </div>
                )}
                 {!result && !isPending && !error && (
                  <div className="flex flex-col items-center justify-center h-full gap-4 text-primary/50 text-center p-8">
                     <Microscope className="w-16 h-16" />
                    <p className="font-headline text-lg">Your diagnosis will appear here.</p>
                    <p className="text-sm">Upload a photo to get started.</p>
                  </div>
                )}
              </div>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
