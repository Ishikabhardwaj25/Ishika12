"use client";

import { DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Users, Briefcase, GraduationCap } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import FindJobs from './find-jobs';
import TrainingPrograms from './training-programs';
import { useLanguage } from '@/context/language-context';
import JoinCooperative from './join-cooperative';

export default function TrainingAndJobs() {
  const { t } = useLanguage();
  return (
    <div className="max-h-[85vh] h-full flex flex-col">
      <DialogHeader className="p-6 border-b border-white/10 sticky top-0 bg-background/80 backdrop-blur-lg z-20">
        <div className="flex items-center gap-4">
          <Users className="w-8 h-8 text-accent" />
          <div>
            <DialogTitle className="text-2xl font-headline text-accent">{t.trainingJobs.dialogTitle}</DialogTitle>
            <DialogDescription>{t.trainingJobs.dialogDescription}</DialogDescription>
          </div>
        </div>
      </DialogHeader>
      <div className="flex-1 overflow-y-auto">
        <Tabs defaultValue="jobs" className="h-full flex flex-col">
          <TabsList className="m-6 bg-primary/10">
            <TabsTrigger value="jobs" className="gap-2">
              <Briefcase className="w-4 h-4" />
              {t.trainingJobs.findJobsTitle}
            </TabsTrigger>
            <TabsTrigger value="training" className="gap-2">
              <GraduationCap className="w-4 h-4" />
              {t.trainingJobs.trainingProgramsTitle}
            </TabsTrigger>
            <TabsTrigger value="cooperatives" className="gap-2">
              <Users className="w-4 h-4" />
              Join a Cooperative
            </TabsTrigger>
          </TabsList>
          <TabsContent value="jobs" className="flex-1 overflow-y-auto px-6 pb-6 mt-0">
            <FindJobs />
          </TabsContent>
          <TabsContent value="training" className="flex-1 overflow-y-auto px-6 pb-6 mt-0">
            <TrainingPrograms />
          </TabsContent>
          <TabsContent value="cooperatives" className="flex-1 overflow-y-auto px-6 pb-6 mt-0">
            <JoinCooperative />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
