"use client";

import { useTransition } from "react";
import Image from 'next/image';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { buyers } from "@/lib/buyers";
import { MapPin, CircleDollarSign, Weight, Handshake } from "lucide-react";
import NegotiateForm from "./negotiate-form";
import { useToast } from "@/hooks/use-toast";

export default function ReadyBuyers() {
    const [isPending, startTransition] = useTransition();
    const { toast } = useToast();

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {buyers.map((buyer) => (
                <Dialog key={buyer.id}>
                    <Card className="bg-card/50 border-primary/20 overflow-hidden flex flex-col animate-sprout-up">
                        <CardHeader className="flex flex-row items-center gap-4">
                            <Avatar className="w-12 h-12">
                                <AvatarImage src={buyer.avatarUrl} alt={buyer.name} />
                                <AvatarFallback>{buyer.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                                <CardTitle className="text-lg font-headline text-primary">{buyer.name}</CardTitle>
                                <CardDescription className="text-xs text-primary/80 flex items-center gap-1">
                                    <MapPin className="w-3 h-3"/> {buyer.location}
                                </CardDescription>
                            </div>
                        </CardHeader>
                        <CardContent className="flex-grow space-y-3">
                             <div className="text-center bg-background/30 p-3 rounded-md">
                                <p className="text-sm text-muted-foreground">Looking for</p>
                                <p className="text-2xl font-bold text-accent">{buyer.crop}</p>
                            </div>
                             <div className="flex justify-around text-sm text-muted-foreground">
                                <span className="flex items-center gap-1"><Weight className="w-4 h-4"/> {buyer.quantity} Quintals</span>
                                <span className="flex items-center gap-1"><CircleDollarSign className="w-4 h-4"/> ₹{buyer.price}/Quintal</span>
                            </div>
                        </CardContent>
                        <CardFooter className="p-4 pt-0">
                            <DialogTrigger asChild>
                                <Button className="w-full">
                                    <Handshake className="w-4 h-4 mr-2"/>
                                    Negotiate
                                </Button>
                            </DialogTrigger>
                        </CardFooter>
                    </Card>
                    <DialogContent className="bg-background/80 border-accent text-foreground p-0 max-w-lg w-[95vw] data-[state=open]:animate-sprout-up backdrop-blur-xl rounded-lg">
                       <NegotiateForm buyer={buyer} />
                    </DialogContent>
                </Dialog>
            ))}
        </div>
    );
}
