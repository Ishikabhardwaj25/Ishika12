
import { DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { GanttChartSquare, CircleCheck, CircleHelp, CircleX } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent } from "@/components/ui/card";

const trackingData = [
    { id: "LOAN-001", type: "Tractor Loan", status: "Approved", icon: <CircleCheck className="text-green-500"/> },
    { id: "RENT-003", type: "Harvester Rent", status: "Pending", icon: <CircleHelp className="text-yellow-500"/> },
    { id: "LOAN-002", type: "Seed Investment", status: "Rejected", icon: <CircleX className="text-red-500"/> },
];

export default function TrackingPage() {
    return (
        <>
            <DialogHeader className="p-6 border-b border-white/10">
                <div className="flex items-center gap-4">
                    <GanttChartSquare className="w-8 h-8 text-accent" />
                    <div>
                        <DialogTitle className="text-2xl font-headline text-accent">Application Status Tracker</DialogTitle>
                        <DialogDescription>Shows loan and rental request progress.</DialogDescription>
                    </div>
                </div>
            </DialogHeader>
            <div className="p-6">
                <Card className="bg-card/50 border-primary/20">
                    <CardContent className="space-y-6 pt-6">
                        {trackingData.map((item, index) => (
                            <div key={item.id}>
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="font-bold text-primary">{item.type}</p>
                                        <p className="text-sm text-muted-foreground">ID: {item.id}</p>
                                    </div>
                                    <div className="flex items-center gap-2 text-lg font-semibold">
                                        {item.icon}
                                        <span>{item.status}</span>
                                    </div>
                                </div>
                                <div className="relative px-2 mt-4">
                                    <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border"></div>
                                    <div className="flex justify-between">
                                        <StatusStep label="Pending" isComplete={true} />
                                        <StatusStep label="Verified" isComplete={item.status === 'Approved' || item.status === 'Rejected'} isActive={item.status === 'Pending'}/>
                                        <StatusStep label="Approved" isComplete={item.status === 'Approved'} isActive={item.status === 'Verified'} isFinal={true} />
                                    </div>
                                </div>
                                {index < trackingData.length - 1 && <Separator className="mt-6 bg-primary/10"/>}
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </div>
        </>
    );
}

const StatusStep = ({ label, isComplete, isActive, isFinal = false }: { label: string, isComplete: boolean, isActive?: boolean, isFinal?: boolean }) => (
    <div className="flex flex-col items-center relative z-10">
        <div className={`w-4 h-4 rounded-full border-2 ${isComplete ? 'bg-primary border-primary' : 'bg-background border-border'}`}></div>
        <p className={`text-xs mt-1 ${isComplete ? 'text-foreground' : 'text-muted-foreground'}`}>{label}</p>
    </div>
)

    