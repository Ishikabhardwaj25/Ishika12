
"use client";

import { useState, useTransition, useMemo } from "react";
import { format } from "date-fns";
import { DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Card, CardContent } from "@/components/ui/card";
import { Wrench, CalendarIcon, CircleDollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "../ui/alert";
import { organizations } from "@/lib/organizations";
import { cn } from "@/lib/utils";
import { useUser, useFirestore } from "@/firebase";
import { useLanguage } from "@/context/language-context";
import { produceData } from "@/lib/produce";
import { bookService } from "@/firebase/firestore/mutations";

const serviceOrganizations = organizations.filter(org => org.services.includes("Booking"));

const servicePlans: { [key: string]: { name: string; pricePerAcre: number; features: string[] } } = {
    affordable: { name: "Affordable", pricePerAcre: 5000, features: ["Standard seeds & soil prep", "Basic harvesting", "Longer turnaround time"] },
    standard: { name: "Standard", pricePerAcre: 9500, features: ["Certified seeds & advanced prep", "Optimized harvesting", "Basic progress report"] },
    premium: { name: "Premium", pricePerAcre: 16000, features: ["Premium seeds & soil analysis", "Precision harvesting", "Fastest turnaround", "Detailed analytics report"] },
};

export default function ServiceBookingForm() {
    const { t } = useLanguage();
    const [isPending, startTransition] = useTransition();
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<boolean>(false);
    const { toast } = useToast();
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();

    const [crop, setCrop] = useState("");
    const [area, setArea] = useState("");
    const [date, setDate] = useState<Date | undefined>();
    const [organization, setOrganization] = useState("");
    const [plan, setPlan] = useState("standard");
    
    const { totalCost } = useMemo(() => {
        const selectedPlan = servicePlans[plan];
        const cost = (area && selectedPlan) ? selectedPlan.pricePerAcre * Number(area) : 0;
        return { totalCost: cost };
    }, [area, plan]);

    const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        if (!user || !firestore) {
            setError("You must be logged in to submit a request.");
            return;
        }
        if (!date) {
            setError("Please select a date for the service.");
            return;
        }

        const bookingData = {
            crop: crop,
            area: Number(area),
            bookingDate: format(date, "PPP"),
            organizationId: organization,
            plan: plan,
        };

        startTransition(async () => {
            try {
                await bookService(firestore, user.uid, bookingData);
                setSuccess(true);
                setCrop("");
                setArea("");
                setDate(undefined);
                setOrganization("");
                setPlan("standard");
                toast({
                    title: "Service Booked!",
                    description: "Your farming plan request has been sent.",
                });
            } catch (e: any) {
                setError(e.message);
            }
        });
    };


    return (
        <>
            <DialogHeader className="p-6 border-b border-white/10">
                <div className="flex items-center gap-4">
                    <Wrench className="w-8 h-8 text-accent" />
                    <div>
                        <DialogTitle className="text-2xl font-headline text-accent">Book a Full Crop Plan</DialogTitle>
                        <DialogDescription>Let experts manage your entire crop cycle, from seed to harvest.</DialogDescription>
                    </div>
                </div>
            </DialogHeader>
            <div className="p-6">
                <Card className="bg-card/50 border-primary/20">
                    <form onSubmit={handleSubmit}>
                        <CardContent className="space-y-6 pt-6">
                             {error && (
                                <Alert variant="destructive">
                                    <AlertTitle>{t.forms.error}</AlertTitle>
                                    <AlertDescription>{error}</AlertDescription>
                                </Alert>
                            )}
                            {success && (
                                <Alert className="border-green-500/50 bg-green-500/10 text-green-200">
                                    <AlertTitle className="text-green-400">{t.forms.success}</AlertTitle>
                                    <AlertDescription>Your booking is confirmed. The provider will contact you shortly.</AlertDescription>
                                </Alert>
                            )}
                            <div className="space-y-2">
                                <Label htmlFor="crop">Which crop do you want to grow?</Label>
                                <Select name="crop" required value={crop} onValueChange={setCrop}>
                                    <SelectTrigger id="crop" className="bg-background/50 border-primary/30">
                                        <SelectValue placeholder="Select a crop..." />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {produceData.map(p => (
                                            <SelectItem key={p.id} value={p.name}>{p.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            
                            <div className="space-y-2">
                                <Label>{t.forms.planLabel}</Label>
                                <div className="grid grid-cols-3 gap-2">
                                    {Object.keys(servicePlans).map((planKey) => (
                                        <Button
                                            key={planKey}
                                            type="button"
                                            variant={plan === planKey ? 'default' : 'outline'}
                                            onClick={() => setPlan(planKey)}
                                            className="h-auto flex flex-col items-center justify-center p-3"
                                        >
                                            <span className="font-bold text-base">{servicePlans[planKey].name}</span>
                                            <span className="text-xs text-muted-foreground">₹{servicePlans[planKey].pricePerAcre}/acre</span>
                                        </Button>
                                    ))}
                                </div>
                                <input type="hidden" name="plan" value={plan} />
                            </div>
                            
                            <Card className="bg-background/30 p-4 border-primary/20">
                                <CardContent className="p-0">
                                    <p className="text-sm font-bold text-primary mb-2">{servicePlans[plan].name} Plan Features:</p>
                                    <ul className="space-y-1 text-xs text-foreground/80 list-disc list-inside">
                                        {servicePlans[plan].features.map(feature => <li key={feature}>{feature}</li>)}
                                    </ul>
                                </CardContent>
                            </Card>


                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="area">{t.forms.areaLabel}</Label>
                                    <Input id="area" name="area" type="number" placeholder={t.forms.areaPlaceholder} required value={area} onChange={(e) => setArea(e.target.value)} className="bg-background/50 border-primary/30" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="date">Planting Start Date</Label>
                                    <Popover>
                                        <PopoverTrigger asChild>
                                        <Button
                                            variant={"outline"}
                                            className={cn(
                                            "w-full justify-start text-left font-normal bg-background/50 border-primary/30",
                                            !date && "text-muted-foreground"
                                            )}
                                        >
                                            <CalendarIcon className="mr-2 h-4 w-4" />
                                            {date ? format(date, "PPP") : <span>{t.forms.datePlaceholder}</span>}
                                        </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-auto p-0">
                                            <Calendar
                                                mode="single"
                                                selected={date}
                                                onSelect={setDate}
                                                initialFocus
                                            />
                                        </PopoverContent>
                                    </Popover>
                                </div>
                            </div>
                             <div className="space-y-2">
                                <Label htmlFor="organization">{t.forms.helperLabel}</Label>
                                <Select name="organization" required value={organization} onValueChange={setOrganization}>
                                    <SelectTrigger id="organization" className="bg-background/50 border-primary/30">
                                        <SelectValue placeholder={t.forms.helperPlaceholder} />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {serviceOrganizations.map(org => (
                                             <SelectItem key={org.id} value={org.id}>{org.name} - {org.location}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                             <div className="grid grid-cols-1 gap-4 text-center">
                                <InfoBox icon={<CircleDollarSign/>} title={t.forms.estimatedCost} value={`₹${totalCost.toLocaleString()}`} isAccent/>
                            </div>

                            <Button type="submit" className="w-full font-bold text-lg py-6" disabled={isPending || isUserLoading || !crop || !area || !date || !organization}>
                                {isPending ? t.forms.booking : 'Book Full Crop Plan'}
                            </Button>
                        </CardContent>
                    </form>
                </Card>
            </div>
        </>
    );
}

const InfoBox = ({ icon, title, value, isAccent }: { icon: React.ReactNode, title: string, value: string, isAccent?: boolean }) => (
    <div className="bg-background/30 p-4 rounded-lg">
        <div className={cn("flex items-center justify-center gap-2", isAccent ? "text-accent" : "text-primary")}>{icon}{title}</div>
        <p className={cn("text-2xl font-bold mt-2", isAccent ? "text-accent" : "text-foreground")}>{value}</p>
    </div>
);
