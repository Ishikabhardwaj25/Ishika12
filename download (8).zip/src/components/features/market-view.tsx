
"use client";

import { useState, useEffect } from 'react';
import { LineChart, ArrowUp, ArrowDown, Minus, Tag } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { getMandiPriceAction } from '@/app/actions';
import { cn } from '@/lib/utils';
import { produceData } from '@/lib/produce';

const trendIcons: { [key: string]: React.ReactNode } = {
  up: <ArrowUp className="w-5 h-5 text-green-500" />,
  down: <ArrowDown className="w-5 h-5 text-red-500" />,
  stable: <Minus className="w-5 h-5 text-gray-500" />,
};

type PriceData = {
    cropName: string;
    price: string;
    trend: 'up' | 'down' | 'stable';
};

export default function MarketView() {
    const [prices, setPrices] = useState<PriceData[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchAllPrices = async () => {
        setLoading(true);
        const pricePromises = produceData.map(p => {
            const formData = new FormData();
            formData.append('cropName', p.name);
            return getMandiPriceAction(formData);
        });

        const results = await Promise.all(pricePromises);
        const newPrices: PriceData[] = results
            .map((res, index) => {
                if(res.data) {
                    return {
                        cropName: produceData[index].name,
                        price: res.data.price,
                        trend: res.data.trend,
                    };
                }
                return null;
            })
            .filter((p): p is PriceData => p !== null);
        
        setPrices(newPrices);
        setLoading(false);
    };

    useEffect(() => {
        fetchAllPrices();
        const interval = setInterval(fetchAllPrices, 30000); // Auto-refresh every 30 seconds
        return () => clearInterval(interval);
    }, []);

    if (loading && prices.length === 0) {
        return (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array(6).fill(0).map((_, index) => (
                    <Card key={index} className="bg-card/50 border-primary/10 animate-pulse">
                        <CardHeader>
                            <div className="h-5 w-24 bg-muted rounded-md"></div>
                            <div className="h-4 w-32 bg-muted rounded-md mt-1"></div>
                        </CardHeader>
                        <CardContent>
                            <div className="h-8 w-28 bg-muted rounded-md"></div>
                            <div className="h-4 w-20 bg-muted rounded-md mt-2"></div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        );
    }
    
    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {prices.map((item) => (
                <Card key={item.cropName} className={cn(
                    "bg-card/50 border-primary/10 transition-all duration-300 animate-sprout-up",
                    item.trend === 'up' && 'border-green-500/30',
                    item.trend === 'down' && 'border-red-500/30',
                )}>
                    <CardHeader>
                        <CardTitle className="text-lg font-headline text-primary flex items-center gap-2"><Tag className='w-4 h-4' />{item.cropName}</CardTitle>
                        <CardDescription className="text-xs">Live Mandi Price</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="flex items-center gap-3">
                            {trendIcons[item.trend]}
                            <p className="text-2xl font-bold text-accent">{item.price}</p>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">per quintal</p>
                    </CardContent>
                </Card>
            ))}
        </div>
    );
}
