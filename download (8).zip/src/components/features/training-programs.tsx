
"use client";

import { useTransition } from "react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { trainingPrograms } from "@/lib/training";
import { Calendar, CircleDollarSign, Monitor, Users } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function TrainingPrograms() {
    const [isPending, startTransition] = useTransition();
    const { toast } = useToast();

    const handleEnroll = (programTitle: string) => {
        startTransition(() => {
            // Simulate enrollment process
            toast({
                title: "Enrollment Request Sent!",
                description: `You have requested to enroll in ${programTitle}.`,
            });
        });
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {trainingPrograms.map((program) => (
                <Card key={program.id} className="bg-card/50 border-primary/20 overflow-hidden flex flex-col animate-sprout-up">
                    <div className="relative w-full h-48">
                        <Image
                            src={program.imageUrl}
                            alt={program.title}
                            fill
                            className="object-cover"
                        />
                    </div>
                    <div className="p-4 flex flex-col flex-grow">
                        <CardTitle className="text-xl font-headline text-accent">{program.title}</CardTitle>
                        <CardDescription className="text-sm text-accent/80">{program.provider}</CardDescription>
                        <CardContent className="p-0 pt-4 flex-grow space-y-4">
                            <p className="text-sm text-foreground/90">{program.description}</p>
                            <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground">
                                <span className="flex items-center gap-1"><Calendar className="w-3 h-3"/> {program.duration}</span>
                                <span className="flex items-center gap-1">
                                    {program.format === "Online" ? <Monitor className="w-3 h-3"/> : <Users className="w-3 h-3"/>}
                                    {program.format}
                                </span>
                                <span className="flex items-center gap-1"><CircleDollarSign className="w-3 h-3"/> {program.cost}</span>
                            </div>
                        </CardContent>
                        <CardFooter className="p-0 pt-4 flex justify-end">
                            <Button
                                variant="outline"
                                className="border-accent/50 text-accent hover:bg-accent hover:text-accent-foreground"
                                onClick={() => handleEnroll(program.title)}
                                disabled={isPending}
                            >
                                {isPending ? "Enrolling..." : "Enroll Now"}
                            </Button>
                        </CardFooter>
                    </div>
                </Card>
            ))}
        </div>
    );
}
