
"use client";

import { useTransition } from 'react';
import { DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { User, Sprout, Tractor, Star, HandCoins, History, Mail } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '../ui/separator';
import { Button } from '../ui/button';
import { useUser } from '@/firebase';
import { useLanguage } from '@/context/language-context';
import { useToast } from '@/hooks/use-toast';
import { draftEmailFromNoteAction } from '@/app/actions';

const achievements = [
    { icon: <HandCoins className="w-4 h-4"/>, label: 'First Loan Approved' },
    { icon: <Star className="w-4 h-4"/>, label: 'Top Seller: Q2' },
    { icon: <Tractor className="w-4 h-4"/>, label: 'Early Adopter: Drone' },
];

const recentActivity = [
    { id: 1, action: 'Applied for Tractor Loan', date: '2 days ago', status: 'Approved' },
    { id: 2, action: 'Sold 50 Quintals of Onions', date: '5 days ago', status: 'Completed' },
    { id: 3, action: 'Booked Plowing Service', date: '1 week ago', status: 'Completed' },
    { id: 4, action: 'Diagnosed Tomato Leaf Blight', date: '2 weeks ago', status: 'Resolved' },
];

export default function ProfileDashboard() {
  const { user } = useUser();
  const { t } = useLanguage();
  const [isDrafting, startDrafting] = useTransition();
  const { toast } = useToast();

  const profile = {
    name: user?.isAnonymous ? 'Anonymous Farmer' : (user?.displayName || user?.email?.split('@')[0] || 'New Farmer'),
    email: user?.email || 'No email set',
    location: 'Nashik, Maharashtra',
    avatar: `https://picsum.photos/seed/${user?.uid || 'default'}/100/100`,
    farmSize: '15 Acres',
    primaryCrops: ['Grapes', 'Onions', 'Tomatoes'],
};

  const handleSendNote = () => {
    if (!user || user.isAnonymous || !user.email) {
      toast({
        variant: "destructive",
        title: "Login Required",
        description: "Please log in with an email account to send notes.",
      });
      return;
    }

    startDrafting(async () => {
      const formData = new FormData();
      formData.append('userName', profile.name);
      formData.append('userEmail', user.email!);

      const result = await draftEmailFromNoteAction(formData);

      if (result.error) {
        toast({
          variant: "destructive",
          title: "Error Drafting Email",
          description: result.error,
        });
      } else if (result.data?.mailtoLink) {
        // Open the user's default email client
        window.location.href = result.data.mailtoLink;
        toast({
          title: "Email Drafted!",
          description: "Your email client should now be open with the draft.",
        });
      }
    });
  };

  return (
    <DialogContent className="bg-background/80 border-accent text-foreground p-0 max-w-4xl w-[95vw] data-[state=open]:animate-sprout-up backdrop-blur-xl rounded-lg">
      <div className="max-h-[85vh] h-full flex flex-col">
      <DialogHeader className="p-6 border-b border-white/10 sticky top-0 bg-background/80 backdrop-blur-lg z-20">
        <div className="flex items-center gap-4">
          <User className="w-8 h-8 text-accent" />
          <div>
            <DialogTitle className="text-2xl font-headline text-accent">{t.myProfile.dialogTitle}</DialogTitle>
            <DialogDescription>{t.myProfile.dialogDescription}</DialogDescription>
          </div>
        </div>
      </DialogHeader>
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        <Card className="bg-card/50 border-primary/20">
            <CardContent className="pt-6 flex flex-col sm:flex-row items-center gap-4">
                 <Avatar className="w-20 h-20 border-2 border-primary">
                    <AvatarImage src={profile.avatar} alt={profile.name} />
                    <AvatarFallback><Sprout /></AvatarFallback>
                </Avatar>
                <div className="flex-1">
                    <h2 className="text-2xl font-bold font-headline text-primary text-center sm:text-left">{profile.name}</h2>
                    <p className="text-muted-foreground text-center sm:text-left">{user?.isAnonymous ? 'Anonymous User' : profile.email}</p>
                </div>
                 <Button onClick={handleSendNote} disabled={isDrafting}>
                  <Mail className="mr-2 h-4 w-4" />
                  {isDrafting ? 'Drafting...' : 'Send Note via Email'}
                </Button>
            </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-card/50 border-primary/20">
                <CardHeader>
                    <CardTitle className="font-headline text-lg text-primary">{t.myProfile.farmOverview}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                    <p><strong>Farm Size:</strong> {profile.farmSize}</p>
                    <p><strong>Primary Crops:</strong></p>
                    <div className="flex flex-wrap gap-2">
                        {profile.primaryCrops.map(crop => <Badge key={crop} variant="secondary">{crop}</Badge>)}
                    </div>
                </CardContent>
            </Card>
             <Card className="bg-card/50 border-primary/20">
                <CardHeader>
                    <CardTitle className="font-headline text-lg text-primary">{t.myProfile.achievements}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                    {achievements.map((ach, i) => (
                        <div key={i} className="flex items-center gap-3 text-sm">
                            <span className="text-accent">{ach.icon}</span>
                            <span>{ach.label}</span>
                        </div>
                    ))}
                </CardContent>
            </Card>
        </div>

        <Card className="bg-card/50 border-primary/20">
            <CardHeader>
                <CardTitle className="font-headline text-lg text-primary flex items-center gap-2"><History className="w-5 h-5"/>{t.myProfile.recentActivity}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                {recentActivity.map((activity, index) => (
                    <div key={activity.id}>
                        <div className="flex justify-between items-center">
                            <div>
                                <p className="font-semibold">{activity.action}</p>
                                <p className="text-xs text-muted-foreground">{activity.date}</p>
                            </div>
                            <Badge variant={activity.status === 'Approved' || activity.status === 'Completed' || activity.status === 'Resolved' ? 'default' : 'outline'}
                                className={
                                    activity.status === 'Approved' || activity.status === 'Completed' || activity.status === 'Resolved' 
                                    ? 'bg-green-500/80 border-transparent text-white' 
                                    : 'border-yellow-500/50 text-yellow-300'
                                }
                            >{activity.status}</Badge>
                        </div>
                         {index < recentActivity.length - 1 && <Separator className="mt-4 bg-border/50" />}
                    </div>
                ))}
            </CardContent>
        </Card>
      </div>
    </div>
    </DialogContent>
  );
}
