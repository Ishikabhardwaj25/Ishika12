"use client";

import { useTransition } from "react";
import Image from 'next/image';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { farmProducts } from "@/lib/farm-products";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function FarmStore() {
    const [isPending, startTransition] = useTransition();
    const { toast } = useToast();

    const handleBuy = (productName: string) => {
        startTransition(() => {
            toast({
                title: "Added to Cart!",
                description: `${productName} has been added to your cart.`,
            });
        });
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {farmProducts.map((product) => (
                <Card key={product.id} className="bg-card/50 border-primary/20 overflow-hidden flex flex-col animate-sprout-up">
                    <CardHeader className="p-0">
                         <div className="relative w-full h-40">
                            <Image
                                src={product.imageUrl}
                                alt={product.name}
                                fill
                                className="object-cover"
                            />
                        </div>
                    </CardHeader>
                    <CardContent className="p-4 flex-grow">
                        <Badge variant="outline" className="text-xs mb-2">{product.category}</Badge>
                        <h3 className="font-bold text-lg text-primary">{product.name}</h3>
                        <p className="text-sm text-muted-foreground mt-1">{product.description}</p>
                    </CardContent>
                    <CardFooter className="p-4 pt-0 flex justify-between items-center">
                        <p className="font-bold text-accent text-lg">{product.price}</p>
                        <Button onClick={() => handleBuy(product.name)} disabled={isPending}>
                            Buy Now
                        </Button>
                    </CardFooter>
                </Card>
            ))}
        </div>
    );
}
