import { DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Building2, MapPin, Phone } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { organizations } from "@/lib/organizations";


export default function LocalOrganizationsList() {
    return (
        <>
            <DialogHeader className="p-6 border-b border-white/10">
                <div className="flex items-center gap-4">
                    <Building2 className="w-8 h-8 text-accent" />
                    <div>
                        <DialogTitle className="text-2xl font-headline text-accent">Registered Local Organizations</DialogTitle>
                        <DialogDescription>Approved organizations in your area that distribute equipment or manage loans.</DialogDescription>
                    </div>
                </div>
            </DialogHeader>
            <div className="p-6">
                <Card className="bg-card/50 border-primary/20">
                    <CardContent className="space-y-4 pt-6">
                        {organizations.map((org, index) => (
                            <div key={index} className="p-4 bg-background/30 rounded-lg border border-primary/10 flex justify-between items-center">
                                <div>
                                    <h3 className="font-bold text-lg text-primary">{org.name}</h3>
                                    <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                                        <span className="flex items-center gap-1"><MapPin className="w-3 h-3"/> {org.location}</span>
                                        <span className="flex items-center gap-1"><Phone className="w-3 h-3"/> {org.contact}</span>
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                    {org.services.map(service => (
                                        <Badge key={service} variant="secondary" className="bg-accent/20 text-accent-foreground">{service}</Badge>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </div>
        </>
    );
}
