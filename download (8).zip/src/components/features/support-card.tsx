"use client";

import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import type { ReactNode } from 'react';

type SupportCardProps = {
  title: string;
  description: string;
  icon: ReactNode;
  children: ReactNode;
  className?: string;
};

export default function SupportCard({ title, description, icon, children, className }: SupportCardProps) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Card
          className={cn(
            "group bg-card/50 border-primary/20 hover:border-primary hover:bg-card/80 transition-all duration-300 cursor-pointer backdrop-blur-sm overflow-hidden transform hover:-translate-y-2 h-full flex flex-col justify-between",
            className
          )}
        >
          <CardHeader className="flex flex-col items-center text-center gap-4 p-6">
            <div className="text-primary group-hover:text-accent transition-colors duration-300">
              {icon}
            </div>
            <div>
              <CardTitle className="font-headline text-xl text-gray-100 group-hover:text-white transition-colors duration-300">{title}</CardTitle>
              <CardDescription className="text-primary/70 mt-1 text-sm">{description}</CardDescription>
            </div>
          </CardHeader>
        </Card>
      </DialogTrigger>
      <DialogContent className="bg-background/80 border-accent text-foreground p-0 max-w-2xl w-[95vw] data-[state=open]:animate-sprout-up backdrop-blur-xl rounded-lg">
        {children}
      </DialogContent>
    </Dialog>
  );
}
