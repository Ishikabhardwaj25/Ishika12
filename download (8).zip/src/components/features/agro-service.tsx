
"use client";

import { DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Tractor, Wrench, Sprout } from 'lucide-react';
import SupportCard from './support-card';
import ServiceBookingForm from './service-booking-form';
import FindLocalServices from './find-local-services';
import { useLanguage } from '@/context/language-context';

export default function AgroService() {
    const { t } = useLanguage();

    const serviceFeatures = [
        {
            title: "Book a Full Crop Plan",
            description: "End-to-end crop management, from seed to harvest.",
            icon: <Sprout className="w-12 h-12" />,
            content: <ServiceBookingForm />,
        },
        {
            title: "Book a Single Service",
            description: "Find local help for specific tasks like plowing or harvesting.",
            icon: <Wrench className="w-12 h-12" />,
            content: <FindLocalServices />,
        },
    ];

  return (
    <div className="max-h-[85vh] h-full flex flex-col">
      <DialogHeader className="p-6 border-b border-white/10 sticky top-0 bg-background/80 backdrop-blur-lg z-20">
        <div className="flex items-center gap-4">
          <Tractor className="w-8 h-8 text-accent" />
          <div>
            <DialogTitle className="text-2xl font-headline text-accent">{t.rentServices.dialogTitle}</DialogTitle>
            <DialogDescription>{t.rentServices.dialogDescription}</DialogDescription>
          </div>
        </div>
      </DialogHeader>
      <div className="flex-1 overflow-y-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {serviceFeatures.map((feature, index) => (
                <SupportCard
                    key={index}
                    title={feature.title}
                    description={feature.description}
                    icon={feature.icon}
                >
                    {feature.content}
                </SupportCard>
            ))}
        </div>
      </div>
    </div>
  );
}
