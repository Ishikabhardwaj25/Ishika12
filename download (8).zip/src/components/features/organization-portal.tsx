"use client";

import { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Label } from '../ui/label';
import { Button } from '../ui/button';
import { Building2, HandCoins, MapPin, Phone, Tractor } from 'lucide-react';
import { organizations, type Organization } from '@/lib/organizations';
import LoanRequestForm from './loan-request-form';
import EquipmentRentHub from './equipment-rent-hub';

export default function OrganizationPortal() {
    const [selectedOrgId, setSelectedOrgId] = useState<string>('');

    const selectedOrg = useMemo(() => {
        return organizations.find(org => org.id === selectedOrgId);
    }, [selectedOrgId]);

    return (
        <Card className="bg-card/50 border-primary/20">
            <CardHeader>
                <CardTitle className="font-headline text-lg text-primary flex items-center gap-2">
                    <Building2 className="w-5 h-5"/> Local Organization Portal
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                 <div className="space-y-2">
                    <Label htmlFor="organization-select">Select Your Nearest Organization</Label>
                    <Select value={selectedOrgId} onValueChange={setSelectedOrgId}>
                        <SelectTrigger id="organization-select" className="bg-background/50 border-primary/30">
                            <SelectValue placeholder="Choose an organization..." />
                        </SelectTrigger>
                        <SelectContent>
                            {organizations.map(org => (
                                <SelectItem key={org.id} value={org.id}>{org.name} - {org.location}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>

                {selectedOrg && (
                    <Card className="bg-background/50 border-primary/10 p-4 animate-sprout-up">
                        <CardHeader>
                            <CardTitle className="font-headline text-accent">{selectedOrg.name}</CardTitle>
                             <div className="flex items-center flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground mt-1">
                                <span className="flex items-center gap-1"><MapPin className="w-3 h-3"/> {selectedOrg.location}</span>
                                <span className="flex items-center gap-1"><Phone className="w-3 h-3"/> {selectedOrg.contact}</span>
                            </div>
                        </CardHeader>
                        <CardContent className="flex flex-col sm:flex-row gap-4">
                            {selectedOrg.services.includes("Loans") && <ServiceActionCard title="Apply for Loan" icon={<HandCoins />} content={<LoanRequestForm />} />}
                            {selectedOrg.services.includes("Equipment") && <ServiceActionCard title="Rent Equipment" icon={<Tractor />} content={<EquipmentRentHub />} />}
                        </CardContent>
                    </Card>
                )}
            </CardContent>
        </Card>
    );
}

const ServiceActionCard = ({ title, icon, content }: { title: string, icon: React.ReactNode, content: React.ReactNode }) => (
     <Dialog>
        <DialogTrigger asChild>
            <Button variant="outline" className="w-full h-auto flex flex-col gap-2 p-4 text-center border-dashed border-primary/50 hover:bg-primary/10 hover:border-primary">
                <div className="w-12 h-12 flex items-center justify-center text-primary bg-primary/10 rounded-full">{icon}</div>
                <span className="font-semibold">{title}</span>
            </Button>
        </DialogTrigger>
        <DialogContent className="bg-background/80 border-accent text-foreground p-0 max-w-2xl w-[95vw] data-[state=open]:animate-sprout-up backdrop-blur-xl rounded-lg">
           {content}
        </DialogContent>
    </Dialog>
);
