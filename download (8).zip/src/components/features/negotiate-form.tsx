"use client";

import { useState, useTransition } from "react";
import { DialogHeader, DialogTitle, DialogDescription, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "../ui/alert";
import type { Buyer } from "@/lib/buyers";
import { Handshake, CircleDollarSign, Weight, X } from "lucide-react";

export default function NegotiateForm({ buyer }: { buyer: Buyer }) {
    const [isPending, startTransition] = useTransition();
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<boolean>(false);
    const { toast } = useToast();

    const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        setError(null);
        setSuccess(false);

        const formData = new FormData(event.currentTarget);
        const proposedPrice = formData.get('proposedPrice');
        
        if (Number(proposedPrice) <= 0) {
            setError("Please enter a valid price.");
            return;
        }

        startTransition(async () => {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 1000));
            setSuccess(true);
            toast({
                title: "Offer Sent!",
                description: `Your offer has been sent to ${buyer.name}.`,
            });
        });
    };

    return (
        <>
            <DialogHeader className="p-6 border-b border-white/10">
                <div className="flex items-center gap-4">
                    <Handshake className="w-8 h-8 text-accent" />
                    <div>
                        <DialogTitle className="text-2xl font-headline text-accent">Negotiate with {buyer.name}</DialogTitle>
                        <DialogDescription>Propose your price for {buyer.crop}.</DialogDescription>
                    </div>
                </div>
            </DialogHeader>
            <div className="p-6">
                <Card className="bg-card/50 border-primary/20">
                    <form onSubmit={handleSubmit}>
                        <CardContent className="space-y-6 pt-6">
                             {error && (
                                <Alert variant="destructive">
                                    <AlertTitle>Error</AlertTitle>
                                    <AlertDescription>{error}</AlertDescription>
                                </Alert>
                            )}
                            {success ? (
                                <Alert className="border-green-500/50 bg-green-500/10 text-green-200 text-center">
                                    <AlertTitle className="text-green-400">Offer Sent Successfully!</AlertTitle>
                                    <AlertDescription>
                                        {buyer.name} has received your offer. You will be notified of their response.
                                    </AlertDescription>
                                    <DialogClose asChild>
                                        <Button variant="outline" className="mt-4">Close</Button>
                                    </DialogClose>
                                </Alert>
                            ) : (
                                <>
                                    <div className="grid grid-cols-2 gap-4 text-center">
                                        <InfoBox icon={<Weight/>} title="Required Qty" value={`${buyer.quantity} Quintals`} />
                                        <InfoBox icon={<CircleDollarSign/>} title="Buyer's Offer" value={`₹${buyer.price}/Quintal`} />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="proposedPrice">Your Proposed Price (₹ per Quintal)</Label>
                                        <Input
                                            id="proposedPrice"
                                            name="proposedPrice"
                                            type="number"
                                            placeholder={`e.g., ${buyer.price + 100}`}
                                            required
                                            className="bg-background/50 border-primary/30 text-center text-lg h-12"
                                        />
                                    </div>
                                    <Button type="submit" className="w-full font-bold text-lg py-6" disabled={isPending}>
                                        {isPending ? "Sending Offer..." : "Send Counter-Offer"}
                                    </Button>
                                </>
                            )}
                        </CardContent>
                    </form>
                </Card>
            </div>
        </>
    );
}


const InfoBox = ({ icon, title, value }: { icon: React.ReactNode, title: string, value: string }) => (
    <div className="bg-background/30 p-3 rounded-lg">
        <div className="flex items-center justify-center gap-2 text-primary text-sm">{icon}{title}</div>
        <p className="text-lg font-bold text-accent mt-1">{value}</p>
    </div>
)
