
"use client";

import { DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Rocket, Lightbulb, PlusCircle } from 'lucide-react';
import ExploreInnovations from './explore-innovations';
import SubmitInnovationForm from './submit-innovation-form';
import { useLanguage } from '@/context/language-context';
import SupportCard from './support-card';

export default function InnovationGarden() {
  const { t } = useLanguage();

  const features = [
    {
      title: t.newIdeas.exploreTitle,
      description: "See the latest in community-driven farming technology.",
      icon: <Lightbulb className="w-12 h-12" />,
      content: <div className="p-6"><ExploreInnovations /></div>,
    },
    {
      title: t.newIdeas.submitTitle,
      description: "Have a great idea? Share it with the community for a chance to get it featured.",
      icon: <PlusCircle className="w-12 h-12" />,
      content: <div className="p-6"><SubmitInnovationForm /></div>,
    }
  ]

  return (
    <div className="max-h-[85vh] h-full flex flex-col">
      <DialogHeader className="p-6 border-b border-border/10 sticky top-0 bg-background/80 backdrop-blur-lg z-20">
        <div className="flex items-center gap-4">
          <Rocket className="w-8 h-8 text-accent" />
          <div>
            <DialogTitle className="text-2xl font-headline text-accent">{t.newIdeas.dialogTitle}</DialogTitle>
            <DialogDescription>{t.newIdeas.dialogDescription}</DialogDescription>
          </div>
        </div>
      </DialogHeader>
      <div className="flex-1 overflow-y-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map((feature, index) => (
            <SupportCard
              key={index}
              title={feature.title}
              description={feature.description}
              icon={feature.icon}
            >
              <div className="max-h-[85vh] h-full flex flex-col">
                 <DialogHeader className="p-6 border-b border-white/10 sticky top-0 bg-background/80 backdrop-blur-lg z-20">
                    <div className="flex items-center gap-4">
                        <div className="text-accent">{feature.icon}</div>
                        <div>
                            <DialogTitle className="text-2xl font-headline text-accent">{feature.title}</DialogTitle>
                            <DialogDescription>{feature.description}</DialogDescription>
                        </div>
                    </div>
                </DialogHeader>
                <div className="flex-1 overflow-y-auto">
                    {feature.content}
                </div>
              </div>
            </SupportCard>
          ))}
        </div>
      </div>
    </div>
  );
}
