
"use client";

import { useState, useMemo } from 'react';
import Image from 'next/image';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { cropProblems, seasonalTips, type CropProblem } from '@/lib/crop-problems';
import { Button } from '../ui/button';
import { ArrowLeft, Search, Lightbulb, Shield, Heart, CloudRain, Rocket } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import ExploreInnovations from './explore-innovations';

export default function ProblemLibrary() {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedProblem, setSelectedProblem] = useState<CropProblem | null>(null);
    const [votes, setVotes] = useState<Record<string, number>>({'pest-attack': 132, 'drought': 98});

    const handleVote = (id: string) => {
        setVotes(prev => ({...prev, [id]: (prev[id] || 0) + 1}));
    };

    const filteredProblems = useMemo(() => {
        if (!searchTerm) return cropProblems;
        return cropProblems.filter(p => 
            p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
            p.symptoms.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()))
        );
    }, [searchTerm]);

    if (selectedProblem) {
        return (
            <div className="p-4 h-full animate-fade-in">
                <Button variant="ghost" onClick={() => setSelectedProblem(null)} className="mb-4">
                    <ArrowLeft className="mr-2 h-4 w-4" /> Back to Problem Library
                </Button>
                <Card className="bg-transparent border-0 shadow-none">
                    <CardHeader>
                        <DialogTitle className="font-headline text-2xl text-primary flex items-center gap-3">
                             <div className="w-16 h-16 rounded-lg overflow-hidden border-2 border-primary/20">
                                <Image src={selectedProblem.image} alt={selectedProblem.name} width={64} height={64} className="object-cover w-full h-full" />
                            </div>
                            {selectedProblem.name}
                        </DialogTitle>
                        <CardDescription>A step-by-step guide to identify and resolve the issue.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div>
                            <h3 className="font-bold mb-2">Symptoms to look for:</h3>
                            <div className="flex flex-wrap gap-2">
                                {selectedProblem.symptoms.map(symptom => (
                                    <Badge key={symptom} variant="outline" className="text-sm">{symptom}</Badge>
                                ))}
                            </div>
                        </div>

                        <div className="space-y-4">
                             {selectedProblem.solution.map(step => (
                                <div key={step.step} className="flex items-start gap-4">
                                    <div className="flex flex-col items-center gap-1">
                                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                                            <step.icon className="w-5 h-5" />
                                        </div>
                                         <span className="text-xs font-bold text-primary/80">Step {step.step}</span>
                                    </div>
                                    <div>
                                        <h4 className="font-bold">{step.title}</h4>
                                        <p className="text-sm text-muted-foreground">{step.description}</p>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <Dialog>
                            <DialogTrigger asChild>
                                <Card className="bg-primary/10 border-primary/20 p-4 mt-6 text-center cursor-pointer hover:bg-primary/20 transition-colors">
                                    <h3 className="font-bold text-primary flex items-center justify-center gap-2"><Lightbulb /> See how new innovations are solving this!</h3>
                                    <p className="text-sm text-primary/80">Explore "{selectedProblem.relatedInnovation.name}"</p>
                                </Card>
                            </DialogTrigger>
                             <DialogContent className="bg-background/80 border-accent text-foreground p-0 max-w-4xl w-[95vw] data-[state=open]:animate-sprout-up backdrop-blur-xl rounded-lg">
                                <DialogHeader className="p-6 border-b border-border/10 sticky top-0 bg-background/80 backdrop-blur-lg z-20">
                                    <div className="flex items-center gap-4">
                                    <Rocket className="w-8 h-8 text-accent" />
                                    <div>
                                        <DialogTitle className="text-2xl font-headline text-accent">Agri-Innovate Hub</DialogTitle>
                                        <DialogDescription>Explore the future of farming technology</DialogDescription>
                                    </div>
                                    </div>
                                </DialogHeader>
                                <div className='p-6'>
                                    <ExploreInnovations highlightId={selectedProblem.relatedInnovation.id}/>
                                </div>
                            </DialogContent>
                        </Dialog>

                         <div className="text-center mt-4">
                             <Button onClick={() => handleVote(selectedProblem.id)} size="lg">
                                <Heart className="w-5 h-5 mr-2 fill-pink-500 text-pink-500"/>
                                Vote for this Solution ({votes[selectedProblem.id] || 0})
                            </Button>
                             {(votes[selectedProblem.id] || 0) > 100 && 
                                <Badge className="ml-4 bg-yellow-400/80 text-yellow-900">Farmer's Pick</Badge>
                             }
                         </div>

                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="space-y-6 h-full">
            <CardHeader className="p-0">
                <CardTitle className="font-headline text-lg flex items-center gap-2">
                    <Shield className="w-6 h-6 text-primary" />
                    Crop Problem Library
                </CardTitle>
                <CardDescription>A farmer's guide to identifying and solving crop problems.</CardDescription>
            </CardHeader>

            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input 
                    type="text"
                    placeholder="Search problems like 'leaf holes' or 'yellow spots'..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-background/50 border-primary/30 focus:border-accent"
                />
            </div>
            
            <div>
                <h3 className="font-headline text-md text-primary mb-2">Problem Library</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {filteredProblems.map(problem => (
                        <Card 
                            key={problem.id} 
                            className="group bg-card/50 border-primary/10 overflow-hidden cursor-pointer hover:shadow-lg hover:border-primary/50 transition-all duration-300 transform hover:-translate-y-1"
                            onClick={() => setSelectedProblem(problem)}
                        >
                            <div className="relative h-24">
                                <Image src={problem.image} alt={problem.name} fill className="object-cover" />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                                <Badge variant="destructive" className="absolute top-2 right-2 text-xs bg-red-600/80">{problem.category}</Badge>
                            </div>
                            <CardContent className="p-3">
                                <h4 className="font-bold text-sm truncate group-hover:text-primary">{problem.name}</h4>
                            </CardContent>
                        </Card>
                    ))}
                    {filteredProblems.length === 0 && (
                        <p className="text-muted-foreground col-span-full text-center py-4">No problems found for "{searchTerm}".</p>
                    )}
                </div>
            </div>

            <div>
                <h3 className="font-headline text-md text-primary mb-2">Seasonal Tips</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {seasonalTips.map(tip => {
                        const Icon = tip.icon;
                        return (
                             <Card key={tip.id} className="bg-card/50 border-primary/10 p-4 flex items-center gap-4">
                                <div className="text-accent"><Icon className="w-8 h-8" /></div>
                                <div>
                                    <h4 className="font-bold">{tip.title}</h4>
                                    <p className="text-xs text-muted-foreground">{tip.description}</p>
                                </div>
                            </Card>
                        )
                    })}
                </div>
            </div>
        </div>
    );
}
