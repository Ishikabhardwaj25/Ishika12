"use client";

import Image from 'next/image';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { cropShieldInnovations } from "@/lib/crop-shields";
import { Badge } from '../ui/badge';
import { Heart, Award, Sun, Wind, Waves, Mic } from 'lucide-react';
import { useState, useMemo, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious, type CarouselApi } from '../ui/carousel';

export default function ExploreInnovations({ highlightId }: { highlightId?: string }) {
  const [votes, setVotes] = useState<Record<string, number>>({
    'eco-sonic': 125,
    'aqua-guard': 88,
    'solar-mist': 102,
    'bio-light': 75,
  });

  const [api, setApi] = useState<CarouselApi>()
  const [current, setCurrent] = useState(0)

  useEffect(() => {
    if (!api) return;

    if (highlightId) {
      const index = cropShieldInnovations.findIndex(i => i.id === highlightId);
      if (index !== -1) {
        api.scrollTo(index);
        setCurrent(index + 1)
      }
    } else {
        setCurrent(api.selectedScrollSnap() + 1);
    }
    
    api.on("select", () => {
      setCurrent(api.selectedScrollSnap() + 1)
    })
  }, [api, highlightId]);

  const handleVote = (id: string) => {
    setVotes(prev => ({...prev, [id]: (prev[id] || 0) + 1}));
  };

  const topInnovationId = useMemo(() => {
    return Object.entries(votes).reduce((top, current) => current[1] > top[1] ? current : top, ["", 0])[0];
  }, [votes]);

  return (
      <div className="w-full space-y-4">
        <Carousel setApi={setApi} className="w-full">
          <CarouselContent>
            {cropShieldInnovations.map((item) => (
               <CarouselItem key={item.id}>
                 <Card className="bg-gradient-to-br from-card/60 to-background/60 border-2 border-primary/20 overflow-hidden shadow-2xl shadow-primary/10">
                    <div className="grid md:grid-cols-2">
                        <div className="p-6 md:p-8 flex flex-col justify-center order-2 md:order-1">
                        {topInnovationId === item.id && (
                            <Badge variant="secondary" className="bg-yellow-400/20 text-yellow-300 border-yellow-500/50 w-fit mb-2 animate-pulse">
                                <Award className="w-4 h-4 mr-2" /> Top Innovation
                            </Badge>
                        )}
                        <h2 className="text-3xl font-headline text-primary mb-2 flex items-center gap-3">
                            <item.Icon className="w-8 h-8"/> {item.title}
                        </h2>
                        <p className="text-foreground/80 mb-4">{item.description}</p>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6">
                            <span className="flex items-center gap-1.5"><Sun className="w-4 h-4 text-yellow-400"/>Solar-Powered</span>
                            <span className="flex items-center gap-1.5"><Wind className="w-4 h-4 text-sky-300"/>Eco-Friendly</span>
                        </div>
                        <div className="flex items-center gap-4">
                            <Button onClick={() => handleVote(item.id)} size="lg">
                                <Heart className="w-5 h-5 mr-2 fill-pink-500 text-pink-500"/>
                                Vote ({votes[item.id]})
                            </Button>
                        </div>
                        </div>
                        <div className="relative min-h-[250px] md:min-h-0 order-1 md:order-2">
                            <Image src={item.imageUrl} alt={item.title} fill className="object-cover"/>
                            <div className="absolute inset-0 bg-gradient-to-t from-background/50 via-transparent to-transparent md:bg-gradient-to-l"></div>
                        </div>
                    </div>
                    </Card>
               </CarouselItem>
            ))}
          </CarouselContent>
           <CarouselPrevious className="left-2 bg-background/50 hover:bg-background" />
           <CarouselNext className="right-2 bg-background/50 hover:bg-background" />
        </Carousel>
        <div className="py-2 text-center text-sm text-muted-foreground">
            Slide {current} of {cropShieldInnovations.length}
        </div>
      </div>
    );
}