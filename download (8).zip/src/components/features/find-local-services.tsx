import { DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tractor, MapPin, Phone } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { organizations } from "@/lib/organizations";

const serviceProviders = organizations.filter(org => org.services.includes("Booking"));

export default function FindLocalServices() {
    return (
        <>
            <DialogHeader className="p-6 border-b border-white/10">
                <div className="flex items-center gap-4">
                    <Tractor className="w-8 h-8 text-accent" />
                    <div>
                        <DialogTitle className="text-2xl font-headline text-accent">Local Service Providers</DialogTitle>
                        <DialogDescription>Find FPOs and SHGs that offer farming services in your area.</DialogDescription>
                    </div>
                </div>
            </DialogHeader>
            <div className="p-6">
                <Card className="bg-card/50 border-primary/20">
                    <CardContent className="space-y-4 pt-6">
                        {serviceProviders.map((org, index) => (
                            <div key={index} className="p-4 bg-background/30 rounded-lg border border-primary/10 flex justify-between items-center">
                                <div>
                                    <h3 className="font-bold text-lg text-primary">{org.name}</h3>
                                    <div className="flex items-center flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground mt-1">
                                        <span className="flex items-center gap-1"><MapPin className="w-3 h-3"/> {org.location}</span>
                                        <span className="flex items-center gap-1"><Phone className="w-3 h-3"/> {org.contact}</span>
                                    </div>
                                    <div className="mt-2 flex flex-wrap gap-2">
                                        <Badge variant="secondary" className="bg-accent/20 text-accent-foreground">Plowing</Badge>
                                        <Badge variant="secondary" className="bg-accent/20 text-accent-foreground">Harvesting</Badge>
                                        <Badge variant="secondary" className="bg-accent/20 text-accent-foreground">Spraying</Badge>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </div>
        </>
    );
}
