
"use client";

import { useState } from 'react';
import { DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Network, Building, Landmark, University, Tractor, ArrowDown, BarChart, Building2, GanttChartSquare } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { useLanguage } from '@/context/language-context';
import { cn } from '@/lib/utils';
import { Bar, BarChart as RechartsBarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts';
import OrganizationPortal from './organization-portal';
import SupportCard from './support-card';
import LocalOrganizationsList from './local-organizations-list';
import TrackingPage from './tracking-page';

const fundingData = [
  { name: 'Nashik', 'State Funds': 4000, 'Central Funds': 2400, amt: 2400 },
  { name: 'Pune', 'State Funds': 3000, 'Central Funds': 1398, amt: 2210 },
  { name: 'Nagpur', 'State Funds': 2000, 'Central Funds': 9800, amt: 2290 },
  { name: 'Aurangabad', 'State Funds': 2780, 'Central Funds': 3908, amt: 2000 },
];


export default function GovernmentNetwork() {
  const { t } = useLanguage();
  const [activeLevel, setActiveLevel] = useState<string | null>(null);

  const levels = [
    { id: 'central', title: "Central Government", icon: <Landmark />, description: "Sets national policies, allocates major funds, and oversees large-scale agricultural projects." },
    { id: 'state', title: "State Government", icon: <Building />, description: "Implements state-specific schemes, manages fund distribution, and supports regional agricultural bodies." },
    { id: 'district', title: "District Organizations", icon: <University />, description: "Includes KVKs and local co-ops that directly provide training, resources, and last-mile support to farmers." },
    { id: 'farmer', title: "Farmers", icon: <Tractor />, description: "The beneficiaries who can apply for loans, rent equipment, and receive subsidies through this network." },
  ];
  
  const supportFeatures = [
    {
        title: t.governmentHelp.findOfficesTitle,
        description: t.governmentHelp.findOfficesDescription,
        icon: <Building2 className="w-12 h-12" />,
        content: <LocalOrganizationsList />,
    },
    {
        title: t.governmentHelp.checkStatusTitle,
        description: t.governmentHelp.checkStatusDescription,
        icon: <GanttChartSquare className="w-12 h-12" />,
        content: <TrackingPage />,
    },
];

  return (
    <div className="max-h-[85vh] h-full flex flex-col">
      <DialogHeader className="p-6 border-b border-white/10 sticky top-0 bg-background/80 backdrop-blur-lg z-20">
        <div className="flex items-center gap-4">
          <Network className="w-8 h-8 text-accent" />
          <div>
            <DialogTitle className="text-2xl font-headline text-accent">{t.governmentHelp.dialogTitle}</DialogTitle>
            <DialogDescription>{t.governmentHelp.dialogDescription}</DialogDescription>
          </div>
        </div>
      </DialogHeader>
      
      <div className="flex-1 overflow-y-auto p-6 space-y-8">
        {/* Local Organization Portal */}
        <OrganizationPortal />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {supportFeatures.map((feature, index) => (
                <SupportCard
                    key={index}
                    title={feature.title}
                    description={feature.description}
                    icon={feature.icon}
                >
                    {feature.content}
                </SupportCard>
            ))}
        </div>

        {/* Flow Visualization */}
        <Card className="bg-card/50 border-primary/20">
            <CardHeader>
                <CardTitle className="font-headline text-lg text-primary flex items-center gap-2"><Network className="w-5 h-5"/> Organizational Flow</CardTitle>
            </CardHeader>
            <CardContent className="relative space-y-2">
                 {levels.map((level, index) => (
                    <div key={level.id}>
                        <div
                            className={cn(
                                "p-4 rounded-lg border-2 flex items-center gap-4 cursor-pointer transition-all duration-300",
                                activeLevel === level.id ? 'bg-primary/20 border-primary' : 'bg-background/30 border-transparent hover:bg-primary/10'
                            )}
                            onClick={() => setActiveLevel(level.id === activeLevel ? null : level.id)}
                        >
                            <div className="w-10 h-10 flex items-center justify-center text-primary bg-primary/10 rounded-full">{level.icon}</div>
                            <h3 className="font-bold text-lg text-foreground">{level.title}</h3>
                        </div>
                        {activeLevel === level.id && (
                            <div className="p-4 bg-background/50 rounded-b-lg text-sm text-muted-foreground animate-sprout-up">
                               {level.description}
                            </div>
                        )}
                        {index < levels.length - 1 && (
                            <div className="flex justify-center h-8">
                                <ArrowDown className="w-5 h-5 text-primary/50" />
                            </div>
                        )}
                    </div>
                ))}
            </CardContent>
        </Card>

        {/* Funding Tracker */}
        <Card className="bg-card/50 border-primary/20">
            <CardHeader>
                <CardTitle className="font-headline text-lg text-primary flex items-center gap-2"><BarChart className="w-5 h-5"/> Smart Funding Tracker</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-sm text-muted-foreground mb-4">Visual representation of fund distribution across major districts.</p>
                <div style={{ width: '100%', height: 300 }}>
                    <ResponsiveContainer>
                        <RechartsBarChart data={fundingData}>
                            <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickFormatter={(value) => `₹${Number(value) / 1000}k`}/>
                            <Tooltip
                                contentStyle={{
                                    background: "hsl(var(--background))",
                                    border: "1px solid hsl(var(--border))",
                                    color: "hsl(var(--foreground))"
                                }}
                            />
                            <Bar dataKey="State Funds" stackId="a" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                            <Bar dataKey="Central Funds" stackId="a" fill="hsl(var(--accent))" radius={[4, 4, 0, 0]}/>
                        </RechartsBarChart>
                    </ResponsiveContainer>
                </div>
            </CardContent>
        </Card>

      </div>
    </div>
  );
}

    
