
"use client";

import { DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Store, ShoppingCart, CirclePlus, ShoppingBag, Handshake } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import MarketView from './market-view';
import SellProduceForm from './sell-produce-form';
import ReadyBuyers from './ready-buyers';
import FarmStore from './farm-store';
import { useLanguage } from '@/context/language-context';

export default function MagicalMarketplace() {
  const { t } = useLanguage();
  return (
    <div className="max-h-[85vh] h-full flex flex-col">
      <DialogHeader className="p-6 border-b border-white/10 sticky top-0 bg-background/80 backdrop-blur-lg z-20">
        <div className="flex items-center gap-4">
          <Store className="w-8 h-8 text-accent" />
          <div>
            <DialogTitle className="text-2xl font-headline text-accent">{t.marketplace.dialogTitle}</DialogTitle>
            <DialogDescription>{t.marketplace.dialogDescription}</DialogDescription>
          </div>
        </div>
      </DialogHeader>
      <div className="flex-1 overflow-y-auto">
        <Tabs defaultValue="market" className="h-full flex flex-col">
          <TabsList className="m-6 bg-primary/10 flex-wrap h-auto justify-start">
            <TabsTrigger value="market" className="gap-2">
              <ShoppingCart className="w-4 h-4" />
              {t.marketplace.marketPricesTitle}
            </TabsTrigger>
            <TabsTrigger value="sell" className="gap-2">
              <CirclePlus className="w-4 h-4" />
              {t.marketplace.sellProduceTitle}
            </TabsTrigger>
            <TabsTrigger value="buyers" className="gap-2">
              <Handshake className="w-4 h-4" />
              {t.marketplace.readyBuyersTitle}
            </TabsTrigger>
            <TabsTrigger value="store" className="gap-2">
              <ShoppingBag className="w-4 h-4" />
              {t.marketplace.farmStoreTitle}
            </TabsTrigger>
          </TabsList>
          <TabsContent value="market" className="flex-1 overflow-y-auto px-6 pb-6 mt-0">
            <MarketView />
          </TabsContent>
          <TabsContent value="sell" className="flex-1 overflow-y-auto px-6 pb-6 mt-0">
            <SellProduceForm />
          </TabsContent>
          <TabsContent value="buyers" className="flex-1 overflow-y-auto px-6 pb-6 mt-0">
            <ReadyBuyers />
          </TabsContent>
          <TabsContent value="store" className="flex-1 overflow-y-auto px-6 pb-6 mt-0">
            <FarmStore />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
