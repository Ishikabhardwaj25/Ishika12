"use client";

import { useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { jobs } from "@/lib/jobs";
import { MapPin, CircleDollarSign, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function FindJobs() {
    const [isPending, startTransition] = useTransition();
    const { toast } = useToast();

    const handleApply = (jobTitle: string) => {
        startTransition(() => {
            // In a real app, this would trigger a form or an API call.
            // For now, we just simulate success with a toast.
            toast({
                title: "Application Submitted!",
                description: `Your application for ${jobTitle} has been sent.`,
            });
        });
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {jobs.map((job) => (
                <Card key={job.id} className="bg-card/50 border-primary/20 overflow-hidden flex flex-col animate-sprout-up">
                    <CardHeader>
                        <CardTitle className="text-xl font-headline text-primary">{job.title}</CardTitle>

                        <CardDescription className="text-sm text-primary/80">{job.organization}</CardDescription>
                    </CardHeader>
                    <CardContent className="flex-grow space-y-4">
                        <p className="text-sm text-foreground/90">{job.description}</p>
                         <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1"><MapPin className="w-3 h-3"/> {job.location}</span>
                            <span className="flex items-center gap-1"><CircleDollarSign className="w-3 h-3"/> {job.salary}</span>
                            <span className="flex items-center gap-1"><Clock className="w-3 h-3"/> {job.type}</span>
                        </div>
                    </CardContent>
                    <CardFooter className="p-4 pt-0 flex justify-end">
                        <Button onClick={() => handleApply(job.title)} disabled={isPending}>
                            {isPending ? "Applying..." : "Apply Now"}
                        </Button>
                    </CardFooter>
                </Card>
            ))}
        </div>
    );
}
