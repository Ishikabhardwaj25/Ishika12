"use client";

import { useState, useTransition, useRef, useEffect } from 'react';
import { MessageSquare, Bot, User, Send, CornerDownLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { askChatAssistantAction } from '@/app/actions';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';

type Message = {
  role: 'user' | 'assistant';
  content: string;
};

export default function ChatAssistant() {
  const [isPending, startTransition] = useTransition();
  const [messages, setMessages] = useState<Message[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollAreaRef.current) {
        const viewport = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
        if (viewport) {
            viewport.scrollTop = viewport.scrollHeight;
        }
    }
  }, [messages]);

  const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!query.trim()) return;

    setError(null);
    const userMessage: Message = { role: 'user', content: query };
    setMessages(prev => [...prev, userMessage]);
    setQuery('');

    const formData = new FormData();
    formData.append('query', query);

    startTransition(async () => {
      const response = await askChatAssistantAction(formData);
      if (response.error) {
        setError(response.error);
        const errorMessage: Message = { role: 'assistant', content: `Sorry, something went wrong. ${response.error}`};
        setMessages(prev => [...prev, errorMessage]);
      } else if (response.data) {
        const assistantMessage: Message = { role: 'assistant', content: response.data.response };
        setMessages(prev => [...prev, assistantMessage]);
      }
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleFormSubmit(e as any);
    }
  };

  return (
    <div className="h-full p-4 flex flex-col">
      <Card className="bg-transparent border-0 shadow-none h-full flex flex-col">
        <CardHeader className="p-0 pb-4">
          <CardTitle className="font-headline text-lg flex items-center gap-2">
            <MessageSquare className="w-6 h-6 text-primary" />
            AI Chat Assistant
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 flex-grow flex flex-col">
          <ScrollArea className="flex-grow rounded-md border border-primary/20 p-4 bg-background/30" ref={scrollAreaRef}>
            <div className="space-y-4">
              {messages.map((msg, index) => (
                <div
                  key={index}
                  className={cn(
                    "flex items-start gap-3 animate-sprout-up",
                    msg.role === 'user' ? 'justify-end' : 'justify-start'
                  )}
                >
                  {msg.role === 'assistant' && (
                    <AvatarIcon className="bg-accent text-accent-foreground">
                      <Bot />
                    </AvatarIcon>
                  )}
                  <div
                    className={cn(
                      "max-w-[80%] rounded-lg p-3 text-sm whitespace-pre-line",
                      msg.role === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-card/70'
                    )}
                  >
                    {msg.content}
                  </div>
                   {msg.role === 'user' && (
                    <AvatarIcon className="bg-primary/20 text-primary-foreground">
                      <User />
                    </AvatarIcon>
                  )}
                </div>
              ))}
               {isPending && (
                    <div className="flex items-start gap-3 justify-start">
                        <AvatarIcon className="bg-accent text-accent-foreground">
                            <Bot />
                        </AvatarIcon>
                        <div className="bg-card/70 rounded-lg p-3">
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                <span className="h-2 w-2 bg-accent rounded-full animate-pulse delay-0"></span>
                                <span className="h-2 w-2 bg-accent rounded-full animate-pulse delay-150"></span>
                                <span className="h-2 w-2 bg-accent rounded-full animate-pulse delay-300"></span>
                            </div>
                        </div>
                    </div>
                )}
               {messages.length === 0 && !isPending && (
                  <div className="text-center text-primary/60 py-8">
                    <MessageSquare className="mx-auto w-12 h-12 mb-2"/>
                    <p className="font-medium">Ask KrishiBot anything!</p>
                    <p className="text-xs">e.g., "Which crop can I grow in Maharashtra in June?"</p>
                  </div>
                )}
            </div>
          </ScrollArea>
          <form onSubmit={handleFormSubmit} className="mt-4">
            <div className="relative">
                <Textarea
                    id="query"
                    name="query"
                    placeholder="Ask a question..."
                    required
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    onKeyDown={handleKeyDown}
                    className="bg-background/50 border-primary/30 focus:border-accent pr-24"
                    rows={1}
                />
                <Button type="submit" size="icon" disabled={isPending || !query.trim()} className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 bg-primary hover:bg-primary/90">
                    <Send className="h-4 w-4"/>
                </Button>
                 <p className="absolute right-12 top-1/2 -translate-y-1/2 text-xs text-muted-foreground hidden md:block">
                  <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground opacity-100">
                    <CornerDownLeft className="w-3 h-3" />
                  </kbd>
                </p>
            </div>
             {error && (
              <Alert variant="destructive" className="mt-2">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

const AvatarIcon = ({ children, className }: { children: React.ReactNode, className?: string }) => (
    <div className={cn("w-8 h-8 rounded-full flex items-center justify-center shrink-0", className)}>
        {children}
    </div>
);
