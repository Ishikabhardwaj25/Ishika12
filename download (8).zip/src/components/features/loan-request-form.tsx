
"use client";

import { useState, useTransition } from "react";
import { DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { HandCoins } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "../ui/alert";
import { organizations } from "@/lib/organizations";
import { useUser, useFirestore } from "@/firebase";
import { useLanguage } from "@/context/language-context";
import { submitLoanRequest } from "@/firebase/firestore/mutations";

const loanOrganizations = organizations.filter(org => org.services.includes("Loans"));

export default function LoanRequestForm() {
    const { t } = useLanguage();
    const [isPending, startTransition] = useTransition();
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<boolean>(false);
    const { toast } = useToast();
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();

    const [purpose, setPurpose] = useState("");
    const [amount, setAmount] = useState("");
    const [duration, setDuration] = useState("");
    const [organization, setOrganization] = useState("");


    const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        if (!user || !firestore) {
            setError("You must be logged in to submit a request.");
            return;
        }

        setError(null);
        setSuccess(false);

        const loanData = {
            purpose: purpose,
            amount: Number(amount),
            duration: Number(duration),
            organizationId: organization,
        };


        startTransition(async () => {
           try {
                await submitLoanRequest(firestore, user.uid, loanData);
                setSuccess(true);
                setPurpose("");
                setAmount("");
                setDuration("");
                setOrganization("");
                toast({
                    title: "Application Sent!",
                    description: "Your loan request has been sent.",
                });
           } catch (e: any) {
                setError(e.message);
           }
        });
    };


    return (
        <>
            <DialogHeader className="p-6 border-b border-white/10">
                <div className="flex items-center gap-4">
                    <HandCoins className="w-8 h-8 text-accent" />
                    <div>
                        <DialogTitle className="text-2xl font-headline text-accent">{t.forms.loanRequestTitle}</DialogTitle>
                        <DialogDescription>{t.forms.loanRequestDescription}</DialogDescription>
                    </div>
                </div>
            </DialogHeader>
            <div className="p-6">
                <Card className="bg-card/50 border-primary/20">
                    <form onSubmit={handleSubmit}>
                        <CardContent className="space-y-6 pt-6">
                             {error && (
                                <Alert variant="destructive">
                                    <AlertTitle>{t.forms.error}</AlertTitle>
                                    <AlertDescription>{error}</AlertDescription>
                                </Alert>
                            )}
                            {success && (
                                <Alert className="border-green-500/50 bg-green-500/10 text-green-200">
                                    <AlertTitle className="text-green-400">{t.forms.success}</AlertTitle>
                                    <AlertDescription>Your application has been sent. Check the status on the tracking page.</AlertDescription>
                                </Alert>
                            )}
                            <div className="space-y-2">
                                <Label htmlFor="purpose">{t.forms.loanPurposeLabel}</Label>
                                <Select name="purpose" required value={purpose} onValueChange={setPurpose}>
                                    <SelectTrigger id="purpose" className="bg-background/50 border-primary/30">
                                        <SelectValue placeholder={t.forms.loanPurposePlaceholder} />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="crop">{t.forms.purposeCrop}</SelectItem>
                                        <SelectItem value="tractor">{t.forms.purposeTractor}</SelectItem>
                                        <SelectItem value="seeds">{t.forms.purposeSeeds}</SelectItem>
                                        <SelectItem value="irrigation">{t.forms.purposeIrrigation}</SelectItem>
                                        <SelectItem value="other">{t.forms.purposeOther}</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="amount">{t.forms.amountLabel}</Label>
                                    <Input id="amount" name="amount" type="number" placeholder={t.forms.amountPlaceholder} required value={amount} onChange={(e) => setAmount(e.target.value)} className="bg-background/50 border-primary/30" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="duration">{t.forms.durationLabel}</Label>
                                    <Input id="duration" name="duration" type="number" placeholder={t.forms.durationPlaceholder} required value={duration} onChange={(e) => setDuration(e.target.value)} className="bg-background/50 border-primary/30" />
                                </div>
                            </div>
                             <div className="space-y-2">
                                <Label htmlFor="organization">{t.forms.officeLabel}</Label>
                                <Select name="organization" required value={organization} onValueChange={setOrganization}>
                                    <SelectTrigger id="organization" className="bg-background/50 border-primary/30">
                                        <SelectValue placeholder={t.forms.officePlaceholder} />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {loanOrganizations.map(org => (
                                             <SelectItem key={org.id} value={org.id}>{org.name} - {org.location}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <Button type="submit" className="w-full font-bold text-lg py-6" disabled={isPending || isUserLoading}>
                                {isPending ? t.forms.sending : t.forms.applyButton}
                            </Button>
                        </CardContent>
                    </form>
                </Card>
            </div>
        </>
    );
}
