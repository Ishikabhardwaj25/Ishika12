import { DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Sprout } from 'lucide-react';
import type { ReactNode } from 'react';

export default function PlaceholderFeature({ title, description, icon }: { title: string; description: string; icon: ReactNode }) {
  return (
    <div>
      <DialogHeader className="p-6 border-b border-white/10">
        <div className="flex items-center gap-4">
          <div className="text-accent">{icon}</div>
          <div>
            <DialogTitle className="text-2xl font-headline text-accent">{title}</DialogTitle>
            <DialogDescription>{description}</DialogDescription>
          </div>
        </div>
      </DialogHeader>
      <div className="p-20 text-center flex flex-col items-center gap-4">
        <Sprout className="w-16 h-16 text-primary/50 animate-pulse" />
        <h3 className="text-lg font-bold text-primary">Feature coming soon!</h3>
        <p className="text-primary/70">This area is under cultivation.</p>
      </div>
    </div>
  );
}
