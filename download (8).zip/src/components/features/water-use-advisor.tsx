"use client";

import { useState, useTransition } from 'react';
import { Droplets, CalendarClock, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Label } from '@/components/ui/label';
import { getWaterUseAdviceAction } from '@/app/actions';
import type { WaterUseAdvisorOutput } from '@/ai/flows/water-use-advisor';

const ResultCard = ({ icon, title, content }: { icon: React.ReactNode, title: string, content: string }) => (
    <Card className="bg-card/50 border-primary/10 animate-sprout-up">
      <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
        <div className="text-accent">{icon}</div>
        <CardTitle className="text-base font-headline text-accent/80">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-foreground whitespace-pre-line">{content}</p>
      </CardContent>
    </Card>
);

export default function WaterUseAdvisor() {
  const [isPending, startTransition] = useTransition();
  const [result, setResult] = useState<WaterUseAdvisorOutput | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [formValues, setFormValues] = useState({
      location: '',
      cropType: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormValues(prev => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setResult(null);

    const formData = new FormData();
    formData.append('location', formValues.location);
    formData.append('cropType', formValues.cropType);

    startTransition(async () => {
      const response = await getWaterUseAdviceAction(formData);
      if (response.error) {
        setError(response.error);
      } else if (response.data) {
        setResult(response.data);
      }
    });
  };

  return (
    <div className="space-y-6 h-full p-4">
      <Card className="bg-transparent border-0 shadow-none h-full flex flex-col">
        <CardHeader className="p-0 pb-4">
          <CardTitle className="font-headline text-lg flex items-center gap-2">
            <Droplets className="w-6 h-6 text-primary" />
            Water Use Advisor
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 flex-grow">
          <form onSubmit={handleFormSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="location">Your Location</Label>
                <Input
                  id="location"
                  name="location"
                  type="text"
                  placeholder="e.g., Pune, Maharashtra"
                  required
                  value={formValues.location}
                  onChange={handleInputChange}
                  className="bg-background/50 border-primary/30 focus:border-accent"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cropType">Crop Type</Label>
                <Input
                  id="cropType"
                  name="cropType"
                  type="text"
                  placeholder="e.g., Sugarcane, Onion"
                  required
                  value={formValues.cropType}
                  onChange={handleInputChange}
                  className="bg-background/50 border-primary/30 focus:border-accent"
                />
              </div>
              <Button type="submit" disabled={isPending || !formValues.location || !formValues.cropType} className="w-full mt-4 bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-lg py-6">
                {isPending ? 'Calculating...' : 'Get Watering Advice'}
              </Button>
            </div>
            
            <div className="flex flex-col">
              <div className="flex-grow space-y-4 min-h-[250px] flex flex-col justify-center">
                {error && (
                  <Alert variant="destructive">
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {isPending && (
                    <div className="flex flex-col items-center justify-center h-full gap-4 text-primary">
                        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-accent"></div>
                        <p className="font-headline text-lg">KrishiBot is analyzing weather data...</p>
                        <p className="text-sm text-primary/70">This might take a moment.</p>
                    </div>
                )}
                
                {result && !isPending && (
                  <div className="space-y-4 animate-fade-in">
                    <h3 className="text-xl font-headline text-accent">Watering Plan</h3>
                    <ResultCard icon={<Droplets />} title="Weekly Water Requirement" content={result.waterRequirement} />
                    <ResultCard icon={<Info />} title="Watering Advice" content={result.advice} />
                    <ResultCard icon={<CalendarClock />} title="Next Watering Schedule" content={result.nextWateringSchedule} />
                  </div>
                )}
                 {!result && !isPending && !error && (
                  <div className="flex flex-col items-center justify-center h-full gap-4 text-primary/50 text-center p-8">
                     <Droplets className="w-16 h-16" />
                    <p className="font-headline text-lg">Your watering advice will appear here.</p>
                    <p className="text-sm">Enter your location and crop to get started.</p>
                  </div>
                )}
              </div>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
