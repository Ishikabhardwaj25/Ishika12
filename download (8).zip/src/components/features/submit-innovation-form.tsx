
"use client";

import { useState, useTransition, ChangeEvent, useRef } from "react";
import Image from 'next/image';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "../ui/alert";
import { UploadCloud, X } from "lucide-react";
import { Progress } from "../ui/progress";
import { useUser, useFirestore } from "@/firebase";
import { submitInnovation } from "@/firebase/firestore/mutations";

export default function SubmitInnovationForm() {
    const [isPending, startTransition] = useTransition();
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<boolean>(false);
    const { toast } = useToast();
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();

    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    const [imageUri, setImageUri] = useState<string | null>(null);
    const [uploadProgress, setUploadProgress] = useState(0);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleImageChange = (e: ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            if (file.size > 4 * 1024 * 1024) { // 4MB limit
                setError("Image size cannot exceed 4MB.");
                return;
            }
            setError(null);
            const reader = new FileReader();
            reader.onprogress = (event) => {
                if (event.lengthComputable) {
                const progress = (event.loaded / event.total) * 100;
                setUploadProgress(progress);
                }
            };
            reader.onloadend = () => {
                setImageUri(reader.result as string);
                setUploadProgress(100);
            };
            reader.readAsDataURL(file);
        }
    };

    const clearImage = () => {
        setImageUri(null);
        setUploadProgress(0);
        if(fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        if (!user || !firestore) {
            setError("You must be logged in to submit an innovation.");
            return;
        }

        setError(null);
        setSuccess(false);

        const innovationData = {
            title,
            description,
            imageUri: imageUri || undefined,
        };

        startTransition(async () => {
            try {
                await submitInnovation(firestore, user.uid, innovationData);
                setSuccess(true);
                setTitle("");
                setDescription("");
                clearImage();
                toast({
                    title: "Submission Received!",
                    description: "Your innovation has been sent for approval. Thank you!",
                });
            } catch (e: any) {
                setError(e.message);
            }
        });
    };

    return (
        <form onSubmit={handleSubmit}>
            <Card className="bg-card/50 border-primary/20">
                <CardContent className="space-y-6 pt-6">
                    {error && (
                        <Alert variant="destructive">
                            <AlertTitle>Submission Failed</AlertTitle>
                            <AlertDescription>{error}</AlertDescription>
                        </Alert>
                    )}
                    {success && (
                        <Alert className="border-green-500/50 bg-green-500/10 text-green-200">
                            <AlertTitle className="text-green-400">Thank You!</AlertTitle>
                            <AlertDescription>Your idea has been submitted for review.</AlertDescription>
                        </Alert>
                    )}
                    <div className="space-y-2">
                        <Label htmlFor="title">Innovation Title</Label>
                        <Input id="title" name="title" placeholder="e.g., Solar-Powered Automated Irrigation" required value={title} onChange={(e) => setTitle(e.target.value)} className="bg-background/50 border-primary/30" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="description">Detailed Description</Label>
                        <Textarea id="description" name="description" placeholder="Describe your idea, its benefits, and how it works..." required value={description} onChange={(e) => setDescription(e.target.value)} className="bg-background/50 border-primary/30 min-h-[120px]" />
                    </div>
                    <div className="space-y-2">
                        <Label>Attach an Image (Optional)</Label>
                        <div className="relative p-2 aspect-video w-full border-2 border-dashed border-primary/30 rounded-lg flex items-center justify-center bg-background/50 overflow-hidden">
                            {imageUri ? (
                            <>
                                <Image src={imageUri} alt="Innovation preview" fill className="object-contain" />
                                <Button type="button" size="icon" variant="destructive" className="absolute top-2 right-2 z-10 h-8 w-8" onClick={clearImage}>
                                <X className="h-4 w-4" />
                                </Button>
                            </>
                            ) : (
                            <label htmlFor="innovation-image" className="text-center cursor-pointer p-4">
                                <UploadCloud className="mx-auto h-10 w-10 text-primary/50" />
                                <p className="mt-2 text-sm text-primary/70">Click to upload an image or sketch</p>
                                <p className="text-xs text-primary/50">PNG or JPG, up to 4MB</p>
                            </label>
                            )}
                            <input id="innovation-image" type="file" className="sr-only" accept="image/png, image/jpeg" onChange={handleImageChange} ref={fileInputRef}/>
                        </div>
                        {uploadProgress > 0 && uploadProgress < 100 && (
                            <Progress value={uploadProgress} className="h-2 bg-primary/20" />
                        )}
                    </div>
                    <Button type="submit" className="w-full font-bold text-lg py-6" disabled={isPending || isUserLoading}>
                        {isPending ? "Submitting..." : "Submit for Approval"}
                    </Button>
                </CardContent>
            </Card>
        </form>
    );
}
