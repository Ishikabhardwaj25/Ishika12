"use client";

import { useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cooperatives } from "@/lib/cooperatives";
import { MapPin, ShieldCheck, Award } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "../ui/badge";

export default function JoinCooperative() {
    const [isPending, startTransition] = useTransition();
    const { toast } = useToast();

    const handleApply = (cooperativeName: string) => {
        startTransition(() => {
            // Simulate API call for application
            toast({
                title: "Application Sent!",
                description: `Your application to join ${cooperativeName} has been submitted for review.`,
            });
        });
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {cooperatives.map((coop) => (
                <Card key={coop.id} className="bg-card/50 border-primary/20 overflow-hidden flex flex-col animate-sprout-up">
                    <CardHeader className="flex flex-row items-start gap-4">
                        <Avatar className="w-16 h-16 border-2 border-primary/50">
                            <AvatarImage src={coop.avatarUrl} alt={coop.name} />
                            <AvatarFallback>{coop.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                            <CardTitle className="text-xl font-headline text-primary">{coop.name}</CardTitle>
                            <CardDescription className="text-sm text-primary/80 flex items-center gap-1 mt-1">
                                <MapPin className="w-4 h-4"/> {coop.location}
                            </CardDescription>
                        </div>
                    </CardHeader>
                    <CardContent className="flex-grow space-y-4">
                        <p className="text-sm text-foreground/90 italic">"{coop.mission}"</p>
                        
                        <div className="space-y-2">
                             <h4 className="font-semibold text-sm flex items-center gap-2"><ShieldCheck className="text-accent"/>Qualifications to Join</h4>
                             <ul className="list-disc list-inside text-xs text-muted-foreground space-y-1">
                                {coop.requirements.map(req => <li key={req}>{req}</li>)}
                             </ul>
                        </div>
                         <div className="space-y-2">
                             <h4 className="font-semibold text-sm flex items-center gap-2"><Award className="text-accent"/>Membership Benefits</h4>
                             <div className="flex flex-wrap gap-2">
                                {coop.benefits.map(benefit => <Badge key={benefit} variant="secondary" className="bg-accent/10 text-accent-foreground border-accent/20">{benefit}</Badge>)}
                             </div>
                        </div>

                    </CardContent>
                    <CardFooter className="p-4 pt-0">
                        <Button onClick={() => handleApply(coop.name)} disabled={isPending} className="w-full">
                            {isPending ? "Applying..." : "Apply for Membership"}
                        </Button>
                    </CardFooter>
                </Card>
            ))}
        </div>
    );
}
