
"use client";

import { useState, useTransition } from 'react';
import { TestTube, GitBranch, ChevronsRight, FlaskConical, CircleDollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { calculateFertilizerAction } from '@/app/actions';
import type { FertilizerCalculatorOutput } from '@/ai/flows/fertilizer-calculator';

const ResultCard = ({ icon, title, content }: { icon: React.ReactNode, title: string, content: string }) => (
    <Card className="bg-card/50 border-primary/10 animate-sprout-up">
      <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
        <div className="text-accent">{icon}</div>
        <CardTitle className="text-base font-headline text-accent/80">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-foreground whitespace-pre-line">{content}</p>
      </CardContent>
    </Card>
);

export default function FertilizerCalculator() {
  const [isPending, startTransition] = useTransition();
  const [result, setResult] = useState<FertilizerCalculatorOutput | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [formValues, setFormValues] = useState({
      landArea: '',
      areaUnit: 'acres',
      cropType: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormValues(prev => ({ ...prev, [name]: value }));
  };
  
  const handleUnitChange = (value: string) => {
    setFormValues(prev => ({ ...prev, areaUnit: value }));
  };

  const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setResult(null);

    const formData = new FormData();
    formData.append('landArea', formValues.landArea);
    formData.append('areaUnit', formValues.areaUnit);
    formData.append('cropType', formValues.cropType);

    startTransition(async () => {
      const response = await calculateFertilizerAction(formData);
      if (response.error) {
        setError(response.error);
      } else if (response.data) {
        setResult(response.data);
      }
    });
  };

  return (
    <div className="space-y-6 h-full p-4">
      <Card className="bg-transparent border-0 shadow-none h-full flex flex-col">
        <CardHeader className="p-0 pb-4">
          <CardTitle className="font-headline text-lg flex items-center gap-2">
            <TestTube className="w-6 h-6 text-primary" />
            Fertilizer Calculator
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 flex-grow">
          <form onSubmit={handleFormSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="landArea">Land Area</Label>
                <Input
                  id="landArea"
                  name="landArea"
                  type="number"
                  placeholder="e.g., 5.5"
                  required
                  value={formValues.landArea}
                  onChange={handleInputChange}
                  className="bg-background/50 border-primary/30 focus:border-accent"
                />
              </div>
              <div className="space-y-2">
                <Label>Unit</Label>
                 <RadioGroup defaultValue="acres" name="areaUnit" value={formValues.areaUnit} onValueChange={handleUnitChange} className="flex gap-4">
                    <div className="flex items-center space-x-2">
                        <RadioGroupItem value="acres" id="acres" />
                        <Label htmlFor="acres">Acres</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <RadioGroupItem value="hectares" id="hectares" />
                        <Label htmlFor="hectares">Hectares</Label>
                    </div>
                </RadioGroup>
              </div>
               <div className="space-y-2">
                <Label htmlFor="cropType">Crop Type</Label>
                <Input
                  id="cropType"
                  name="cropType"
                  type="text"
                  placeholder="e.g., Wheat, Tomato"
                  required
                  value={formValues.cropType}
                  onChange={handleInputChange}
                  className="bg-background/50 border-primary/30 focus:border-accent"
                />
              </div>
                <Button type="submit" disabled={isPending || !formValues.landArea || !formValues.cropType} className="w-full mt-4 bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-lg py-6">
                {isPending ? 'Calculating...' : 'Calculate Fertilizer'}
              </Button>
            </div>
            
            <div className="flex flex-col">
              <div className="flex-grow space-y-4 min-h-[250px] flex flex-col justify-center">
                {error && (
                  <Alert variant="destructive">
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {isPending && (
                    <div className="flex flex-col items-center justify-center h-full gap-4 text-primary">
                        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-accent"></div>
                        <p className="font-headline text-lg">KrishiBot is calculating...</p>
                        <p className="text-sm text-primary/70">This might take a moment.</p>
                    </div>
                )}
                
                {result && !isPending && (
                  <div className="space-y-4 animate-fade-in">
                    <h3 className="text-xl font-headline text-accent">AI Recommendation</h3>
                    <ResultCard icon={<FlaskConical />} title="Fertilizer Type" content={result.fertilizerType} />
                    <ResultCard icon={<GitBranch />} title="Required Quantity" content={result.quantity} />
                    <ResultCard icon={<CircleDollarSign />} title="Estimated Cost" content={result.estimatedCost} />
                    <ResultCard icon={<ChevronsRight />} title="Application Schedule" content={result.applicationSchedule} />
                  </div>
                )}
                 {!result && !isPending && !error && (
                  <div className="flex flex-col items-center justify-center h-full gap-4 text-primary/50 text-center p-8">
                     <TestTube className="w-16 h-16" />
                    <p className="font-headline text-lg">Your fertilizer plan will appear here.</p>
                    <p className="text-sm">Enter your land area and crop type to get started.</p>
                  </div>
                )}
              </div>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
