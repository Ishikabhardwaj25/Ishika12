
"use client";

import { useState, useTransition, useMemo } from "react";
import { DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tractor, Percent, CalendarDays, CircleDollarSign } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "../ui/alert";
import { organizations } from "@/lib/organizations";
import { useUser, useFirestore } from "@/firebase";
import { useLanguage } from "@/context/language-context";
import { rentEquipment } from "@/firebase/firestore/mutations";

const equipmentData: { [key: string]: { name: string; subsidy: number; } } = {
    tractor: { name: "Tractor", subsidy: 40 },
    harvester: { name: "Harvester", subsidy: 35 },
    drone: { name: "Farming Drone", subsidy: 50 },
    plough: { name: "Plough", subsidy: 45 },
    rotavator: { name: "Rotavator", subsidy: 40 },
    seedDrill: { name: "Seed Drill", subsidy: 55 },
    sprayer: { name: "Power Sprayer", subsidy: 30 },
    transplanter: { name: "Transplanter", subsidy: 50 },
    cultivator: { name: "Cultivator", subsidy: 40 },
    waterPump: { name: "Water Pump", subsidy: 60 },
    thresher: { name: "Thresher", subsidy: 35 },
    reaper: { name: "Reaper", subsidy: 35 },
    laserLeveler: { name: "Laser Land Leveler", subsidy: 65 },
};

const equipmentOrganizations = organizations.filter(org => org.services.includes("Equipment"));

export default function EquipmentRentHub() {
    const { t } = useLanguage();
    const [isPending, startTransition] = useTransition();
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<boolean>(false);
    const { toast } = useToast();
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();

    const [equipment, setEquipment] = useState("tractor");
    const [duration, setDuration] = useState("1");
    const [durationUnit, setDurationUnit] = useState("months");
    const [organizationId, setOrganizationId] = useState("");

    const selectedEquipment = equipmentData[equipment];
    const selectedOrganization = useMemo(() => {
        return organizations.find(org => org.id === organizationId);
    }, [organizationId]);

    const rentPerMonth = useMemo(() => {
        if (!selectedOrganization || !selectedOrganization.rates || !(equipment in selectedOrganization.rates)) return 0;
        return selectedOrganization.rates[equipment as keyof typeof selectedOrganization.rates] || 0;
    }, [selectedOrganization, equipment]);


    const calculateTotal = () => {
        if (!rentPerMonth || !duration) return 0;
        const numericDuration = Number(duration);
        let totalMonths = 0;
        if (durationUnit === 'days') totalMonths = numericDuration / 30;
        if (durationUnit === 'months') totalMonths = numericDuration;
        if (durationUnit === 'year') totalMonths = numericDuration * 12;
        return totalMonths * rentPerMonth;
    };
    
    const dailyRate = rentPerMonth ? (rentPerMonth / 30).toFixed(2) : "0.00";

    const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        if (!user || !firestore) {
            setError("You must be logged in to submit a request.");
            return;
        }

        setError(null);
        setSuccess(false);

        const rentalData = {
            equipmentType: equipment,
            duration: Number(duration),
            durationUnit: durationUnit,
            organizationId: organizationId,
        };

        startTransition(async () => {
            try {
                rentEquipment(firestore, user.uid, rentalData);
                setSuccess(true);
                toast({
                    title: "Rental Request Sent!",
                    description: `${selectedEquipment.name} has been requested for ${duration} ${durationUnit}.`,
                });
            } catch (e: any) {
                 setError(e.message);
            }
        });
    }

    const availableEquipmentForOrg = useMemo(() => {
        if (!selectedOrganization) return Object.keys(equipmentData);
        return Object.keys(equipmentData).filter(eq => selectedOrganization.rates && eq in selectedOrganization.rates);
    }, [selectedOrganization]);

    return (
         <>
            <DialogHeader className="p-6 border-b border-white/10">
                <div className="flex items-center gap-4">
                    <Tractor className="w-8 h-8 text-accent" />
                    <div>
                        <DialogTitle className="text-2xl font-headline text-accent">{t.forms.rentToolsDialogTitle}</DialogTitle>
                        <DialogDescription>{t.forms.rentToolsDialogDescription}</DialogDescription>
                    </div>
                </div>
            </DialogHeader>
            <div className="p-6">
                <form onSubmit={handleSubmit}>
                    <Card className="bg-card/50 border-primary/20">
                        <CardContent className="space-y-6 pt-6">
                             {error && (
                                <Alert variant="destructive">
                                    <AlertTitle>{t.forms.error}</AlertTitle>
                                    <AlertDescription>{error}</AlertDescription>
                                </Alert>
                            )}
                            {success && (
                                <Alert className="border-green-500/50 bg-green-500/10 text-green-200">
                                    <AlertTitle className="text-green-400">{t.forms.success}</AlertTitle>
                                    <AlertDescription>Your rental request has been sent. Check the tracking page for status.</AlertDescription>
                                </Alert>
                            )}
                            <div className="space-y-2">
                                <Label htmlFor="organization">{t.forms.officeLabel}</Label>
                                <Select name="organization" required value={organizationId} onValueChange={setOrganizationId}>
                                    <SelectTrigger id="organization" className="bg-background/50 border-primary/30">
                                        <SelectValue placeholder={t.forms.officePlaceholder} />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {equipmentOrganizations.map(org => (
                                             <SelectItem key={org.id} value={org.id}>{org.name} - {org.location}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            
                            <div className="space-y-2">
                                <Label htmlFor="equipment">{t.forms.toolLabel}</Label>
                                <Select name="equipment" value={equipment} onValueChange={setEquipment} required disabled={!organizationId}>
                                    <SelectTrigger id="equipment" className="bg-background/50 border-primary/30" >
                                        <SelectValue placeholder={t.forms.toolPlaceholder} />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {availableEquipmentForOrg.map(key => (
                                             <SelectItem key={key} value={key}>{equipmentData[key].name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                {!organizationId && <p className="text-xs text-muted-foreground">Please select an office first.</p>}
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="duration">{t.forms.howLongLabel}</Label>
                                    <Input id="duration" name="duration" type="number" placeholder="e.g. 7" required value={duration} onChange={e => setDuration(e.target.value)} className="bg-background/50 border-primary/30" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="durationUnit">{t.forms.durationUnitLabel}</Label>
                                    <Select name="durationUnit" value={durationUnit} onValueChange={setDurationUnit} required>
                                        <SelectTrigger id="durationUnit" className="bg-background/50 border-primary/30">
                                            <SelectValue/>
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="days">{t.forms.days}</SelectItem>
                                            <SelectItem value="months">{t.forms.months}</SelectItem>
                                            <SelectItem value="year">{t.forms.year}</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                                <InfoBox icon={<CircleDollarSign/>} title={t.forms.totalRent} value={organizationId ? `₹${calculateTotal().toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : 'N/A'} />
                                <InfoBox icon={<Percent/>} title={t.forms.govtDiscount} value={organizationId ? `${selectedEquipment.subsidy}%` : 'N/A'} />
                                <InfoBox icon={<CalendarDays/>} title={t.forms.costPerDay} value={organizationId ? `₹${dailyRate}/day` : 'N/A'} />
                            </div>

                            <Button type="submit" className="w-full font-bold text-lg py-6" disabled={isPending || isUserLoading || !equipment || !duration || !organizationId}>
                                {isPending ? t.forms.sending : t.forms.rentButton}
                            </Button>
                        </CardContent>
                    </Card>
                </form>
            </div>
        </>
    );
}

const InfoBox = ({ icon, title, value }: { icon: React.ReactNode, title: string, value: string }) => (
    <div className="bg-background/30 p-4 rounded-lg">
        <div className="flex items-center justify-center gap-2 text-primary">{icon}{title}</div>
        <p className="text-2xl font-bold text-accent mt-2">{value}</p>
    </div>
)

    
