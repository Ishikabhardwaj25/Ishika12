"use client";

import { useState, useTransition } from 'react';
import { Cloud, Sun, CloudSun, CloudRain, CloudLightning, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Label } from '@/components/ui/label';
import { getWeatherForecastAction } from '@/app/actions';
import type { WeatherForecastOutput } from '@/ai/flows/weather-forecast';

const weatherIcons: { [key: string]: React.ReactNode } = {
  Sunny: <Sun className="w-10 h-10 text-yellow-400" />,
  PartlyCloudy: <CloudSun className="w-10 h-10 text-gray-400" />,
  Cloudy: <Cloud className="w-10 h-10 text-gray-500" />,
  Rainy: <CloudRain className="w-10 h-10 text-blue-400" />,
  Stormy: <CloudLightning className="w-10 h-10 text-purple-400" />,
};

export default function WeatherForecast() {
  const [isPending, startTransition] = useTransition();
  const [result, setResult] = useState<WeatherForecastOutput | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [location, setLocation] = useState('');

  const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setResult(null);

    const formData = new FormData();
    formData.append('location', location);

    startTransition(async () => {
      const response = await getWeatherForecastAction(formData);
      if (response.error) {
        setError(response.error);
      } else if (response.data) {
        setResult(response.data);
      }
    });
  };

  return (
    <div className="space-y-6 h-full p-4">
      <Card className="bg-transparent border-0 shadow-none h-full flex flex-col">
        <CardHeader className="p-0 pb-4">
          <CardTitle className="font-headline text-lg flex items-center gap-2">
            <Cloud className="w-6 h-6 text-primary" />
            7-Day Weather Forecast
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 flex-grow flex flex-col">
          <form onSubmit={handleFormSubmit} className="space-y-4">
            <div className="flex gap-2">
              <div className="w-full space-y-2">
                <Label htmlFor="location">Enter your location</Label>
                <Input
                  id="location"
                  name="location"
                  type="text"
                  placeholder="e.g., your city or district"
                  required
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="bg-background/50 border-primary/30 focus:border-accent"
                />
              </div>
              <div className="self-end">
                <Button type="submit" disabled={isPending || !location} className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold">
                  {isPending ? 'Forecasting...' : 'Get Forecast'}
                </Button>
              </div>
            </div>
          </form>

          <div className="flex-grow space-y-4 mt-6 flex flex-col justify-center">
            {error && (
              <Alert variant="destructive">
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {isPending && (
              <div className="flex flex-col items-center justify-center h-full gap-4 text-primary animate-pulse">
                <Cloud className="w-16 h-16 text-accent" />
                <p className="font-headline text-lg">KrishiBot is checking the skies...</p>
              </div>
            )}

            {result && !isPending && (
              <div className="animate-fade-in space-y-4">
                 <Alert className="border-accent/50 bg-accent/10">
                  <Info className="h-4 w-4 text-accent" />
                  <AlertTitle className="font-headline text-accent">Farming Summary</AlertTitle>
                  <AlertDescription className="text-foreground/90">
                    {result.summary}
                  </AlertDescription>
                </Alert>
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-4 text-center">
                  {result.forecast.map((day, index) => (
                    <Card key={index} className="bg-card/50 border-primary/20 p-4 flex flex-col items-center justify-between animate-sprout-up" style={{ animationDelay: `${index * 100}ms`}}>
                      <p className="font-bold font-headline text-primary">{day.day}</p>
                      <div className="my-2">
                        {weatherIcons[day.icon] || <Sun className="w-10 h-10" />}
                      </div>
                      <p className="font-semibold text-lg">{day.temperature}</p>
                      <p className="text-sm text-muted-foreground">{day.condition}</p>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {!result && !isPending && !error && (
              <div className="flex flex-col items-center justify-center h-full gap-4 text-primary/50 text-center p-8">
                <CloudSun className="w-20 h-20" />
                <p className="font-headline text-lg">Your 7-day forecast will appear here.</p>
                <p className="text-sm">Enter a location to get started.</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
