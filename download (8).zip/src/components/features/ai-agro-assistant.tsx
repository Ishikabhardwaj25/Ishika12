
"use client";

import { useState } from 'react';
import { Bot, Leaf, Droplets, Cloud, Tag, Layers, TestTube, MessageSquare, Shield } from 'lucide-react';
import CropProtectionCenter from './crop-protection-center';
import FertilizerCalculator from './fertilizer-calculator';
import WeatherForecast from './weather-forecast';
import SoilHealthGuide from './soil-health-guide';
import WaterUseAdvisor from './water-use-advisor';
import ChatAssistant from './chat-assistant';
import { cn } from '@/lib/utils';
import { Button } from '../ui/button';
import { useLanguage } from '@/context/language-context';
import CharacterAnimation from '../dashboard/character-animation';
import { Card } from '../ui/card';

export default function AiAgroAssistant() {
  const { t } = useLanguage();
  const [activeFeature, setActiveFeature] = useState('chat-assistant');
  
  const features = [
    { id: 'chat-assistant', title: t.aiAssistant.featureChatAssistant, icon: <MessageSquare className="w-5 h-5" />, component: <ChatAssistant /> },
    { id: 'crop-protection', title: 'Crop Protection', icon: <Shield className="w-5 h-5" />, component: <CropProtectionCenter /> },
    { id: 'fertilizer-calculator', title: t.aiAssistant.featureFertilizerCalculator, icon: <TestTube className="w-5 h-5" />, component: <FertilizerCalculator /> },
    { id: 'weather-forecast', title: t.aiAssistant.featureWeatherForecast, icon: <Cloud className="w-5 h-5" />, component: <WeatherForecast /> },
    { id: 'soil-health', title: t.aiAssistant.featureSoilHealth, icon: <Layers className="w-5 h-5" />, component: <SoilHealthGuide /> },
    { id: 'water-advisor', title: t.aiAssistant.featureWaterAdvisor, icon: <Droplets className="w-5 h-5" />, component: <WaterUseAdvisor /> },
  ];

  const ActiveComponent = features.find(f => f.id === activeFeature)?.component || null;

  return (
    <Card className="bg-card/60 border border-border/50 backdrop-blur-sm overflow-hidden shadow-lg h-full flex flex-col md:flex-row">
      <div className="md:w-1/3 p-4 flex flex-col justify-center items-center">
        <CharacterAnimation />
      </div>

      <div className="md:w-2/3 flex flex-col">
        <div className="p-4 border-b md:border-b-0 md:border-l border-border/30">
            <div className="flex flex-wrap gap-2 justify-center">
                {features.map((feature) => (
                <Button
                    key={feature.id}
                    onClick={() => setActiveFeature(feature.id)}
                    variant={activeFeature === feature.id ? 'default' : 'ghost'}
                    size="sm"
                    className={cn(
                        "flex-1 justify-center gap-2 transition-all duration-200",
                         activeFeature === feature.id
                            ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/20'
                            : 'hover:bg-muted/50'
                    )}
                >
                    {feature.icon}
                    <span className="font-medium text-xs hidden sm:inline">{feature.title}</span>
                </Button>
                ))}
            </div>
        </div>
        
        <div className="flex-1 overflow-y-auto relative border-t md:border-t-0 md:border-l border-border/30">
          <div className="p-1 md:p-2 h-full min-h-[400px]">
            {ActiveComponent}
          </div>
        </div>
      </div>
    </Card>
  );
}
