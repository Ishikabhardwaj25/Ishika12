
"use client";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, Microscope } from 'lucide-react';
import ProblemLibrary from "./problem-library";
import CropDoctor from "./crop-doctor";


export default function CropProtectionCenter() {

    return (
        <div className="h-full p-4">
             <Tabs defaultValue="library" className="h-full flex flex-col">
                <TabsList className="bg-primary/10">
                    <TabsTrigger value="library" className="gap-2">
                        <Shield className="w-4 h-4" />
                        Problem Library
                    </TabsTrigger>
                    <TabsTrigger value="doctor" className="gap-2">
                        <Microscope className="w-4 h-4" />
                        AI Crop Doctor
                    </TabsTrigger>
                </TabsList>
                <TabsContent value="library" className="flex-1 overflow-y-auto mt-4">
                    <ProblemLibrary />
                </TabsContent>
                <TabsContent value="doctor" className="flex-1 overflow-y-auto mt-4">
                    <CropDoctor />
                </TabsContent>
            </Tabs>
        </div>
    );
}
