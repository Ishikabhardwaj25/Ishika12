
"use client";

import { useState, useTransition, ChangeEvent, useRef } from "react";
import Image from 'next/image';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "../ui/alert";
import { UploadCloud, X } from "lucide-react";
import { Progress } from "../ui/progress";
import { produceData } from "@/lib/produce";
import { useUser, useFirestore } from "@/firebase";
import { listProduceForSale } from "@/firebase/firestore/mutations";
import { Textarea } from "../ui/textarea";

export default function SellProduceForm() {
    const [isPending, startTransition] = useTransition();
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<boolean>(false);
    const { toast } = useToast();
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();

    const [formState, setFormState] = useState({
        cropType: "",
        grade: "A",
        quantity: "",
        price: "",
        description: "",
    });
    const [imageUri, setImageUri] = useState<string | null>(null);
    const [uploadProgress, setUploadProgress] = useState(0);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormState(prev => ({...prev, [name]: value}));
    };
    
    const handleSelectChange = (name: string, value: string) => {
        setFormState(prev => ({...prev, [name]: value}));
    };

    const handleImageChange = (e: ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            if (file.size > 4 * 1024 * 1024) { // 4MB limit
                setError("Image size cannot exceed 4MB.");
                return;
            }
            setError(null);
            const reader = new FileReader();
            reader.onprogress = (event) => {
                if (event.lengthComputable) {
                const progress = (event.loaded / event.total) * 100;
                setUploadProgress(progress);
                }
            };
            reader.onloadend = () => {
                setImageUri(reader.result as string);
                setUploadProgress(100);
            };
            reader.readAsDataURL(file);
        }
    };

    const clearImage = () => {
        setImageUri(null);
        setUploadProgress(0);
        if(fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        if (!user || !firestore) {
            setError("You must be logged in to sell produce.");
            return;
        }
        setError(null);
        setSuccess(false);

        const offerData = {
            cropType: formState.cropType,
            quality: formState.grade,
            quantity: Number(formState.quantity),
            price: Number(formState.price),
            description: formState.description,
            imageUri: imageUri || undefined,
        };

        startTransition(async () => {
            try {
                await listProduceForSale(firestore, user.uid, offerData);
                setSuccess(true);
                setFormState({ cropType: "", grade: "A", quantity: "", price: "", description: "" });
                clearImage();
                toast({
                    title: "Produce Listed!",
                    description: "Your produce has been successfully listed on the marketplace.",
                });
            } catch (e: any) {
                setError(e.message);
            }
        });
    };

    return (
        <form onSubmit={handleSubmit}>
            <Card className="bg-card/50 border-primary/20 max-w-2xl mx-auto">
                <CardContent className="space-y-6 pt-6">
                    {error && (
                        <Alert variant="destructive">
                            <AlertTitle>Listing Failed</AlertTitle>
                            <AlertDescription>{error}</AlertDescription>
                        </Alert>
                    )}
                    {success && (
                        <Alert className="border-green-500/50 bg-green-500/10 text-green-200">
                            <AlertTitle className="text-green-400">Success!</AlertTitle>
                            <AlertDescription>Your produce is now live on the marketplace.</AlertDescription>
                        </Alert>
                    )}
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="cropType">Crop Type</Label>
                            <Select name="cropType" required value={formState.cropType} onValueChange={(v) => handleSelectChange('cropType', v)}>
                                <SelectTrigger id="cropType" className="bg-background/50 border-primary/30">
                                    <SelectValue placeholder="Select crop..." />
                                </SelectTrigger>
                                <SelectContent>
                                    {produceData.map(p => (
                                        <SelectItem key={p.id} value={p.name}>{p.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="grade">Quality Grade</Label>
                            <Select name="grade" required value={formState.grade} onValueChange={(v) => handleSelectChange('grade', v)}>
                                <SelectTrigger id="grade" className="bg-background/50 border-primary/30">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="A">Grade A (Premium)</SelectItem>
                                    <SelectItem value="B">Grade B (Standard)</SelectItem>
                                    <SelectItem value="C">Grade C (Fair)</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="quantity">Quantity (in Quintals)</Label>
                            <Input id="quantity" name="quantity" type="number" placeholder="e.g., 50" required value={formState.quantity} onChange={handleInputChange} className="bg-background/50 border-primary/30" />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="price">Expected Price (₹ per Quintal)</Label>
                            <Input id="price" name="price" type="number" placeholder="e.g., 2200" required value={formState.price} onChange={handleInputChange} className="bg-background/50 border-primary/30" />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="description">Description (Optional)</Label>
                        <Textarea
                            id="description"
                            name="description"
                            placeholder="e.g., 'Organically grown, fresh from our farm in Nashik.'"
                            value={formState.description}
                            onChange={handleInputChange}
                            className="bg-background/50 border-primary/30"
                        />
                    </div>

                    <div className="space-y-2">
                        <Label>Produce Image (Optional)</Label>
                        <div className="relative p-2 aspect-video w-full border-2 border-dashed border-primary/30 rounded-lg flex items-center justify-center bg-background/50 overflow-hidden">
                            {imageUri ? (
                            <>
                                <Image src={imageUri} alt="Produce preview" fill className="object-contain" />
                                <Button type="button" size="icon" variant="destructive" className="absolute top-2 right-2 z-10 h-8 w-8" onClick={clearImage}>
                                <X className="h-4 w-4" />
                                </Button>
                            </>
                            ) : (
                            <label htmlFor="produce-image" className="text-center cursor-pointer p-4">
                                <UploadCloud className="mx-auto h-10 w-10 text-primary/50" />
                                <p className="mt-2 text-sm text-primary/70">Click to upload an image</p>
                                <p className="text-xs text-primary/50">PNG or JPG, up to 4MB</p>
                            </label>
                            )}
                            <input id="produce-image" type="file" className="sr-only" accept="image/png, image/jpeg" onChange={handleImageChange} ref={fileInputRef}/>
                        </div>
                        {uploadProgress > 0 && uploadProgress < 100 && (
                            <Progress value={uploadProgress} className="h-2 bg-primary/20" />
                        )}
                    </div>

                    <Button type="submit" className="w-full font-bold text-lg py-6" disabled={isPending || isUserLoading}>
                        {isPending ? "Listing your produce..." : "List on Marketplace"}
                    </Button>
                </CardContent>
            </Card>
        </form>
    );
}
