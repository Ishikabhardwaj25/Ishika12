"use server";

import { z } from 'zod';
import { initializeFirebase } from '@/firebase/server-init';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';

const emailSchema = z.string().email({ message: "Invalid email address." });
const passwordSchema = z.string().min(6, { message: "Password must be at least 6 characters long." });

const SignUpSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
});

export async function signUpAction(formData: FormData) {
  const rawInput = {
    email: formData.get('email'),
    password: formData.get('password'),
  };

  const validation = SignUpSchema.safeParse(rawInput);
  if (!validation.success) {
    const errorMessages = validation.error.issues.map(issue => issue.message).join(' ');
    return { error: `Invalid input: ${errorMessages}` };
  }

  const { auth } = initializeFirebase();
  const { email, password } = validation.data;

  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    return { data: { message: "Successfully registered!", userId: userCredential.user.uid } };
  } catch (e: any) {
    if (e.code === 'auth/email-already-in-use') {
        return { error: 'This email is already registered. Please log in instead.' };
    }
    return { error: e.message || "An unknown error occurred during sign-up." };
  }
}


const SignInSchema = z.object({
    email: emailSchema,
    password: z.string().min(1, { message: "Password is required."}),
});

export async function signInAction(formData: FormData) {
    const rawInput = {
        email: formData.get('email'),
        password: formData.get('password'),
    };
    
    const validation = SignInSchema.safeParse(rawInput);
    if (!validation.success) {
        const errorMessages = validation.error.issues.map(issue => issue.message).join(' ');
        return { error: `Invalid input: ${errorMessages}` };
    }

    const { auth } = initializeFirebase();
    const { email, password } = validation.data;

    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        return { data: { message: "Successfully logged in!", userId: userCredential.user.uid } };
    } catch (e: any) {
         if (e.code === 'auth/user-not-found') {
            return { error: 'This account is not registered. Please sign up instead.' };
        }
         if (e.code === 'auth/invalid-credential' || e.code === 'auth/wrong-password') {
            return { error: 'Invalid email or password. Please try again.' };
        }
        return { error: e.message || "An unknown error occurred during sign-in." };
    }
}
