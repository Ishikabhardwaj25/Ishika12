import Header from '@/components/layout/header';
import Dashboard from '@/components/dashboard/dashboard';
import { Leaf } from '@/components/ui/leaf';

export default function Home() {
  return (
    <div className="relative flex flex-col min-h-screen w-full overflow-x-hidden">
      {/* New Multicolor Animated Gradient Background */}
      <div className="absolute inset-0 -z-20 w-full h-full bg-gradient-to-br from-green-200 via-sky-200 to-amber-200 dark:from-green-900/50 dark:via-sky-900/50 dark:to-amber-900/50 animate-background-pan" />
      <div className="absolute inset-0 -z-10 bg-grid-pattern opacity-10" />

      {/* Animated Floating Leaves */}
      <Leaf className="absolute top-[5%] -left-4 w-24 h-24" style={{ animationDelay: '0s', animationDuration: '15s' }} />
      <Leaf className="absolute top-[20%] right-[5%] w-16 h-16" style={{ animationDelay: '3s', animationDuration: '12s' }} />
      <Leaf className="absolute bottom-[10%] left-[10%] w-20 h-20" style={{ animationDelay: '5s', animationDuration: '10s' }} />
      <Leaf className="absolute bottom-[5%] -right-2 w-28 h-28" style={{ animationDelay: '8s', animationDuration: '18s' }} />
      <Leaf className="absolute top-[40%] left-[30%] w-16 h-16" style={{ animationDelay: '10s', animationDuration: '20s' }} />
      <Leaf className="absolute top-[60%] right-[35%] w-24 h-24" style={{ animationDelay: '12s', animationDuration: '14s' }} />

      <Header />
      <main className="flex-1 flex flex-col items-center justify-center p-4 md:p-8 pt-24 md:pt-32">
        <Dashboard />
      </main>
    </div>
  );
}
