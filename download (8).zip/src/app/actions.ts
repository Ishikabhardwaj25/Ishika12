
"use server";

import { diagnoseCropDisease } from "@/ai/flows/crop-doctor-disease-diagnosis";
import type { DiagnoseCropDiseaseInput } from "@/ai/flows/crop-doctor-disease-diagnosis";
import { calculateFertilizer } from "@/ai/flows/fertilizer-calculator";
import type { FertilizerCalculatorInput } from "@/ai/flows/fertilizer-calculator";
import { getWeatherForecast } from "@/ai/flows/weather-forecast";
import type { WeatherForecastInput } from "@/ai/flows/weather-forecast";
import { getMandiPrice } from "@/ai/flows/mandi-prices";
import type { MandiPriceInput } from "@/ai/flows/mandi-prices";
import { getSoilHealthGuide } from "@/ai/flows/soil-health-guide";
import type { SoilHealthGuideInput } from "@/ai/flows/soil-health-guide";
import { getWaterUseAdvice } from "@/ai/flows/water-use-advisor";
import type { WaterUseAdvisorInput } from "@/ai/flows/water-use-advisor";
import { askChatAssistant } from "@/ai/flows/chat-assistant";
import type { ChatAssistantInput } from "@/ai/flows/chat-assistant";
import { generateEmail } from "@/ai/flows/generate-email";
import { z } from "zod";
import { listProduceForSale } from "@/firebase/firestore/mutations";
import fs from 'fs/promises';
import path from 'path';

const DiagnoseActionInputSchema = z.object({
  photoDataUri: z.string().min(1, { message: "Photo is required." }),
  description: z.string(),
});

export async function diagnoseCropDiseaseAction(formData: FormData) {
  const rawInput = {
    photoDataUri: formData.get('photoDataUri'),
    description: formData.get('description'),
  };

  const validation = DiagnoseActionInputSchema.safeParse(rawInput);

  if (!validation.success) {
    return { error: "Invalid input.", details: validation.error.format() };
  }

  const input: DiagnoseCropDiseaseInput = validation.data;
  
  try {
    const result = await diagnoseCropDisease(input);
    return { data: result };
  } catch (e) {
    console.error(e);
    return { error: "An unexpected error occurred during diagnosis." };
  }
}

const FertilizerActionInputSchema = z.object({
    landArea: z.coerce.number().min(0.1, { message: "Land area is required." }),
    areaUnit: z.enum(['acres', 'hectares']),
    cropType: z.string().min(1, { message: "Crop type is required." }),
});

export async function calculateFertilizerAction(formData: FormData) {
    const rawInput = {
        landArea: formData.get('landArea'),
        areaUnit: formData.get('areaUnit'),
        cropType: formData.get('cropType'),
    };

    const validation = FertilizerActionInputSchema.safeParse(rawInput);

    if (!validation.success) {
        return { error: "Invalid input.", details: validation.error.format() };
    }

    const input: FertilizerCalculatorInput = validation.data;

    try {
        const result = await calculateFertilizer(input);
        return { data: result };
    } catch (e) {
        console.error(e);
        return { error: "An unexpected error occurred during calculation." };
    }
}

const WeatherForecastActionInputSchema = z.object({
    location: z.string().min(2, { message: "Location is required." }),
});

export async function getWeatherForecastAction(formData: FormData) {
    const rawInput = {
        location: formData.get('location'),
    };

    const validation = WeatherForecastActionInputSchema.safeParse(rawInput);

    if (!validation.success) {
        return { error: "Invalid input.", details: validation.error.format() };
    }

    const input: WeatherForecastInput = validation.data;

    try {
        const result = await getWeatherForecast(input);
        return { data: result };
    } catch (e) {
        console.error(e);
        return { error: "An unexpected error occurred while fetching the forecast." };
    }
}

const MandiPriceActionInputSchema = z.object({
    cropName: z.string().min(1, { message: "Crop name is required." }),
});

export async function getMandiPriceAction(formData: FormData) {
    const rawInput = {
        cropName: formData.get('cropName'),
    };

    const validation = MandiPriceActionInputSchema.safeParse(rawInput);

    if (!validation.success) {
        return { error: "Invalid input.", details: validation.error.format() };
    }

    const input: MandiPriceInput = validation.data;

    try {
        const result = await getMandiPrice(input);
        return { data: result };
    } catch (e) {
        console.error(e);
        return { error: "An unexpected error occurred while fetching the price." };
    }
}

const SoilHealthGuideActionInputSchema = z.object({
    location: z.string().min(2, { message: "Location is required." }),
    cropType: z.string().min(1, { message: "Crop type is required." }),
});

export async function getSoilHealthGuideAction(formData: FormData) {
    const rawInput = {
        location: formData.get('location'),
        cropType: formData.get('cropType'),
    };
    
    const validation = SoilHealthGuideActionInputSchema.safeParse(rawInput);

    if (!validation.success) {
        return { error: "Invalid input.", details: validation.error.format() };
    }

    const input: SoilHealthGuideInput = validation.data;

    try {
        const result = await getSoilHealthGuide(input);
        return { data: result };
    } catch (e) {
        console.error(e);
        return { error: "An unexpected error occurred while fetching the guide." };
    }
}

const WaterUseAdvisorActionInputSchema = z.object({
    location: z.string().min(2, { message: "Location is required." }),
    cropType: z.string().min(1, { message: "Crop type is required." }),
});

export async function getWaterUseAdviceAction(formData: FormData) {
    const rawInput = {
        location: formData.get('location'),
        cropType: formData.get('cropType'),
    };
    
    const validation = WaterUseAdvisorActionInputSchema.safeParse(rawInput);

    if (!validation.success) {
        return { error: "Invalid input.", details: validation.error.format() };
    }

    const input: WaterUseAdvisorInput = validation.data;

    try {
        const result = await getWaterUseAdvice(input);
        return { data: result };
    } catch (e) {
        console.error(e);
        return { error: "An unexpected error occurred while fetching the advice." };
    }
}

const ChatAssistantActionInputSchema = z.object({
    query: z.string().min(1, { message: "Query is required." }),
});

export async function askChatAssistantAction(formData: FormData) {
    const rawInput = {
        query: formData.get('query'),
    };

    const validation = ChatAssistantActionInputSchema.safeParse(rawInput);

    if (!validation.success) {
        return { error: "Invalid input.", details: validation.error.format() };
    }
    
    const input: ChatAssistantInput = validation.data;

    try {
        const result = await askChatAssistant(input);
        return { data: result };
    } catch (e) {
        console.error(e);
        return { error: "An unexpected error occurred." };
    }
}

const SellProduceSchema = z.object({
  cropType: z.string().min(1, { message: "Crop type is required." }),
  quality: z.string().min(1, { message: "Quality is required." }),
  quantity: z.coerce.number().min(1, { message: "Quantity must be at least 1." }),
  price: z.coerce.number().min(1, { message: "Price must be at least 1." }),
  imageUri: z.string().optional(),
  userId: z.string(),
});

export async function listProduceForSaleAction(formData: FormData) {
    const rawInput = {
        cropType: formData.get('cropType'),
        quality: formData.get('grade'),
        quantity: formData.get('quantity'),
        price: formData.get('price'),
        imageUri: formData.get('imageUri'),
        userId: formData.get('userId'),
    };
    
    const validation = SellProduceSchema.safeParse(rawInput);

    if (!validation.success) {
        return { error: "Invalid input.", details: validation.error.format() };
    }
    
    const { userId, ...offerData } = validation.data;

    try {
        // This function now needs to be defined to interact with Firestore
        // For now, let's assume it exists in mutations
        // await listProduceForSale(firestore, userId, offerData); 
        return { data: { message: "Produce listed successfully!" } };
    } catch (e) {
        console.error(e);
        return { error: "An unexpected error occurred." };
    }
}


const DraftEmailActionInputSchema = z.object({
  userName: z.string(),
  userEmail: z.string().email(),
});

export async function draftEmailFromNoteAction(formData: FormData) {
    const rawInput = {
        userName: formData.get('userName'),
        userEmail: formData.get('userEmail'),
    };

    const validation = DraftEmailActionInputSchema.safeParse(rawInput);

    if (!validation.success) {
        return { error: "Invalid input.", details: validation.error.format() };
    }

    try {
        const notesPath = path.join(process.cwd(), 'Notes.txt');
        const userQuery = await fs.readFile(notesPath, 'utf-8');

        const { userName } = validation.data;
        const emailContent = await generateEmail({ userName, userQuery });
        
        const mailtoLink = `mailto:?subject=${encodeURIComponent(emailContent.subject)}&body=${encodeURIComponent(emailContent.body)}`;
        
        return { data: { mailtoLink } };

    } catch (e: any) {
        console.error(e);
        if (e.code === 'ENOENT') {
            return { error: "The Notes.txt file could not be found." };
        }
        return { error: "An unexpected error occurred while drafting the email." };
    }
}
