export type Cooperative = {
    id: string;
    name: string;
    location: string;
    mission: string;
    requirements: string[];
    benefits: string[];
    avatarUrl: string;
};

export const cooperatives: Cooperative[] = [
    {
        id: "coop-1",
        name: "Nashik Valley Grape Growers",
        location: "Nashik, Maharashtra",
        mission: "To empower grape farmers through collective bargaining, knowledge sharing, and access to premium markets.",
        requirements: [
            "Minimum 2 acres of vineyard",
            "Located within Nashik district",
            "Commitment to quality standards",
            "Annual membership fee of ₹2,000",
        ],
        benefits: [
            "Better prices for produce",
            "Access to export markets",
            "Subsidized fertilizers and pesticides",
            "Free workshops and training",
        ],
        avatarUrl: "https://picsum.photos/seed/coop1/100/100",
    },
    {
        id: "coop-2",
        name: "Pune Organic Farmers Collective",
        location: "Pune, Maharashtra",
        mission: "Promoting sustainable and organic farming practices to deliver healthy produce to urban consumers.",
        requirements: [
            "Certified Organic farm (or in transition)",
            "Minimum 1 acre of land",
            "Adherence to organic principles",
            "Willingness to participate in weekly markets",
        ],
        benefits: [
            "Direct access to Pune's organic market",
            "Shared resources for composting",
            "Group certification cost-sharing",
            "Community support and knowledge exchange",
        ],
        avatarUrl: "https://picsum.photos/seed/coop2/100/100",
    },
    {
        id: "coop-3",
        name: "Vidarbha Cotton & Soy Union",
        location: "Nagpur, Maharashtra",
        mission: "To improve the livelihood of cotton and soybean farmers through technology adoption and collective sales.",
        requirements: [
            "Primary crops must be Cotton or Soybean",
            "No minimum land requirement",
            "Agreement to sell 50% of produce through the co-op",
            "Annual fee: ₹1,000",
        ],
        benefits: [
            "Guaranteed minimum support price (MSP)",
            "Access to high-quality seeds",
            "Shared ginning and processing facilities",
            "Insurance against crop failure",
        ],
        avatarUrl: "https://picsum.photos/seed/coop3/100/100",
    },
];
