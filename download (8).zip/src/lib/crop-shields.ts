import type { CropShieldInnovation } from './innovations';
import { Waves, Zap, Droplet, Mic } from 'lucide-react';

export const cropShieldInnovations: CropShieldInnovation[] = [
    {
        id: "eco-sonic",
        title: "Eco-Sonic Crop Defender",
        description: "Uses nature’s rhythm — soft vibration frequencies — to repel insects like locusts, beetles, and grasshoppers safely. 100% eco-friendly and solar-powered.",
        category: "Pest Control",
        imageUrl: "https://images.unsplash.com/photo-1579581910976-fc040a1b5d14?q=80&w=1287&auto=format&fit=crop",
        Icon: Mic,
    },
    {
        id: "aqua-guard",
        title: "Aqua-Guard Soil Blanket",
        description: "A biodegradable “blanket” that protects roots from flooding or drought by adjusting its thickness to retain or release moisture.",
        category: "Water Management",
        imageUrl: "https://images.unsplash.com/photo-1591782250293-8a0a8e197a15?q=80&w=1287&auto=format&fit=crop",
        Icon: Waves,
    },
    {
        id: "solar-mist",
        title: "Solar Mist Canopy",
        description: "A foldable solar-powered net canopy that automatically sprays a fine cooling mist during heat waves, protecting crops from sunburn and dehydration.",
        category: "Climate Control",
        imageUrl: "https://images.unsplash.com/photo-1533055622055-a6e5b414f7a1?q=80&w=1287&auto=format&fit=crop",
        Icon: Droplet,
    },
    {
        id: "bio-light",
        title: "Bio-Light Trap Fence",
        description: "A colorful light fence that attracts harmful moths and insects at night but traps them safely without chemicals. Made from eco-biodegradable materials.",
        category: "Pest Control",
        imageUrl: "https://images.unsplash.com/photo-1532787161399-5523a5933668?q=80&w=1288&auto=format&fit=crop",
        Icon: Zap,
    },
];
