import { Shield, Bug, Droplets, Sun, Wind, CloudSnow, Flame, CloudRain } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export type SolutionStep = {
    step: number;
    title: string;
    description: string;
    icon: LucideIcon;
};

export type CropProblem = {
    id: string;
    name: string;
    image: string;
    category: 'Pest' | 'Weather' | 'Soil' | 'Disease';
    symptoms: string[];
    solution: SolutionStep[];
    relatedInnovation: {
        id: string;
        name: string;
    };
};

export const cropProblems: CropProblem[] = [
    {
        id: "pest-attack",
        name: "Pest Attack (e.g., Locusts)",
        image: "https://images.unsplash.com/photo-1599769395425-a136b81d6c8f?q=80&w=600",
        category: "Pest",
        symptoms: ["Chewed leaves", "Visible insects or larvae", "Sudden crop damage"],
        solution: [
            { step: 1, title: "Identify Symptoms", description: "Look for holes in leaves, damaged stems, and clusters of insects.", icon: Shield },
            { step: 2, title: "Remove the Source", description: "Use natural predators like birds, or introduce neem oil spray.", icon: Bug },
            { step: 3, title: "Maintain Healthy Growth", description: "Ensure proper watering and nutrients to help plants recover faster.", icon: Droplets },
            { step: 4, title: "Prevent Reoccurrence", description: "Plant repellent crops like marigolds or mint around your main crops.", icon: Shield }
        ],
        relatedInnovation: { id: "eco-sonic", name: "Eco-Sonic Crop Defender" },
    },
    {
        id: "drought",
        name: "Drought / Underwatering",
        image: "https://images.unsplash.com/photo-1523249099-913509043c52?q=80&w=600",
        category: "Weather",
        symptoms: ["Wilting or drooping leaves", "Dry, cracked soil", "Stunted growth"],
        solution: [
            { step: 1, title: "Identify Symptoms", description: "Check if soil is dry 2-3 inches deep. Leaves may curl or turn yellow.", icon: Sun },
            { step: 2, title: "Immediate Action", description: "Water deeply in the early morning or late evening to reduce evaporation.", icon: Droplets },
            { step: 3, title: "Conserve Moisture", description: "Apply a layer of mulch (straw, compost) around plants to retain water.", icon: Shield },
            { step: 4, title: "Prevent Reoccurrence", description: "Install a drip irrigation system for efficient watering.", icon: Shield }
        ],
        relatedInnovation: { id: "aqua-guard", name: "Aqua-Guard Soil Blanket" },
    },
    {
        id: "fungus",
        name: "Fungal Disease (e.g., Powdery Mildew)",
        image: "https://images.unsplash.com/photo-1612442456541-f1c92a635889?q=80&w=600",
        category: "Disease",
        symptoms: ["White powdery spots on leaves", "Yellowing leaves", "Distorted shoots"],
        solution: [
            { step: 1, title: "Identify Symptoms", description: "Look for the characteristic white, dusty coating on leaf surfaces.", icon: Shield },
            { step: 2, title: "Treat the Infection", description: "Spray a mixture of baking soda (1 tbsp) and water (1 gallon) on affected areas.", icon: Droplets },
            { step: 3, title: "Improve Airflow", description: "Prune overcrowded areas to increase air circulation around plants.", icon: Wind },
            { step: 4, title: "Prevent Reoccurrence", description: "Water the soil directly, not the leaves, to keep foliage dry.", icon: Shield }
        ],
        relatedInnovation: { id: "solar-mist", name: "Solar Mist Canopy" },
    },
    {
        id: "overwatering",
        name: "Overwatering / Flooding",
        image: "https://images.unsplash.com/photo-1591782250293-8a0a8e197a15?q=80&w=600",
        category: "Weather",
        symptoms: ["Yellowing, wilting leaves (from the bottom up)", "Root rot (mushy, brown roots)", "Stunted growth"],
        solution: [
            { step: 1, title: "Identify Symptoms", description: "Soil is constantly waterlogged. Leaves are limp and yellow despite wet soil.", icon: Droplets },
            { step: 2, title: "Stop Watering", description: "Allow the soil to dry out completely before watering again.", icon: Flame },
            { step: 3, title: "Improve Drainage", description: "Aerate the soil with a garden fork or add organic matter like compost to improve soil structure.", icon: Wind },
            { step: 4, title: "Prevent Reoccurrence", description: "Ensure proper field drainage and water only when the top 2 inches of soil are dry.", icon: Shield }
        ],
        relatedInnovation: { id: "aqua-guard", name: "Aqua-Guard Soil Blanket" },
    },
];

export const seasonalTips = [
    { id: "monsoon", title: "Monsoon Protection", description: "Ensure good drainage to prevent waterlogging. Use fungicides preventively.", icon: CloudRain },
    { id: "winter", title: "Winter Care", description: "Protect plants from frost with covers. Reduce watering frequency as growth slows.", icon: CloudSnow },
    { id: "summer", title: "Summer Irrigation", description: "Water deeply and less frequently. Use mulch to conserve soil moisture.", icon: Sun },
];
