export type Job = {
    id: string;
    title: string;
    location: string;
    type: "Full-time" | "Part-time" | "Contract";
    salary: string;
    description: string;
    organization: string;
};

export const jobs: Job[] = [
    {
        id: "drone-pilot-nashik",
        title: "Agriculture Drone Pilot",
        location: "Nashik, Maharashtra",
        type: "Full-time",
        salary: "₹35,000 - ₹50,000 / month",
        description: "Operate and maintain a fleet of agricultural drones for spraying, seeding, and monitoring. Requires DGCA certification.",
        organization: "Gramin Agri Society",
    },
    {
        id: "farm-manager-pune",
        title: "Organic Farm Manager",
        location: "Pune, Maharashtra",
        type: "Full-time",
        salary: "₹50,000 - ₹70,000 / month",
        description: "Oversee all operations of a 50-acre certified organic farm. Must have 5+ years of experience in organic farming.",
        organization: "FarmFuture Foundation",
    },
    {
        id: "irrigation-tech-aurangabad",
        title: "Irrigation Technician",
        location: "Aurangabad, Maharashtra",
        type: "Contract",
        salary: "₹25,000 / project",
        description: "Install and maintain drip irrigation systems for local farms. 3-month contract with potential for extension.",
        organization: "Dharti Putra Sahakari",
    },
    {
        id: "harvester-operator-nagpur",
        title: "Harvester Operator",
        location: "Nagpur, Maharashtra",
        type: "Part-time",
        salary: "₹1,200 / day",
        description: "Seasonal work operating a combine harvester during the wheat and soybean seasons. Experience required.",
        organization: "Krishi Vikas Kendra",
    },
];
