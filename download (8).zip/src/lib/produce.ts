export type Produce = {
    id: string;
    name: string;
};

export const produceData: Produce[] = [
    {
        id: "wheat",
        name: "Wheat",
    },
    {
        id: "rice",
        name: "Rice",
    },
    {
        id: "tomato",
        name: "Tomato",
    },
    {
        id: "onion",
        name: "Onion",
    },
    {
        id: "potato",
        name: "Potato",
    },
    {
        id: "sugarcane",
        name: "Sugarcane",
    },
     {
        id: "cotton",
        name: "Cotton",
    },
    {
        id: "maize",
        name: "Maize",
    },
    {
        id: "grapes",
        name: "Grapes",
    }
];
