
export type EquipmentRates = {
    tractor?: number;
    harvester?: number;
    drone?: number;
    plough?: number;
    rotavator?: number;
    seedDrill?: number;
    sprayer?: number;
    transplanter?: number;
    cultivator?: number;
    waterPump?: number;
    thresher?: number;
    reaper?: number;
    laserLeveler?: number;
};

export type Organization = {
    id: string;
    name: string;
    location: string;
    contact: string;
    services: ("Loans" | "Equipment" | "Booking" | "Seeds")[];
    rates?: EquipmentRates; // Monthly rental rates
};

export const organizations: Organization[] = [
    { 
        id: "kvk-nashik", 
        name: "Krishi Vikas Kendra", 
        location: "Nashik District", 
        contact: "9876543210", 
        services: ["Loans", "Equipment", "Booking"],
        rates: {
            tractor: 1000,
            harvester: 2400,
            drone: 1800,
            plough: 500,
            rotavator: 700,
            seedDrill: 900,
            waterPump: 400,
            laserLeveler: 2800,
        }
    },
    { 
        id: "gas-pune", 
        name: "Gramin Agri Society", 
        location: "Pune Division", 
        contact: "8765432109", 
        services: ["Equipment", "Booking", "Seeds"],
        rates: {
            tractor: 1100,
            drone: 1600,
            sprayer: 600,
            transplanter: 1200,
            cultivator: 500,
            reaper: 1000,
        }
    },
    { 
        id: "fff-nagpur", 
        name: "FarmFuture Foundation", 
        location: "Nagpur", 
        contact: "7654321098", 
        services: ["Loans", "Seeds"] 
    },
    { 
        id: "dps-aurangabad", 
        name: "Dharti Putra Sahakari", 
        location: "Aurangabad", 
        contact: "6543210987", 
        services: ["Equipment", "Booking"],
        rates: {
            tractor: 1050,
            harvester: 3000,
            drone: 2000,
            rotavator: 800,
            thresher: 1400,
            waterPump: 500,
        }
    },
];

    
