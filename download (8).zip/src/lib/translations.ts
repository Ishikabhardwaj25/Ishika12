
export type Language = 
  | 'en' | 'hi' | 'as' | 'bn' | 'brx' | 'doi' | 'gu' | 'kn' | 'ks' | 'kok' 
  | 'mai' | 'ml' | 'mni' | 'mr' | 'ne' | 'or' | 'pa' | 'sa' | 'sat' | 'sd' 
  | 'ta' | 'te' | 'ur';

export type TranslationContent = {
  welcome: {
    title: string;
    description: string;
  };
  aiAssistant: {
    title: string;
    description: string;
    dialogTitle: string;
    dialogDescription: string;
    featureCropDoctor: string;
    featureFertilizerCalculator: string;
    featureWeatherForecast: string;
    featureMandiPrices: string;
    featureSoilHealth: string;
    featureWaterAdvisor: string;
    featureChatAssistant: string;
    newsBoardTitle: string;
    newsBoardContent: string;
  };
  governmentHelp: {
    title: string;
    description: string;
    dialogTitle: string;
    dialogDescription: string;
    applyLoanTitle: string;
    applyLoanDescription: string;
    rentToolsTitle: string;
    rentToolsDescription: string;
    findOfficesTitle: string;
    findOfficesDescription: string;
    checkStatusTitle: string;
    checkStatusDescription: string;
  };
  rentServices: {
    title: string;
    description: string;
    dialogTitle: string;
    dialogDescription: string;
    bookServiceTitle: string;
    bookServiceDescription: string;
    findHelpersTitle: string;
    findHelpersDescription: string;
  };
  newIdeas: {
    title: string;
    description: string;
    dialogTitle: string;
    dialogDescription: string;
    exploreTitle: string;
    submitTitle: string;
  };
  trainingJobs: {
    title: string;
    description: string;
    dialogTitle: string;
    dialogDescription: string;
    findJobsTitle: string;
    trainingProgramsTitle: string;
  };
  marketplace: {
    title: string;
    description: string;
    dialogTitle: string;
    dialogDescription: string;
    marketPricesTitle: string;
    sellProduceTitle: string;
    readyBuyersTitle: string;
    farmStoreTitle: string;
  };
  myProfile: {
    title: string;
    description: string;
    dialogTitle: string;
    dialogDescription: string;
    farmOverview: string;
    achievements: string;
    recentActivity: string;
  };
  // Forms and other common strings
  forms: {
    // Loan Request Form
    loanRequestTitle: string;
    loanRequestDescription: string;
    loanPurposeLabel: string;
    loanPurposePlaceholder: string;
    purposeCrop: string;
    purposeTractor: string;
    purposeSeeds: string;
    purposeIrrigation: string;
    purposeOther: string;
    amountLabel: string;
    amountPlaceholder: string;
    durationLabel: string;
    durationPlaceholder: string;
    officeLabel: string;
    officePlaceholder: string;
    applyButton: string;
    sending: string;
    // Equipment Rent Hub
    rentToolsDialogTitle: string;
    rentToolsDialogDescription: string;
    toolLabel: string;
    toolPlaceholder: string;
    howLongLabel: string;
    durationUnitLabel: string;
    days: string;
    months: string;
    year: string;
    totalRent: string;
    govtDiscount: string;
    costPerDay: string;
    rentButton: string;
    // Service Booking Form
    bookServiceDialogTitle: string;
    bookServiceDialogDescription: string;
    serviceLabel: string;
    servicePlaceholder: string;
    plowing: string;
    harvesting: string;
    spraying: string;
    planLabel: string;
    planBasic: string;
    planStandard: string;
    planPremium: string;
    areaLabel: string;
    areaPlaceholder: string;
    dateLabel: string;
    datePlaceholder: string;
    helperLabel: string;
    helperPlaceholder: string;
    estimatedCost: string;
    bookButton: string;
    booking: string;
    // Other common
    submit: string;
    success: string;
    error: string;
    pending: string;
    approved: string;
    rejected: string;
    completed: string;
    close: string;
  }
};

export type Translations = {
  [key in Language]: TranslationContent;
};

const enTranslations: TranslationContent = {
  welcome: {
    title: "Welcome to your Farmverse",
    description: "Everything you need, sprouting at your fingertips.",
  },
  aiAssistant: {
    title: "AI Farming Assistant",
    description: "Your personal helper for smart farming.",
    dialogTitle: "KrishiBot - AI Agro Assistant",
    dialogDescription: "Your smart farming companion. Currently viewing:",
    featureCropDoctor: "Crop Doctor",
    featureFertilizerCalculator: "Fertilizer Calculator",
    featureWeatherForecast: "Weather Forecast",
    featureMandiPrices: "Mandi Prices",
    featureSoilHealth: "Soil Health Guide",
    featureWaterAdvisor: "Water Advisor",
    featureChatAssistant: "Chat Assistant",
    newsBoardTitle: "AI News Board",
    newsBoardContent: "[Live] Tomato prices expected to rise by 15% next week due to weather conditions.",
  },
  governmentHelp: {
    title: "Government Help",
    description: "Get loans & rent tools.",
    dialogTitle: "Government Help Center",
    dialogDescription: "Apply for loans and rent cheaper tools from the government.",
    applyLoanTitle: "Apply for Loan",
    applyLoanDescription: "Get money for your farm.",
    rentToolsTitle: "Rent Cheaper Tools",
    rentToolsDescription: "Use tractors, drones, and harvesters.",
    findOfficesTitle: "Find Local Offices",
    findOfficesDescription: "Find help centers near you.",
    checkStatusTitle: "Check My Application",
    checkStatusDescription: "See the status of your requests.",
  },
  rentServices: {
    title: "Agro Service",
    description: "Book services for your farm.",
    dialogTitle: "Agro Service",
    dialogDescription: "Book on-demand farming services from local self-help groups and organizations.",
    bookServiceTitle: "Book a Service",
    bookServiceDescription: "Schedule plowing, harvesting, or drone services.",
    findHelpersTitle: "Find Local Helpers",
    findHelpersDescription: "Discover groups providing services near you.",
  },
  newIdeas: {
    title: "Agri-Innovate",
    description: "See the latest in farming tech.",
    dialogTitle: "Agri-Innovate Hub",
    dialogDescription: "Cultivating the future of farming, one idea at a time.",
    exploreTitle: "Explore Innovations",
    submitTitle: "Submit Your Innovation",
  },
  trainingJobs: {
    title: "Training & Jobs",
    description: "Find work or learn new skills.",
    dialogTitle: "Training & Jobs Arena",
    dialogDescription: "Find skilled workers or join training programs to enhance your skills.",
    findJobsTitle: "Find Jobs",
    trainingProgramsTitle: "Training Programs",
  },
  marketplace: {
    title: "Marketplace",
    description: "Sell your crops directly.",
    dialogTitle: "Magical Marketplace",
    dialogDescription: "Your portal to sell produce, find buyers, and purchase supplies.",
    marketPricesTitle: "Market Prices",
    sellProduceTitle: "Sell Your Produce",
    readyBuyersTitle: "Ready Buyers",
    farmStoreTitle: "Farm Store",
  },
  myProfile: {
    title: "My Profile",
    description: "See your farm details.",
    dialogTitle: "My Profile",
    dialogDescription: "Your personal farm dashboard, achievements, and history.",
    farmOverview: "Farm Overview",
    achievements: "Achievements",
    recentActivity: "Recent Activity",
  },
  forms: {
    loanRequestTitle: "Apply for a Loan",
    loanRequestDescription: "Fill this form to get money for your farm.",
    loanPurposeLabel: "Why do you need a loan?",
    loanPurposePlaceholder: "Select a reason...",
    purposeCrop: "For crops",
    purposeTractor: "To buy a tractor",
    purposeSeeds: "For seeds & fertilizers",
    purposeIrrigation: "For water system",
    purposeOther: "Other reason",
    amountLabel: "How much money? (₹)",
    amountPlaceholder: "e.g., 50000",
    durationLabel: "For how many months?",
    durationPlaceholder: "e.g., 24",
    officeLabel: "Which office is near you?",
    officePlaceholder: "Select an office...",
    applyButton: "Apply for Loan",
    sending: "Sending...",
    rentToolsDialogTitle: "Rent Cheaper Tools",
    rentToolsDialogDescription: "Rent farming tools at a lower price with government help.",
    toolLabel: "Which tool do you need?",
    toolPlaceholder: "Select a tool...",
    howLongLabel: "For how long?",
    durationUnitLabel: "Days or Months?",
    days: "Days",
    months: "Months",
    year: "Year",
    totalRent: "Total Rent",
    govtDiscount: "Govt. Discount",
    costPerDay: "Cost Per Day",
    rentButton: "Rent This Tool",
    bookServiceDialogTitle: "Book a Farming Service",
    bookServiceDialogDescription: "Fill the form to book a service from a local helper.",
    serviceLabel: "What service do you need?",
    servicePlaceholder: "Select a service...",
    plowing: "Plowing & Tilling",
    harvesting: "Harvesting",
    spraying: "Pesticide Spraying",
    planLabel: "Select a Plan",
    planBasic: "Basic",
    planStandard: "Standard",
    planPremium: "Premium",
    areaLabel: "Area (in Acres)",
    areaPlaceholder: "e.g., 5",
    dateLabel: "Preferred Date",
    datePlaceholder: "Pick a date",
    helperLabel: "Which helper is near you?",
    helperPlaceholder: "Select a helper...",
    estimatedCost: "Estimated Total Cost",
    bookButton: "Book Service",
    booking: "Booking...",
    submit: "Submit",
    success: "Success!",
    error: "Error",
    pending: "Pending",
    approved: "Approved",
    rejected: "Rejected",
    completed: "Completed",
    close: "Close",
  }
};


export const translations: Translations = {
  en: enTranslations,
  hi: {
    ...enTranslations,
    welcome: {
      title: "आपके फार्मवर्स में आपका स्वागत है",
      description: "आपकी ज़रूरत की हर चीज़, आपकी उंगलियों पर।",
    },
    aiAssistant: {
        ...enTranslations.aiAssistant,
        title: "एआई खेती सहायक",
        description: "स्मार्ट खेती के लिए आपका व्यक्तिगत सहायक।",
        dialogTitle: "कृषिबॉट - एआई कृषि सहायक",
        dialogDescription: "आपका स्मार्ट खेती साथी। वर्तमान में देख रहे हैं:",
    },
    governmentHelp: {
        ...enTranslations.governmentHelp,
        title: "सरकारी मदद",
        description: "ऋण प्राप्त करें और उपकरण किराए पर लें।",
        dialogTitle: "सरकारी सहायता केंद्र",
        dialogDescription: "सरकार से ऋण के लिए आवेदन करें और सस्ते उपकरण किराए पर लें।",
    },
    rentServices: {
        ...enTranslations.rentServices,
        title: "एग्रो सर्विस",
        description: "अपने खेत के लिए सेवाएं बुक करें।",
        dialogTitle: "एग्रो सर्विस",
        dialogDescription: "स्थानीय स्वयं सहायता समूहों और संगठनों से मांग पर खेती सेवाएं बुक करें।",
    },
    newIdeas: {
        ...enTranslations.newIdeas,
        title: "एग्री-इनोवेट",
        description: "खेती की नवीनतम तकनीक देखें।",
        dialogTitle: "एग्री-इनोवेट हब",
        dialogDescription: "खेती के भविष्य को विकसित करना, एक समय में एक विचार।",
    },
    trainingJobs: {
        ...enTranslations.trainingJobs,
        title: "प्रशिक्षण और नौकरियां",
        description: "काम खोजें या नए कौशल सीखें।",
        dialogTitle: "प्रशिक्षण और नौकरी क्षेत्र",
        dialogDescription: "कुशल श्रमिक खोजें या अपने कौशल को बढ़ाने के लिए प्रशिक्षण कार्यक्रमों में शामिल हों।",
    },
    marketplace: {
        ...enTranslations.marketplace,
        title: "बाज़ार",
        description: "अपनी फसलें सीधे बेचें।",
        dialogTitle: "जादुई बाज़ार",
        dialogDescription: "उपज बेचने, खरीदार खोजने और आपूर्ति खरीदने के लिए आपका पोर्टल।",
    },
    myProfile: {
        ...enTranslations.myProfile,
        title: "मेरी प्रोफाइल",
        description: "अपने खेत का विवरण देखें।",
        dialogTitle: "मेरी प्रोफाइल",
        dialogDescription: "आपका व्यक्तिगत कृषि डैशबोर्ड, उपलब्धियां और इतिहास।",
    },
    forms: {
        ...enTranslations.forms,
      loanRequestTitle: "ऋण के लिए आवेदन करें",
      loanRequestDescription: "अपने खेत के लिए पैसे पाने के लिए यह फॉर्म भरें।",
      loanPurposeLabel: "आपको ऋण की आवश्यकता क्यों है?",
      loanPurposePlaceholder: "एक कारण चुनें...",
      purposeCrop: "फसलों के लिए",
      purposeTractor: "ट्रैक्टर खरीदने के लिए",
      purposeSeeds: "बीज और उर्वरकों के लिए",
      purposeIrrigation: "जल प्रणाली के लिए",
      purposeOther: "अन्य कारण",
      amountLabel: "कितने पैसे चाहिए? (₹)",
      amountPlaceholder: "उदा., 50000",
      durationLabel: "कितने महीनों के लिए?",
      durationPlaceholder: "उदा., 24",
      officeLabel: "आपके पास कौन सा कार्यालय है?",
      officePlaceholder: "एक कार्यालय चुनें...",
      applyButton: "ऋण के लिए आवेदन करें",
      sending: "भेज रहा है...",
      rentToolsDialogTitle: "सस्ते उपकरण किराए पर लें",
      rentToolsDialogDescription: "सरकारी सहायता से कम कीमत पर खेती के उपकरण किराए पर लें।",
      toolLabel: "आपको कौन सा उपकरण चाहिए?",
      toolPlaceholder: "एक उपकरण चुनें...",
      howLongLabel: "कितने समय के लिए?",
      durationUnitLabel: "दिन या महीने?",
      days: "दिन",
      months: "महीने",
      year: "वर्ष",
      totalRent: "कुल किराया",
      govtDiscount: "सरकारी छूट",
      costPerDay: "प्रति दिन लागत",
      rentButton: "यह उपकरण किराए पर लें",
      bookServiceDialogTitle: "खेती सेवा बुक करें",
      bookServiceDialogDescription: "एक स्थानीय सहायक से सेवा बुक करने के लिए फॉर्म भरें।",
      serviceLabel: "आपको कौन सी सेवा चाहिए?",
      servicePlaceholder: "एक सेवा चुनें...",
      plowing: "जुताई और जुताई",
      harvesting: "कटाई",
      spraying: "कीटनाशक छिड़काव",
      planLabel: "एक योजना चुनें",
      planBasic: "बुनियादी",
      planStandard: "मानक",
      planPremium: "प्रीमियम",
      areaLabel: "क्षेत्र (एकड़ में)",
      areaPlaceholder: "उदा., 5",
      dateLabel: "पसंदीदा तारीख",
      datePlaceholder: "एक तारीख चुनें",
      helperLabel: "आपके पास कौन सा सहायक है?",
      helperPlaceholder: "एक सहायक चुनें...",
      estimatedCost: "अनुमानित कुल लागत",
      bookButton: "सेवा बुक करें",
      booking: "बुक कर रहा है...",
      submit: "जमा करें",
      success: "सफलता!",
      error: "त्रुटि",
      pending: "लंबित",
      approved: "स्वीकृत",
      rejected: "अस्वीकृत",
      completed: "पूर्ण",
      close: "बंद करें",
    }
  },
  as: { // Assamese
    ...enTranslations,
    welcome: { title: "আপোনাৰ ফাৰ্মভাৰ্ছলৈ স্বাগতম", description: "আপোনাক প্ৰয়োজন হোৱা সকলো, আপোনাৰ আঙুলিৰ মূৰত।" }
  },
  bn: { // Bengali
    ...enTranslations,
    welcome: { title: "আপনার ফার্মভার্সে স্বাগতম", description: "আপনার যা কিছু প্রয়োজন, আপনার হাতের মুঠোয়।" }
  },
  brx: { // Bodo
    ...enTranslations,
    welcome: { title: "नोंथांनि फार्मभार्सआव बरायबाय", description: "नोंथांनि नांगौफोरखौ, नोंथांनि आखायनि सिङाव।" }
  },
  doi: { // Dogri
    ...enTranslations,
    welcome: { title: "तु'αडे फार्मवर्स च स्वागत ऐ", description: "जो बी तु'αну चाहिए, तु'αडे उंगलियें पर।" }
  },
  gu: { // Gujarati
    ...enTranslations,
    welcome: { title: "તમારા ફાર્મવર્સમાં આપનું સ્વાગત છે", description: "તમારે જે જોઈએ તે બધું, તમારી આંગળીના ટેરવે।" }
  },
  kn: { // Kannada
    ...enTranslations,
    welcome: { title: "ನಿಮ್ಮ ಫಾರ್ಮ್‌ವರ್ಸ್‌ಗೆ ಸ್ವಾಗತ", description: " ನಿಮಗೆ ಬೇಕಾದതെಲ್ಲವೂ, ನಿಮ್ಮ ಬೆರಳ ತುದಿಯಲ್ಲಿ." }
  },
  ks: { // Kashmiri
    ...enTranslations,
    welcome: { title: "تُہندِس فارم ورسس منز خوش آمدید", description: "ہر چیز یُس تُہہِ ضرورت چھُ، تُہندِ انگجِ پؠٹھ۔" }
  },
  kok: { // Konkani
    ...enTranslations,
    welcome: { title: "तुमच्या फार्मवर्सांत स्वागत", description: "तुमकां जाय आशिल्लें सगळें, तुमच्या बोटांच्या तोंडांत।" }
  },
  mai: { // Maithili
    ...enTranslations,
    welcome: { title: "अहाँक फार्मवर्समे स्वागत अछि", description: "अहाँके जे किछु चाही, अहाँक आँगुरक नोक पर।" }
  },
  ml: { // Malayalam
    ...enTranslations,
    welcome: { title: "നിങ്ങളുടെ ഫാംവേഴ്‌സിലേക്ക് സ്വാഗതം", description: "നിങ്ങൾക്ക് ആവശ്യമായതെല്ലാം നിങ്ങളുടെ വിരൽത്തുമ്പിൽ." }
  },
  mni: { // Manipuri
    ...enTranslations,
    welcome: { title: "ꯑꯗꯣꯝꯒꯤ ꯐꯥꯔꯝꯚꯔꯁꯇꯥ ꯇꯔꯥꯝꯅ ꯑꯣꯀꯆꯔꯤ", description: "ꯑꯗꯣꯝꯅ ꯄꯥꯝꯂꯤꯕ ꯈꯨꯗꯤꯡꯃꯛ, ꯑꯗꯣꯝꯒꯤ ꯈꯨꯠꯇ ꯂꯩ।" }
  },
  mr: { // Marathi
    ...enTranslations,
    welcome: { title: "तुमच्या फार्मवर्समध्ये स्वागत आहे", description: "तुम्हाला हवं ते सर्व, तुमच्या बोटांच्या टोकावर." }
  },
  ne: { // Nepali
    ...enTranslations,
    welcome: { title: "तपाईंको फार्मवर्समा स्वागत छ", description: "तपाईंलाई चाहिने सबै कुरा, तपाईंको औंलाको टुप्पोमा।" }
  },
  or: { // Odia
    ...enTranslations,
    welcome: { title: "ଆପଣଙ୍କ ଫାର୍ମଭର୍ସକୁ ସ୍ୱାଗତ", description: "ଆପଣଙ୍କୁ ଯାହା ଦରକାର, ତାହା ଆପଣଙ୍କ ଆଙ୍ଗୁଠି நுனியில்।" }
  },
  pa: { // Punjabi
    ...enTranslations,
    welcome: { title: "ਤੁਹਾਡੇ ਫਾਰਮਵਰਸ ਵਿੱਚ ਤੁਹਾਡਾ ਸਵਾਗਤ ਹੈ", description: "ਤੁਹਾਨੂੰ ਜੋ ਵੀ ਚਾਹੀਦਾ ਹੈ, ਤੁਹਾਡੀਆਂ ਉਂਗਲਾਂ 'ਤੇ।" }
  },
  sa: { // Sanskrit
    ...enTranslations,
    welcome: { title: "भवतः फार्मverse मध्ये स्वागतम्", description: "यत् किमपि भवतः आवश्यकम्, तत् भवतः अंगुल्यग्रे।" }
  },
  sat: { // Santali
    ...enTranslations,
    welcome: { title: "ᱟᱢᱟᱜ ᱯᱷᱟᱨᱢᱣᱟᱨᱥ ᱨᱮ ᱥᱟᱹᱜᱩᱱ ད स्वागत", description: "ᱟᱢᱟᱜ ᱡᱟᱦᱟᱸ ᱞᱟᱹᱜᱤᱫ དᱚᱨᱠᅡᱨ, ᱚᱱᱟ ᱟᱢᱟᱜ ᱠᱟᱹᱴᱩᱵ୍ ᱨᱮ।" }
  },
  sd: { // Sindhi
    ...enTranslations,
    welcome: { title: "توهان جي فارمورس ۾ ڀليڪار", description: "جيڪو ڪجهه توهان کي گهرجي, توهان جي آڱرين تي." }
  },
  ta: { // Tamil
    ...enTranslations,
    welcome: { title: "உங்கள் ஃபார்ம்வர்ஸுக்கு வரவேற்கிறோம்", description: "உங்களுக்கு தேவையான அனைத்தும், உங்கள் விரல் நுனியில்." }
  },
  te: { // Telugu
    ...enTranslations,
    welcome: { title: "మీ ఫార్మ్‌వర్స్‌కు స్వాగతం", description: "మీకు కావలసినవన్నీ, మీ చేతివేళ్ల వద్ద." }
  },
  ur: { // Urdu
    ...enTranslations,
    welcome: { title: "آپ کے فارمورس میں خوش آمدید", description: "آپ کو جس چیز کی ضرورت ہے، آپ کی انگلیوں پر۔" }
  },
};
