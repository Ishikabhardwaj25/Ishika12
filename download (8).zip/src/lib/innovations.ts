export type Innovation = {
    id: string;
    title: string;
    description: string;
    category: string;
    imageUrl: string;
};

export const innovations: Innovation[] = [
    {
        id: "drone-seeding",
        title: "Autonomous Drone Seeding",
        description: "Precision seeding and monitoring using AI-powered drones, increasing yield by up to 15% and reducing manual labor.",
        category: "Automation",
        imageUrl: "https://images.unsplash.com/photo-1579828898622-446f8a4733c8?q=80&w=800",
    },
    {
        id: "hydroponics",
        title: "Vertical Hydroponic Systems",
        description: "Soil-less farming in controlled environments, allowing for year-round cultivation with 90% less water usage.",
        category: "Sustainable Farming",
        imageUrl: "https://images.unsplash.com/photo-1591781498471-d0694154a3a6?q=80&w=800",
    },
    {
        id: "soil-sensors",
        title: "Smart Soil Sensors",
        description: "Real-time monitoring of soil moisture, pH, and nutrient levels, providing data-driven insights for optimal crop health.",
        category: "Data & Analytics",
        imageUrl: "https://images.unsplash.com/photo-1579581910976-fc040a1b5d14?q=80&w=800",
    },
    {
        id: "bio-pesticides",
        title: "Advanced Bio-Pesticides",
        description: "Eco-friendly pest control solutions derived from natural sources, protecting crops without harming the environment.",
        category: "Crop Protection",
        imageUrl: "https://images.unsplash.com/photo-1612442456541-f1c92a635889?q=80&w=800",
    },
];

export type CropShieldInnovation = {
    id: string;
    title: string;
    description: string;
    imageUrl: string;
    category: string;
    Icon: React.ElementType;
};
