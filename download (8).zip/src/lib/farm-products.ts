export type FarmProduct = {
    id: string;
    name: string;
    category: string;
    price: string;
    imageUrl: string;
    description: string;
};

export const farmProducts: FarmProduct[] = [
    {
        id: "prod-1",
        name: "High-Yield Wheat Seeds",
        category: "Seeds",
        price: "₹850 / 10kg",
        imageUrl: "https://images.unsplash.com/photo-1507919909716-291a2d492644?q=80&w=800",
        description: "Certified high-yield wheat seeds for rabi season."
    },
    {
        id: "prod-2",
        name: "Organic NPK Fertilizer",
        category: "Fertilizers",
        price: "₹1200 / 50kg bag",
        imageUrl: "https://images.unsplash.com/photo-1615114814213-954131038555?q=80&w=800",
        description: "Balanced NPK fertilizer for all crop types."
    },
    {
        id: "prod-3",
        name: "Hand Trowel",
        category: "Tools",
        price: "₹350",
        imageUrl: "https://images.unsplash.com/photo-1618587002046-591be6858a74?q=80&w=800",
        description: "Durable, rust-resistant hand trowel for planting and weeding."
    },
    {
        id: "prod-4",
        name: "Neem Oil Bio-Pesticide",
        category: "Pesticides",
        price: "₹700 / liter",
        imageUrl: "https://images.unsplash.com/photo-1625246333195-78d9c3874449?q=80&w=800",
        description: "Effective organic solution for controlling common pests."
    },
];
