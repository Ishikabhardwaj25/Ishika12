export type Buyer = {
    id: string;
    name: string;
    location: string;
    crop: string;
    quantity: number; // in quintals
    price: number; // in INR per quintal
    avatarUrl: string;
};

export const buyers: Buyer[] = [
    {
        id: "buyer-1",
        name: "Premium Foods Ltd.",
        location: "Mumbai, MH",
        crop: "Tomato",
        quantity: 200,
        price: 2800,
        avatarUrl: "https://picsum.photos/seed/buyer1/100/100",
    },
    {
        id: "buyer-2",
        name: "Fresh Veggies Inc.",
        location: "Pune, MH",
        crop: "Onion",
        quantity: 500,
        price: 1500,
        avatarUrl: "https://picsum.photos/seed/buyer2/100/100",
    },
    {
        id: "buyer-3",
        name: "GrainCorp",
        location: "Nagpur, MH",
        crop: "Wheat",
        quantity: 1000,
        price: 2150,
        avatarUrl: "https://picsum.photos/seed/buyer3/100/100",
    },
    {
        id: "buyer-4",
        name: "Local Market Co-op",
        location: "Nashik, MH",
        crop: "Grapes",
        quantity: 150,
        price: 4500,
        avatarUrl: "https://picsum.photos/seed/buyer4/100/100",
    },
];
