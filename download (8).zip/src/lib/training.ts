export type Training = {
    id: string;
    title: string;
    provider: string;
    duration: string;
    format: "Online" | "In-person" | "Hybrid";
    cost: string;
    description: string;
    imageUrl: string;
};

export const trainingPrograms: Training[] = [
    {
        id: "organic-farming-cert",
        title: "Organic Farming Certification",
        provider: "FarmFuture Foundation",
        duration: "6 Weeks",
        format: "Hybrid",
        cost: "₹5,000 (subsidized)",
        description: "A comprehensive course covering principles of organic farming, soil management, pest control, and certification processes.",
        imageUrl: "https://images.unsplash.com/photo-1597916819323-53e395c7a0b8?q=80&w=800",
    },
    {
        id: "drip-irrigation-workshop",
        title: "Drip Irrigation Workshop",
        provider: "Dharti Putra Sahakari",
        duration: "3 Days",
        format: "In-person",
        cost: "Free for members",
        description: "Hands-on workshop on designing, installing, and maintaining efficient drip irrigation systems for various crops.",
        imageUrl: "https://images.unsplash.com/photo-1621376395027-a0f1fb25b037?q=80&w=800",
    },
    {
        id: "agri-drone-license",
        title: "Agri-Drone Pilot License",
        provider: "Gramin Agri Society",
        duration: "2 Weeks",
        format: "In-person",
        cost: "₹25,000",
        description: "Become a certified drone pilot for agricultural applications. Includes flight training and preparation for DGCA exam.",
        imageUrl: "https://images.unsplash.com/photo-1579828898622-446f8a4733c8?q=80&w=800",
    },
    {
        id: "post-harvest-mgmt",
        title: "Post-Harvest Management",
        provider: "Krishi Vikas Kendra",
        duration: "4 Weeks",
        format: "Online",
        cost: "₹2,500",
        description: "Learn best practices for storage, processing, and value addition to reduce post-harvest losses and increase income.",
        imageUrl: "https://images.unsplash.com/photo-1606041933255-9345a69f1673?q=80&w=800",
    },
];
